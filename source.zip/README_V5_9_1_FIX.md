# BYD Telemetre V5.9.1 — Kotlin derleme hatası düzeltmesi

`feature/diagnostics/.../DualScanEngine.kt` 82. satırdaki `Pair<String?,String?>=try` yazımı `Pair<String?, String?> = try` biçiminde düzeltildi.

Bu, kullanıcının Gradle günlüğünde görülen `save` sözdizimi hatasının ve onu izleyen çözümlenemeyen isimlerin kaynağıdır. Tam Android/Gradle derlemesi burada doğrulanamamıştır.
