# No proprietary firmware classes are packaged or reflected into the phone app.
-keepattributes SourceFile,LineNumberTable
