package com.sealion7.companion

import com.sealion7.core.model.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class TirePressureSafetyTest {
    private val now = Instant.parse("2026-10-25T08:00:00Z")
    private val key = MetricKey.TIRE_FL
    private fun snapshot(value: Double, limit: Double? = 220.0, receivedAt: Instant = now): VehicleSnapshot {
        val metric = VehicleMetric(
            key.name, value, "kPa", DataSource.AAOS_CAR_HARDWARE,
            receivedAt, receivedAt, DataQuality.VALID, 30, SupportStatus.AVAILABLE,
            AccessScope.OEM_READ
        )
        val bounds = if (limit == null) emptyMap() else mapOf(key to TirePressureLimit(
            key, limit, DataSource.AAOS_CAR_HARDWARE, DataSource.AAOS_CAR_HARDWARE.name,
            "CarPropertyConfig.getMinValue(areaId) · TIRE_PRESSURE"
        ))
        return VehicleSnapshot(readings = mapOf(key to MetricState.Live(metric)), tirePressureLimits = bounds)
    }

    @Test fun lowPressureNeedsFreshReadingAndVehicleLimit() {
        val low = snapshot(205.0)
        assertEquals(TirePressureStatus.LOW, TirePressureSafety.assess(low, now).first().status)
        assertEquals(1, TirePressureSafety.alerts(low, now).size)
        assertTrue(TirePressureSafety.alerts(snapshot(205.0, null), now).isEmpty())
        assertTrue(TirePressureSafety.alerts(snapshot(205.0, receivedAt = now.minusSeconds(90)), now).isEmpty())
    }

    @Test fun equalToLimitDoesNotWarn() {
        assertTrue(TirePressureSafety.alerts(snapshot(220.0), now).isEmpty())
        assertEquals(TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT,
            TirePressureSafety.assess(snapshot(220.0), now).first().status)
    }

    @Test fun cannotUseAnotherWheelLimit() {
        val s = snapshot(190.0).copy(tirePressureLimits = mapOf(
            key to TirePressureLimit(MetricKey.TIRE_FR, 230.0, DataSource.AAOS_CAR_HARDWARE,
                DataSource.AAOS_CAR_HARDWARE.name, "Other wheel")
        ))
        assertTrue(TirePressureSafety.alerts(s, now).isEmpty())
    }

    @Test fun staleReadingAndNoPermissionDoNotWarn() {
        val base = snapshot(190.0)
        val metric = (base.number(key) as MetricState.Live).metric
        assertTrue(TirePressureSafety.alerts(base.copy(readings = mapOf(key to MetricState.Stale(metric, 60))), now).isEmpty())
        assertTrue(TirePressureSafety.alerts(base.copy(readings = mapOf(key to MetricState.PermissionRequired)), now).isEmpty())
    }
}
