package com.sealion7.companion

import com.sealion7.core.model.PowerTelemetryNormalizer
import com.sealion7.core.model.MetricKey
import org.junit.Assert.*
import org.junit.Test

class PowerTelemetryNormalizerTest {
    @Test fun `AAOS signed mW discharge yields positive kW`() {
        assertEquals(12.5, PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(-12_500_000.0)!!, 0.000001)
    }
    @Test fun `AAOS positive charge is not relabeled battery discharge`() {
        assertNull(PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(23_000_000.0))
    }
    @Test fun `invalid and out of range samples never become measurements`() {
        assertNull(PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(Double.NaN))
        assertNull(PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(Double.POSITIVE_INFINITY))
        assertNull(PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(-1_300_000_000.0))
    }
    @Test fun `traction and regeneration are independent of net battery and regen setting`() {
        assertNotEquals(MetricKey.TRACTION_POWER, MetricKey.BATTERY_NET_POWER)
        assertNotEquals(MetricKey.REGEN_POWER, MetricKey.REGEN_SETTING)
        assertNotEquals(MetricKey.TRACTION_POWER, MetricKey.REGEN_POWER)
    }
}
