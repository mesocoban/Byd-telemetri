package com.sealion7.companion

import com.sealion7.core.model.gpsBearingDirectionTr
import org.junit.Assert.assertEquals
import org.junit.Test

class HeadingFormatterTest {
    @Test fun cardinalDirections() {
        assertEquals("K", gpsBearingDirectionTr(0.0))
        assertEquals("KD", gpsBearingDirectionTr(45.0))
        assertEquals("D", gpsBearingDirectionTr(90.0))
        assertEquals("GD", gpsBearingDirectionTr(135.0))
        assertEquals("G", gpsBearingDirectionTr(180.0))
        assertEquals("GB", gpsBearingDirectionTr(225.0))
        assertEquals("B", gpsBearingDirectionTr(270.0))
        assertEquals("KB", gpsBearingDirectionTr(315.0))
        assertEquals("K", gpsBearingDirectionTr(359.9))
        assertEquals("K", gpsBearingDirectionTr(360.0))
    }
}
