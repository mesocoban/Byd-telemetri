package com.sealion7.companion

import com.sealion7.core.model.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class EnergyConsumptionTest {
    @Test fun instantConsumptionHasCorrectUnits() {
        assertEquals(20.0, EnergyConsumptionMath.instantaneousKwhPer100Km(20.0, 100.0)!!, 0.000001)
    }

    @Test fun lowSpeedIsNotReportedAsConsumption() {
        assertNull(EnergyConsumptionMath.instantaneousKwhPer100Km(30.0, 0.0))
        assertNull(EnergyConsumptionMath.instantaneousKwhPer100Km(30.0, 9.9))
    }

    @Test fun invalidMeasurementsAreRejected() {
        assertNull(EnergyConsumptionMath.instantaneousKwhPer100Km(-5.0, 80.0))
        assertNull(EnergyConsumptionMath.instantaneousKwhPer100Km(Double.NaN, 80.0))
    }

    @Test fun energyIntegrationExcludesLongGaps() {
        assertNull(EnergyConsumptionMath.energyKwh(30.0, 30.0))
        assertEquals(30.0 * 5.0 / 3600.0, EnergyConsumptionMath.energyKwh(30.0, 5.0)!!, 0.000001)
    }

    @Test fun noHistoricalTripIsInvented() {
        val tracker = EnergyConsumptionSession()
        val state = tracker.apply(VehicleSnapshot(), Instant.parse("2026-10-25T00:00:00Z"))
        assertTrue(state.number(MetricKey.LAST_TRIP_AVG_CONSUMPTION) is MetricState.Unavailable)
        assertTrue(state.number(MetricKey.TRIP_A_AVG_CONSUMPTION) is MetricState.Unavailable)
    }

    @Test fun allDiscoveryFieldsArePresent() {
        assertEquals(9, EnergyConsumptionEvidence.capabilities().size)
        assertFalse(EnergyConsumptionEvidence.capabilities().any { it.canWrite })
    }
}
