package com.sealion7.companion

import com.sealion7.core.model.AutomotiveMetricNormalizer as Metric
import org.junit.Assert.*
import org.junit.Test

/** Tests documented AAOS unit conversions without introducing synthetic data into production. */
class AutomotiveNormalizerTest {
 @Test fun speedMetersPerSecondToKmh() { assertEquals(36.0, Metric.speedKmh(10.0)!!, 0.00001) }
 @Test fun reverseSpeedIsMagnitude() { assertEquals(36.0, Metric.speedKmh(-10.0)!!, 0.00001) }
 @Test fun invalidSpeedMustNotLookLive() { assertNull(Metric.speedKmh(Double.NaN)) }
 @Test fun batterySocUsesActualUsableCapacity() { assertEquals(50.0, Metric.socPercent(44000.0, 88000.0)!!, 0.00001) }
 @Test fun absentBatteryCapacityMeansNoSoc() { assertNull(Metric.socPercent(44.0, 0.0)) }
 @Test fun batteryOverflowMustNotBeClamped() { assertNull(Metric.socPercent(110.0, 100.0)) }
 @Test fun rangeMeterConversion() { assertEquals(125.0, Metric.rangeKm(125000.0)!!, 0.00001) }
 @Test fun negativeRangeRejected() { assertNull(Metric.rangeKm(-1.0)) }
 @Test fun unrealisticOdometerRejected() { assertNull(Metric.odometerKm(-20.0)) }
 @Test fun externalTemperatureFiniteOnly() { assertNull(Metric.outsideCelsius(Double.POSITIVE_INFINITY)) }
}
