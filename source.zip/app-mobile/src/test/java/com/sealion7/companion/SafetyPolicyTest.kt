package com.sealion7.companion

import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.VehicleSafetyPolicy
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class SafetyPolicyTest {
 @Test fun phoneGpsMustNeverBecomeOemSpeed(){
  val now=Instant.now()
  val gps=VehicleMetric("phone.gps_speed",88.0,"km/sa",DataSource.PHONE_GPS,
    now,now,DataQuality.VALID,5,SupportStatus.AVAILABLE,AccessScope.PUBLIC_ANDROID)
  assertFalse(VehicleSafetyPolicy.canPresentAsVehicleSpeed(gps))
 }
 @Test fun noAuthorizedWriteMeansNoControl(){
  assertFalse(VehicleSafetyPolicy.canEnableRemoteCommand(false,true,true))
  assertFalse(VehicleSafetyPolicy.canEnableRemoteCommand(true,false,true))
  assertFalse(VehicleSafetyPolicy.canEnableRemoteCommand(true,true,false))
 }
 @Test fun vehicleHasNoFabricatedMetrics(){
  for(key in MetricKey.entries) assertTrue(VehicleSnapshot().number(key) is MetricState.Unavailable)
 }
}
