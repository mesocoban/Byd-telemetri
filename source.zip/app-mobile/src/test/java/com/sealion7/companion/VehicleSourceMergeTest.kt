package com.sealion7.companion

import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.VehicleSourceMerger
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class VehicleSourceMergeTest {
 private fun sample(source:DataSource,key:MetricKey,value:Double):MetricState.Live<Double>{
  val now=Instant.parse("2026-10-24T12:00:00Z")
  return MetricState.Live(VehicleMetric(key.name,value,key.unit,source,now,now,
   DataQuality.VALID,10,SupportStatus.AVAILABLE,AccessScope.OEM_READ))
 }
 @Test fun sourceSelectionKeepsProvenance() {
  val aaos = VehicleSnapshot(readings=mapOf(MetricKey.SOC to sample(DataSource.AAOS_CAR_HARDWARE,MetricKey.SOC,56.0)))
  val ts = VehicleSnapshot(readings=mapOf(MetricKey.SOC to sample(DataSource.TS_CAR_ADAPTER,MetricKey.SOC,56.0)))
  val merged=VehicleSourceMerger.merge(listOf(aaos,ts))
  val value=merged.number(MetricKey.SOC) as MetricState.Live
  assertEquals(DataSource.AAOS_CAR_HARDWARE,value.metric.source)
 }
 @Test fun phoneSpeedIsNeverVehicleSpeed() {
  val gps=VehicleSnapshot(readings=mapOf(MetricKey.VEHICLE_SPEED to sample(DataSource.PHONE_GPS,MetricKey.VEHICLE_SPEED,88.0)))
  assertFalse(VehicleSourceMerger.merge(listOf(gps)).number(MetricKey.VEHICLE_SPEED) is MetricState.Live)
 }
 @Test fun noSourceGivesNoLiveData() {
  assertFalse(VehicleSourceMerger.merge(emptyList()).number(MetricKey.SOC) is MetricState.Live)
 }
 @Test fun chargingPowerRequiresExplicitChargingFlag() {
  assertNull(OemTelemetryNormalizer.chargePower(359.4,false))
  assertEquals(7.2,OemTelemetryNormalizer.chargePower(7.2,true)!!,0.01)
 }
 @Test fun speedAndSocBounds() {
  assertNull(OemTelemetryNormalizer.speed(Double.NaN))
  assertNull(OemTelemetryNormalizer.speed(1000.0))
  assertNull(OemTelemetryNormalizer.soc(0.0))
  assertNull(OemTelemetryNormalizer.soc(105.0))
 }
}
