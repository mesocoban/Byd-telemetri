package com.sealion7.companion

import com.sealion7.core.model.AaosExtendedNormalizer
import org.junit.Assert.*
import org.junit.Test

class AaosExtendedNormalizerTest {
 @Test fun batteryNetPowerIsMilliwatts() {
  assertEquals(12.5, AaosExtendedNormalizer.batteryNetKw(12_500_000.0)!!,0.001)
  assertEquals(-40.0, AaosExtendedNormalizer.batteryNetKw(-40_000_000.0)!!,0.001)
  assertNull(AaosExtendedNormalizer.batteryNetKw(Double.NaN))
 }
 @Test fun tirePressureIsKpaAndRangeChecked() {
  assertEquals(250.0,AaosExtendedNormalizer.tireKpa(250.0)!!,0.001)
  assertNull(AaosExtendedNormalizer.tireKpa(-1.0))
  assertNull(AaosExtendedNormalizer.tireKpa(2000.0))
 }
 @Test fun temperatureAndRegenAreNotFabricated() {
  assertEquals(30.0,AaosExtendedNormalizer.batteryTempC(30.0)!!,0.001)
  assertNull(AaosExtendedNormalizer.batteryTempC(200.0))
  assertEquals(2.0,AaosExtendedNormalizer.regenSetting(2.0)!!,0.001)
  assertNull(AaosExtendedNormalizer.regenSetting(2.5))
 }
}
