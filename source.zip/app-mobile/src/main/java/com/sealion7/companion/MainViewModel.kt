package com.sealion7.companion

import android.content.Context
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sealion7.core.database.SavedFeature
import com.sealion7.core.database.SavedFeatureDao
import com.sealion7.core.model.*
import com.sealion7.core.preferences.PrivacySettings
import com.sealion7.data.vehicle.AndroidPhoneContextProvider
import com.sealion7.domain.vehicle.VehicleRepository
import com.sealion7.feature.catalog.FeatureCatalogLoader
import com.sealion7.feature.catalog.FeatureEntry
import com.sealion7.feature.catalog.FirmwareCandidate
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MainViewModel @Inject constructor(
 private val repository: VehicleRepository,
 private val settings: PrivacySettings,
 private val savedDao: SavedFeatureDao,
 private val phone: AndroidPhoneContextProvider,
 catalog: FeatureCatalogLoader,
 @ApplicationContext private val context: Context
) : ViewModel() {
 val features: List<FeatureEntry> = catalog.load()
 val glossary = catalog.glossary()
 val firmwareCandidates: List<FirmwareCandidate> = catalog.firmwareCandidates()
 val snapshot: StateFlow<VehicleSnapshot> = repository.observeVehicleSnapshot()
  .stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),VehicleSnapshot())
 val savedIds: StateFlow<Set<String>> = savedDao.observe().map{items-> items.map{it.id}.toSet()}
  .stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000), emptySet())
 val darkMode: StateFlow<Boolean> = settings.darkMode.stateIn(viewModelScope,SharingStarted.Eagerly,true)
 val gpsEnabled: StateFlow<Boolean> = settings.phoneGpsEnabled
  .stateIn(viewModelScope,SharingStarted.Eagerly,false)
 private val permissionRefresh = MutableStateFlow(0)
 private fun hasGpsPermission()=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
 val permissionGranted: StateFlow<Boolean> = permissionRefresh.map{hasGpsPermission()}
  .stateIn(viewModelScope,SharingStarted.Eagerly,hasGpsPermission())
 private val clock:Flow<Instant> = flow { while(true){emit(Instant.now());delay(1000)} }
 private val incoming:Flow<MetricState<Double>> = combine(gpsEnabled,permissionGranted){on,allowed->Pair(on,allowed)}
  .flatMapLatest { (on,allowed)-> when {
   !on -> flowOf(MetricState.Unavailable("Telefon GPS takibi kapalı"))
   !allowed -> flowOf(MetricState.PermissionRequired)
   else -> phone.observeGpsSpeed()
  } }
 val phoneSpeed:StateFlow<MetricState<Double>> = combine(incoming,clock) { state,now ->
  if(state is MetricState.Live && now.epochSecond-state.metric.receivedAt.epochSecond > state.metric.freshnessSeconds)
    MetricState.Stale(state.metric,now.epochSecond-state.metric.receivedAt.epochSecond)
  else state
 }.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),MetricState.Unavailable("Telefon GPS takibi kapalı"))
 /** Clock comes from the device, not from the vehicle telemetry. */
 val deviceClock: StateFlow<String> = clock
  .map { java.time.LocalDateTime.ofInstant(it, java.time.ZoneId.systemDefault())
   .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) }
  .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000),
   java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")))
 private val incomingHeading: Flow<MetricState<Double>> = combine(gpsEnabled, permissionGranted) { on, allowed -> on to allowed }
  .flatMapLatest { (on, allowed) -> when {
   !on -> flowOf(MetricState.Unavailable("Telefon GPS kapalı"))
   !allowed -> flowOf(MetricState.PermissionRequired)
   else -> phone.observeGpsDirection()
  } }
 val phoneHeading: StateFlow<MetricState<Double>> = combine(incomingHeading, clock) { state, now ->
  if (state is MetricState.Live && now.epochSecond - state.metric.receivedAt.epochSecond > state.metric.freshnessSeconds)
   MetricState.Stale(state.metric, now.epochSecond - state.metric.receivedAt.epochSecond)
  else state
 }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MetricState.Unavailable("Telefon GPS kapalı"))

 private val incomingGpsFix: Flow<PhoneGpsFixState> = combine(gpsEnabled,permissionGranted) { on,allowed -> on to allowed }
  .flatMapLatest { (on,allowed) -> when {
   !on -> flowOf(PhoneGpsFixState.Unavailable("Telefon GPS takibi kapalı"))
   !allowed -> flowOf(PhoneGpsFixState.PermissionRequired)
   else -> phone.observeGpsFix()
  } }
 val phoneGpsFix: StateFlow<PhoneGpsFixState> = combine(incomingGpsFix,clock) { state,now ->
  if(state is PhoneGpsFixState.Fresh && now.epochSecond-state.fix.measuredAt.epochSecond > 5)
   PhoneGpsFixState.Stale(now.epochSecond-state.fix.measuredAt.epochSecond)
  else state
 }.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),PhoneGpsFixState.Unavailable("GPS kapalı"))

 private val _phoneSpeedHistory=MutableStateFlow<List<Double>>(emptyList())
 val phoneSpeedHistory:StateFlow<List<Double>> = _phoneSpeedHistory.asStateFlow()
 val capabilities=MutableStateFlow<List<VehicleCapability>>(emptyList())
 val scanInProgress = MutableStateFlow(false)
 val scanSummary = MutableStateFlow("Henüz kullanıcı tarafından tarama başlatılmadı")
 val scanReport = MutableStateFlow<VehicleScanReport?>(null)
 val lastScanAt = MutableStateFlow<Instant?>(null)
 init {
  refreshCapabilities()
  // One initial permission-filtered audit on app start; the explicit button repeats it.
  scanVehicleSources()
  viewModelScope.launch {
   var lastSample:Instant?=null
   phoneSpeed.collect { state ->
    if(state is MetricState.Live && state.metric.receivedAt != lastSample) {
     lastSample=state.metric.receivedAt
     _phoneSpeedHistory.value=(_phoneSpeedHistory.value + state.metric.value).takeLast(42)
    }
   }
  }
 }
 fun refreshCapabilities(){viewModelScope.launch{ capabilities.value = repository.getCapabilities() }}
 /** A manual read-only discovery of permission-filtered capabilities and observations. */
 fun scanVehicleSources() {
  if(scanInProgress.value) return
  viewModelScope.launch {
   scanInProgress.value=true
   scanSummary.value="İzinli kaynaklar taranıyor…"
   try {
    val found = repository.getCapabilities()
    capabilities.value = found
    val report = repository.scanReadOnlySources()
    scanReport.value=report
    val getterCount=firmwareCandidates.flatMap{it.getters}.distinct().size
    lastScanAt.value=Instant.now()
    scanSummary.value = "${firmwareCandidates.size} firmware özelliği / $getterCount aday getter; " +
     "${report.sourcesChecked} kaynak kontrolü; ${report.attemptedGetterCalls} GERÇEK okuma çağrısı, " +
     "${report.nonNullResponses} ham yanıt, ${report.liveVehicleMetrics} geçerli araç metriği; " +
     "bağlantı: ${report.connection}. 4560 sabit tarama kullanılmıyor."
   } catch (_: SecurityException) {
    scanSummary.value="Tarama reddedildi: Android/OEM izni gerekli"
   } catch (_: Exception) {
    scanSummary.value="Tarama tamamlanamadı: servis erişimi veya SDK uyumluluğu kontrol edilmeli"
   } finally {
    scanInProgress.value=false
   }
  }
 }
 fun setDarkMode(enabled:Boolean){viewModelScope.launch {settings.setDarkMode(enabled)}}
 fun refreshPermission(){permissionRefresh.value++}
 fun setGpsEnabled(enabled:Boolean){
  viewModelScope.launch {
   settings.setPhoneGpsEnabled(enabled)
   if(!enabled) _phoneSpeedHistory.value=emptyList()
  }
 }
 fun toggleSaved(id:String){viewModelScope.launch{
  if(id in savedIds.value) savedDao.remove(id)
  else savedDao.add(SavedFeature(id,System.currentTimeMillis()))
 }}
}
