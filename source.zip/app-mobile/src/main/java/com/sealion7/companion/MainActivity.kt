package com.sealion7.companion

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sealion7.core.designsystem.DataCard
import com.sealion7.core.designsystem.MotionSpec
import com.sealion7.core.designsystem.Palette
import com.sealion7.core.designsystem.SealionTheme
import com.sealion7.core.model.*
import com.sealion7.feature.catalog.CatalogScreen
import com.sealion7.feature.catalog.FeatureEntry
import com.sealion7.feature.catalog.FirmwareCandidate
import com.sealion7.feature.catalog.FirmwareCandidateSection
import com.sealion7.feature.catalog.FirmwareEvidenceScreen
import com.sealion7.feature.catalog.GlossaryItem
import com.sealion7.feature.diagnostics.DiagnosticsScreen
import com.sealion7.feature.driving.*
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val model: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark by model.darkMode.collectAsStateWithLifecycle()
            SealionTheme(darkMode = dark) { MainScreen(model, this) }
        }
    }

    override fun onResume() {
        super.onResume()
        model.refreshPermission()
    }
}

private enum class Destination(val title: String) {
    PANEL("Panel"),
    DRIVE("Sürüş"),
    BATTERY("Pil ve Şarj"),
    CLIMATE("Klima ve Çevre"),
    VEHICLE("Araç Durumu"),
    ADAS("ADAS ve Güvenlik"),
    IDENTIFY("Tanımlama")
}

@Composable
private fun MainScreen(model: MainViewModel, activity: ComponentActivity) {
    var destination by remember { mutableStateOf(Destination.PANEL) }
    val snap by model.snapshot.collectAsStateWithLifecycle()
    val phone by model.phoneSpeed.collectAsStateWithLifecycle()
    val heading by model.phoneHeading.collectAsStateWithLifecycle()
    val phoneGpsFix by model.phoneGpsFix.collectAsStateWithLifecycle()
    val deviceClock by model.deviceClock.collectAsStateWithLifecycle()
    val history by model.phoneSpeedHistory.collectAsStateWithLifecycle()
    val gps by model.gpsEnabled.collectAsStateWithLifecycle()
    val saved by model.savedIds.collectAsStateWithLifecycle()
    val permission by model.permissionGranted.collectAsStateWithLifecycle()
    val darkMode by model.darkMode.collectAsStateWithLifecycle()
    val capabilities by model.capabilities.collectAsStateWithLifecycle()
    val scanning by model.scanInProgress.collectAsStateWithLifecycle()
    val scanSummary by model.scanSummary.collectAsStateWithLifecycle()
    val scanReport by model.scanReport.collectAsStateWithLifecycle()
    val firmwareCandidates = remember(model.firmwareCandidates) { model.firmwareCandidates }
    val features = remember(model.features) { model.features }
    val glossary = remember(model.glossary) { model.glossary }
    val isAaos = remember { activity.packageManager.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE) }
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.screenWidthDp > configuration.screenHeightDp

    val aaosPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        model.refreshCapabilities()
    }
    val gpsPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        model.refreshPermission()
        if (granted) model.setGpsEnabled(true)
    }

    val aaosRuntimePermissions = remember { arrayOf(
        "android.car.permission.CAR_SPEED", "android.car.permission.CAR_ENERGY",
        "android.car.permission.CAR_MILEAGE_3P", "android.car.permission.CAR_TIRES_3P",
        "android.car.permission.CAR_POWERTRAIN", "android.car.permission.CAR_EXTERIOR_ENVIRONMENT"
    ) }

    var pendingPermissionInfo by remember { mutableStateOf<String?>(null) }
    var pendingPermissionAction by remember { mutableStateOf("") }
    if (pendingPermissionInfo != null) {
        AlertDialog(
            onDismissRequest = { pendingPermissionInfo = null },
            title = { Text("BYD Telemetre · İzin isteği") },
            text = { Text(pendingPermissionInfo!!) },
            confirmButton = { TextButton(onClick = {
                val action = pendingPermissionAction
                pendingPermissionInfo = null
                if (action == "gps") gpsPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                if (action == "aaos") aaosPermissionLauncher.launch(aaosRuntimePermissions)
            }) { Text("İzin iste") } },
            dismissButton = { TextButton(onClick = { pendingPermissionInfo = null }) { Text("Vazgeç") } }
        )
    }
    val mainContent: @Composable () -> Unit = {
        ContentForDestination(
            destination = destination,
            snapshot = snap,
            phone = phone,
            phoneHeading = heading,
            gpsFix = phoneGpsFix,
            deviceClock = deviceClock,
            phoneHistory = history,
            gpsEnabled = gps,
            features = features,
            firmwareCandidates = firmwareCandidates,
            scanReport = scanReport,
            glossary = glossary,
            bookmarks = saved,
            toggleBookmark = model::toggleSaved,
            capabilities = capabilities,
            scanInProgress = scanning,
            scanSummary = scanSummary,
            onScan = model::scanVehicleSources,
            isAaos = isAaos,
            hasPermission = permission,
            darkMode = darkMode,
            onAaosPermissionRequest = {
                pendingPermissionAction = "aaos"
                pendingPermissionInfo = "Aracın desteklediği Android Automotive ölçümleri için hız, enerji, kilometre, lastik ve çevre verisi izinleri istenebilir. Bazı araç izinleri üretici imzası gerektirir; normal izin penceresi bunları veremez."
            },
            onDarkModeChange = model::setDarkMode,
            onGpsChange = { enable ->
                if (enable && !permission) {
                    pendingPermissionAction = "gps"
                    pendingPermissionInfo = "Telefon GPS konumu, yön ve rakım bilgilerini göstermek için konum izni gerekir. Konum verileri sunucuya gönderilmez."
                }
                else model.setGpsEnabled(enable)
            }
        )
    }

    if (isLandscape) {
        Row(Modifier.fillMaxSize()) {
            NavigationRail(
                modifier = Modifier.fillMaxHeight(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Spacer(Modifier.height(12.dp))
                Destination.entries.forEach { d ->
                    NavigationRailItem(
                        selected = destination == d,
                        onClick = { destination = d },
                        icon = { Icon(iconFor(d), contentDescription = d.title) },
                        label = { Text(d.title, textAlign = TextAlign.Center) },
                        alwaysShowLabel = true
                    )
                }
            }
            Row(
                Modifier.fillMaxSize().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(Modifier.weight(2f).fillMaxHeight()) { mainContent() }
                SecondaryLandscapePane(
                    destination = destination,
                    snapshot = snap,
                    gpsEnabled = gps,
                    phone = phone,
                    phoneHeading = heading,
                    deviceClock = deviceClock,
                    phoneHistory = history,
                    scanSummary = scanSummary,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    Destination.entries.forEach { d ->
                        NavigationBarItem(
                            selected = destination == d,
                            onClick = { destination = d },
                            icon = { Icon(iconFor(d), contentDescription = d.title) },
                            label = { Text(d.title, textAlign = TextAlign.Center) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) { mainContent() }
        }
    }
}

private fun iconFor(destination: Destination) = when (destination) {
    Destination.PANEL -> Icons.Default.Dashboard
    Destination.DRIVE -> Icons.Default.Speed
    Destination.BATTERY -> Icons.Default.BatteryChargingFull
    Destination.CLIMATE -> Icons.Default.AcUnit
    Destination.VEHICLE -> Icons.Default.DirectionsCar
    Destination.ADAS -> Icons.Default.Security
    Destination.IDENTIFY -> Icons.Default.ManageSearch
}

@Composable
private fun ContentForDestination(
    destination: Destination,
    snapshot: VehicleSnapshot,
    phone: MetricState<Double>,
    phoneHeading: MetricState<Double>,
    gpsFix: PhoneGpsFixState,
    deviceClock: String,
    phoneHistory: List<Double>,
    gpsEnabled: Boolean,
    features: List<FeatureEntry>,
    firmwareCandidates: List<FirmwareCandidate>,
    scanReport: VehicleScanReport?,
    glossary: List<GlossaryItem>,
    bookmarks: Set<String>,
    toggleBookmark: (String) -> Unit,
    capabilities: List<VehicleCapability>,
    scanInProgress: Boolean,
    scanSummary: String,
    onScan: () -> Unit,
    isAaos: Boolean,
    hasPermission: Boolean,
    darkMode: Boolean,
    onAaosPermissionRequest: () -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onGpsChange: (Boolean) -> Unit
) {
    when (destination) {
        Destination.PANEL -> PanelScreen(snapshot, phone, phoneHistory, gpsEnabled, phoneHeading, deviceClock)
        Destination.DRIVE -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) { DrivingDashboardScreen(snapshot, phone, phoneHistory, gpsEnabled, phoneHeading, deviceClock) }
            FirmwareCandidateSection("Sürüş", firmwareCandidates, snapshot)
        }
        Destination.BATTERY -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) { BatteryChargeScreen(snapshot) }
            FirmwareCandidateSection("Pil ve Şarj", firmwareCandidates, snapshot)
        }
        Destination.CLIMATE -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) { ClimateEnvironmentScreen(snapshot) }
            FirmwareCandidateSection("Klima ve Çevre", firmwareCandidates, snapshot)
        }
        Destination.VEHICLE -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) { VehicleStatusScreen(snapshot) }
            FirmwareCandidateSection("Araç Durumu", firmwareCandidates, snapshot)
        }
        Destination.ADAS -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) { AdasSafetyScreen(snapshot) }
            FirmwareCandidateSection("ADAS ve Güvenlik", firmwareCandidates, snapshot)
        }
        Destination.IDENTIFY -> IdentifyScreen(
            capabilities = capabilities,
            gpsEnabled = gpsEnabled,
            phoneState = phone,
            phoneHeading = phoneHeading,
            gpsFix = gpsFix,
            deviceClock = deviceClock,
            snapshot = snapshot,
            scanInProgress = scanInProgress,
            scanSummary = scanSummary,
            onScan = onScan,
            features = features,
            firmwareCandidates = firmwareCandidates,
            scanReport = scanReport,
            glossary = glossary,
            bookmarks = bookmarks,
            onToggleBookmark = toggleBookmark,
            isAaos = isAaos,
            hasPermission = hasPermission,
            darkMode = darkMode,
            onAaosPermissionRequest = onAaosPermissionRequest,
            onDarkModeChange = onDarkModeChange,
            onGpsChange = onGpsChange
        )
    }
}

@Composable
private fun PanelScreen(
    snapshot: VehicleSnapshot,
    phoneState: MetricState<Double>,
    phoneHistory: List<Double>,
    gpsEnabled: Boolean,
    phoneHeading: MetricState<Double>,
    deviceClock: String
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Genel Panel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item { AlertBanner(snapshot.alerts) }
        item { DirectionTimeRow(phoneHeading, deviceClock, Modifier.fillMaxWidth()) }
        item {
            SpeedHeroCard(snapshot.number(MetricKey.VEHICLE_SPEED), Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RangeHeroCard(snapshot.number(MetricKey.RANGE), Modifier.weight(1f))
                BatterySocCard(snapshot.number(MetricKey.SOC), Modifier.weight(1f))
            }
        }
        item { DriveStateCards(snapshot.driveMode, snapshot.gear, snapshot.number(MetricKey.REGEN_SETTING), Modifier.fillMaxWidth()) }
        item {
            EnergyFlowCard(
                tractionPower = snapshot.number(MetricKey.TRACTION_POWER),
                batteryConsumption = snapshot.number(MetricKey.BATTERY_CONSUMPTION_POWER),
                regenPower = snapshot.number(MetricKey.REGEN_POWER),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { EnergyConsumptionCards(snapshot, includeTrips = false) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedStatusMetricCard("Toplam km", snapshot.number(MetricKey.ODOMETER), Modifier.weight(1f))
                AnimatedStatusMetricCard("Şarj gücü", snapshot.number(MetricKey.CHARGE_POWER), Modifier.weight(1f))
            }
        }
        if (gpsEnabled) {
            item { PhoneSpeedTile(phoneState, phoneHistory) }
        }
        item {
            Text(
                "Panel, bütün grupların özet görünümüdür. Gerçek araç telemetrisi yalnız doğrulanmış salt-okunur kaynaktan gösterilir.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BatteryChargeScreen(snapshot: VehicleSnapshot) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Pil ve Şarj", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BatterySocCard(snapshot.number(MetricKey.SOC), Modifier.weight(1f))
                RangeHeroCard(snapshot.number(MetricKey.RANGE), Modifier.weight(1f))
            }
        }
        item { EnergyFlowCard(
            tractionPower = snapshot.number(MetricKey.TRACTION_POWER),
            batteryConsumption = snapshot.number(MetricKey.BATTERY_CONSUMPTION_POWER),
            regenPower = snapshot.number(MetricKey.REGEN_POWER),
            modifier = Modifier.fillMaxWidth()
        ) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedStatusMetricCard("Batarya net akışı (±)", snapshot.number(MetricKey.BATTERY_NET_POWER), Modifier.weight(1f), "kW")
                AnimatedStatusMetricCard("Batarya ort. sıcaklığı", snapshot.number(MetricKey.BATTERY_AVG_TEMP), Modifier.weight(1f), "°C")
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedStatusMetricCard("Şarj gücü", snapshot.number(MetricKey.CHARGE_POWER), Modifier.weight(1f), "kW")
                AnimatedStatusMetricCard("Batarya net akışı", snapshot.number(MetricKey.BATTERY_NET_POWER), Modifier.weight(1f), "kW")
            }
        }
        item { DriveStateCards(snapshot.driveMode, snapshot.gear, snapshot.number(MetricKey.REGEN_SETTING), Modifier.fillMaxWidth()) }
        item { EnergyConsumptionCards(snapshot, includeTrips = true) }
        item {
            AnimatedStatusMetricCard("TS şarj durumu · ham kod (AC/DC doğrulanmadı)",
                snapshot.number(MetricKey.TS_CHARGER_STATE_RAW), Modifier.fillMaxWidth(), "kod")
        }
        item { CarSettingsRawSummary(snapshot, setOf("Enerji", "Şarj", "Batarya/BMS", "Şarj bağlantısı", "Şarj limiti", "Planlı şarj", "Batarya termal", "Deşarj/V2L/V2V/V2G", "Enerji istatistiği", "Batarya/şarj uyarı", "Özel şarj"), Modifier.fillMaxWidth()) }
        item { PlaceholderSystemCard("12 V akü voltajı", "Firmware tarafında belirlenen aday alan. Canlı eşleme henüz doğrulanmadı.") }
        item { PlaceholderSystemCard("Şarj bağlantısı ve kalan süre", "AC/DC bağlantısı, süre ve planlı şarj için salt-okunur adaptör genişletmesi gerekir.") }
    }
}

@Composable
private fun ClimateEnvironmentScreen(snapshot: VehicleSnapshot) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Klima ve Çevre", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedStatusMetricCard("Dış sıcaklık", snapshot.number(MetricKey.OUTSIDE_TEMP), Modifier.weight(1f), "°C")
                AmbientTemperatureCard(snapshot.number(MetricKey.OUTSIDE_TEMP), Modifier.weight(1f))
            }
        }
        item { PlaceholderSystemCard("Klima durumu", "A/C, AUTO, sürücü/yolcu sıcaklığı, fan ve sirkülasyon verileri tanımlandı; henüz canlı okuyucuya bağlanmadı.") }
        item { PlaceholderSystemCard("Kabin sıcaklığı", "Kabin sıcaklığı ve HVAC yönlendirme alanları okunursa bu ekranda canlı kartlara dönüşecek.") }
        item { PlaceholderSystemCard("Dış çevre", "Yağmur, ortam ışığı ve ek çevresel sensörler yalnız erişilebilir kaynaktan gösterilecek.") }
    }
}

@Composable
private fun VehicleStatusScreen(snapshot: VehicleSnapshot) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Araç Durumu", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        if (snapshot.alerts.any { it.code.startsWith("TPMS_LOW_") }) {
            item { AlertBanner(snapshot.alerts.filter { it.code.startsWith("TPMS_LOW_") }) }
        }
        item { TireGrid(snapshot) }
        item { CarSettingsRawSummary(snapshot, setOf("TPMS", "Gösterge"), Modifier.fillMaxWidth()) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedStatusMetricCard("Toplam kilometre", snapshot.number(MetricKey.ODOMETER), Modifier.weight(1f), "km")
                AnimatedStatusMetricCard("Trip A", snapshot.number(MetricKey.TRIP_A), Modifier.weight(1f), "km")
            }
        }
        item { AnimatedStatusMetricCard("Trip B", snapshot.number(MetricKey.TRIP_B), Modifier.fillMaxWidth(), "km") }
        item { PlaceholderSystemCard("Kapılar, camlar, bagaj ve kilit", "Bu gövde alanları firmware içinde belirlenmiş durumda; doğrulanmış canlı okuma bulunursa burada ayrı kartlar gösterilecek.") }
        item { PlaceholderSystemCard("Aydınlatma ve araç gövdesi", "Farlar, bagaj, merkezi kilit ve gövde uyarıları ayrı salt-okunur adaptör grubuna alınacak.") }
    }
}

@Composable
private fun AdasSafetyScreen(snapshot: VehicleSnapshot) {
    var selected by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = selected, edgePadding = 4.dp) {
            listOf("48 gösterge", "10 arıza mesajı", "ADAS durumları", "OEM ham arıza").forEachIndexed { index, title ->
                Tab(selected = selected == index, onClick = { selected = index }, text = { Text(title) })
            }
        }
        when (selected) {
            0 -> DashboardIndicatorCatalog(snapshot, Modifier.fillMaxSize())
            1 -> DashboardFaultMessages(Modifier.fillMaxSize())
            3 -> LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                item { CarSettingsRawSummary(snapshot, setOf("Arıza"), Modifier.fillMaxWidth()) }
            }
            else -> {
                val systems = listOf("AHSS", "AEB", "BSD", "FCW", "TSR", "LDA", "ELKA", "ABS", "ESC")
                LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item { Text("ADAS ve Güvenlik", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                    item { AlertBanner(snapshot.alerts) }
                    items(systems) { system ->
                        PlaceholderSystemCard(system, "OEM erişimi ve durum kodları henüz doğrulanmadı; bu kart gerçek zamanlı arıza göstergesi değildir.")
                    }
                    item {
                        Text("Yalnız izinli, salt-okunur ölçümler kullanılacaktır. Uyarı kataloğundaki bir getter adı, araçtan okunduğu anlamına gelmez.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun IdentifyScreen(
    capabilities: List<VehicleCapability>,
    gpsEnabled: Boolean,
    phoneState: MetricState<Double>,
    phoneHeading: MetricState<Double>,
    gpsFix: PhoneGpsFixState,
    deviceClock: String,
    snapshot: VehicleSnapshot,
    scanInProgress: Boolean,
    scanSummary: String,
    onScan: () -> Unit,
    features: List<FeatureEntry>,
    firmwareCandidates: List<FirmwareCandidate>,
    scanReport: VehicleScanReport?,
    glossary: List<GlossaryItem>,
    bookmarks: Set<String>,
    onToggleBookmark: (String) -> Unit,
    isAaos: Boolean,
    hasPermission: Boolean,
    darkMode: Boolean,
    onAaosPermissionRequest: () -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onGpsChange: (Boolean) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 4.dp) {
            listOf("Okunanlar", "Belirlenenler", "115 özellik", "Kılavuz", "Ayarlar").forEachIndexed { index, title ->
                Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> DiagnosticsScreen(capabilities, gpsEnabled, phoneState, snapshot, scanInProgress, scanSummary, onScan,
                phoneHeading = phoneHeading, deviceClock = deviceClock, gpsFix = gpsFix, scanReport=scanReport,
                firmwareCount=firmwareCandidates.size,
                distinctGetters=firmwareCandidates.flatMap { it.getters }.distinct().size)
            1 -> IdentifiedSystemsScreen(capabilities, snapshot)
            2 -> FirmwareEvidenceScreen(firmwareCandidates, snapshot)
            3 -> CatalogScreen(features, glossary, bookmarks, onToggleBookmark)
            else -> SettingsScreen(
                gps = gpsEnabled,
                hasPermission = hasPermission,
                darkMode = darkMode,
                isAaos = isAaos,
                onAaosPermissionRequest = onAaosPermissionRequest,
                onDarkModeChange = onDarkModeChange,
                onGpsChange = onGpsChange
            )
        }
    }
}

@Composable
private fun IdentifiedSystemsScreen(capabilities: List<VehicleCapability>, snapshot: VehicleSnapshot) {
    val identified = capabilities.filter { it.canRead || it.providerId != null }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Belirlenen alanlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Text(
                "Burada salt-okunur olarak belirlenen alanlar listelenir. Canlı veri olmayan alanlar, ilgili sayfalarda da belirlenen sistem olarak görünür.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        items(identified) { cap ->
            val live = snapshot.readings[cap.key]
            DataCard(cap.key.title, Modifier.fillMaxWidth()) {
                Text("Kaynak: ${cap.providerId ?: "Yok"}")
                Text("Okuma durumu: ${if (live is MetricState.Live) "Canlı / hesaplanan" else if (cap.canRead) "Aday / Yetkili" else "Henüz doğrulanmadı"}")
                Text("Destek: ${cap.supportStatus}")
                Text("Kısıtlar: ${cap.constraints.joinToString().ifBlank { "Belirtilmedi" }}", style = MaterialTheme.typography.bodySmall)
                Text(
                    when (live) {
                        is MetricState.Live -> "Canlı veri mevcut"
                        is MetricState.Stale -> "Önceden okundu, güncel değil"
                        is MetricState.PermissionRequired -> "İzin gerekli"
                        is MetricState.Unsupported -> "Desteklenmiyor"
                        is MetricState.Unavailable -> live.reason
                        is MetricState.Error -> "Hata: ${live.code}"
                        else -> "Bağlantı yok"
                    },
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun SecondaryLandscapePane(
    destination: Destination,
    snapshot: VehicleSnapshot,
    gpsEnabled: Boolean,
    phone: MetricState<Double>,
    phoneHeading: MetricState<Double>,
    deviceClock: String,
    phoneHistory: List<Double>,
    scanSummary: String,
    modifier: Modifier = Modifier
) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hızlı Bakış", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        DirectionTimeRow(phoneHeading, deviceClock, Modifier.fillMaxWidth())
        DataCard("Aktif ekran", Modifier.fillMaxWidth()) {
            Text(destination.title, fontWeight = FontWeight.SemiBold)
            Text("Yatay modda iki bölge kullanılır; sol tarafta standart Android gezinme çubuğu bulunur.", style = MaterialTheme.typography.bodySmall)
        }
        CompactMetricRow("Hız", snapshot.number(MetricKey.VEHICLE_SPEED), "km/sa")
        CompactMetricRow("SOC", snapshot.number(MetricKey.SOC), "%")
        CompactMetricRow("Menzil", snapshot.number(MetricKey.RANGE), "km")
        CompactMetricRow("Çekiş gücü", snapshot.number(MetricKey.TRACTION_POWER), "kW")
        CompactMetricRow("Batarya tüketimi", snapshot.number(MetricKey.BATTERY_CONSUMPTION_POWER), "kW")
        CompactMetricRow("Anlık tüketim", snapshot.number(MetricKey.INSTANT_CONSUMPTION), "kWh/100 km")
        CompactMetricRow("İzleme ortalaması", snapshot.number(MetricKey.TRACKED_AVG_CONSUMPTION), "kWh/100 km")
        CompactMetricRow("Rejenerasyon gücü", snapshot.number(MetricKey.REGEN_POWER), "kW")
        CompactMetricRow("Şarj", snapshot.number(MetricKey.CHARGE_POWER), "kW")
        if (gpsEnabled) {
            PhoneSpeedTile(phone, phoneHistory)
        }
        DataCard("Tanılama özeti", Modifier.fillMaxWidth()) {
            Text(scanSummary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CompactMetricRow(title: String, state: MetricState<Double>, unit: String) {
    DataCard(title, Modifier.fillMaxWidth()) {
        val color by animateColorAsState(colorForState(state), label = "compact-card")
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(color.copy(alpha = 0.18f))
                .padding(14.dp)
        ) {
            Text(metricValueText(state, unit), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AmbientTemperatureCard(state: MetricState<Double>, modifier: Modifier = Modifier) {
    val color by animateColorAsState(colorForTemperatureState(state), label = "ambient-temp")
    DataCard("Çevresel gösterge", modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(92.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(color.copy(alpha = 0.75f), color.copy(alpha = 0.2f))))
        ) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(metricValueText(state, "°C"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Dış çevre sıcaklığı", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun EnergyFlowCard(
    tractionPower: MetricState<Double>,
    batteryConsumption: MetricState<Double>,
    regenPower: MetricState<Double>,
    modifier: Modifier = Modifier
) {
    val tractionColor by animateColorAsState(colorForPowerState(tractionPower), label = "traction-color")
    val batteryColor by animateColorAsState(colorForPowerState(batteryConsumption), label = "battery-discharge-color")
    val regenColor by animateColorAsState(
        if (regenPower is MetricState.Live) Palette.positive else colorForPowerState(regenPower),
        label = "regen-color"
    )
    val tractionProgress by animateFloatAsState(progressForAbsMetric(tractionPower, 250.0), tween(MotionSpec.fillMillis), label = "traction-progress")
    val batteryProgress by animateFloatAsState(progressForAbsMetric(batteryConsumption, 250.0), tween(MotionSpec.fillMillis), label = "discharge-progress")
    val regenProgress by animateFloatAsState(progressForAbsMetric(regenPower, 250.0), tween(MotionSpec.fillMillis), label = "regen-progress")
    DataCard("Anlık güç akışı · ayrı ölçümler", modifier) {
        LabeledAnimatedBar("Çekiş gücü (motor)", tractionProgress, tractionColor, metricValueText(tractionPower, "kW"))
        LabeledAnimatedBar("Batarya tüketim gücü (DC)", batteryProgress, batteryColor, metricValueText(batteryConsumption, "kW"))
        LabeledAnimatedBar("Rejenerasyon gücü (geri kazanım)", regenProgress, regenColor, metricValueText(regenPower, "kW"))
        Text("Batarya deşarj gücü motor çekiş gücü değildir. Rejenerasyon ayar kademesi veya pozitif batarya şarj akışı, ölçülmüş rejenerasyon gücü sayılamaz.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable
private fun LabeledAnimatedBar(title: String, progress: Float, color: Color, valueLabel: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(valueLabel, style = MaterialTheme.typography.labelMedium)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(50)),
            color = color,
            trackColor = color.copy(alpha = 0.18f)
        )
    }
}

@Composable
private fun AnimatedStatusMetricCard(
    title: String,
    state: MetricState<Double>,
    modifier: Modifier = Modifier,
    unit: String? = null
) {
    val bg by animateColorAsState(colorForState(state).copy(alpha = 0.16f), label = "$title-bg")
    val ring by animateColorAsState(colorForState(state), label = "$title-ring")
    val progress by animateFloatAsState(progressForGenericMetric(state), tween(MotionSpec.fillMillis), label = "$title-progress")
    DataCard(title, modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(56.dp)) {
                    drawArc(
                        color = ring.copy(alpha = 0.15f),
                        startAngle = 140f,
                        sweepAngle = 260f,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = ring,
                        startAngle = 140f,
                        sweepAngle = 260f * progress,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                Box(Modifier.size(8.dp).clip(CircleShape).background(ring))
            }
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bg)
                    .padding(12.dp)
            ) {
                Text(metricValueText(state, unit ?: ""), fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text(stateDescription(state), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun TireGrid(snapshot: VehicleSnapshot) {
    TireWheelSummary(snapshot, Modifier.fillMaxWidth())
}

@Composable
private fun PlaceholderSystemCard(title: String, body: String) {
    DataCard(title, Modifier.fillMaxWidth()) {
        Text(body)
        Text("Durum: Belirlendi / Canlı okuma henüz doğrulanmadı", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SettingsScreen(
    gps: Boolean,
    hasPermission: Boolean,
    darkMode: Boolean,
    isAaos: Boolean,
    onAaosPermissionRequest: () -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onGpsChange: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayarlar ve gizlilik", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        DataCard("Telefon konumu", Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Telefon GPS hızını göster")
                    Text("Yalnız açıkken ölçülür. Araç hızı veya OEM telemetrisi yerine geçmez.", style = MaterialTheme.typography.bodySmall)
                    Text(if (hasPermission) "Konum izni: verildi" else "Konum izni: gerekli", style = MaterialTheme.typography.labelSmall)
                }
                Switch(checked = gps, onCheckedChange = onGpsChange)
            }
        }
        DataCard("Ekran teması", Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Koyu tema", modifier = Modifier.weight(1f))
                Switch(checked = darkMode, onCheckedChange = onDarkModeChange)
            }
        }
        DataCard("Android Automotive salt-okunur veri", Modifier.fillMaxWidth()) {
            Text(
                if (isAaos) "Araç içi Android Automotive algılandı. İzin verilirse yalnız açık ve desteklenen CarPropertyManager okumaları kullanılacak."
                else "Bu cihaz Android Automotive olarak tanınmıyor. OEM hız, menzil ve SOC erişimi sağlanamaz."
            )
            if (isAaos) Button(onClick = onAaosPermissionRequest) { Text("Araç okuma izinlerini iste") }
        }
        DataCard("Araç kumandaları", Modifier.fillMaxWidth()) {
            Text("Kilitleme, korna, klima ve diğer yazma komutları: yetkili OEM arayüzü yok, devre dışı.")
        }
        DataCard("Veri saklama", Modifier.fillMaxWidth()) {
            Text("Sadece özellik yer imleri Room veritabanında; GPS etkinleştirme tercihi DataStore'da yerel olarak tutulur. Konum geçmişi kaydedilmez; ölçümler sunucuya gönderilmez.")
        }
    }
}

private fun metricValueText(state: MetricState<Double>, unit: String): String = when (state) {
    is MetricState.Live -> "${format(state.metric.value)} ${unit.ifBlank { state.metric.unit }}"
    is MetricState.Stale -> "— ${unit}".trim()
    is MetricState.PermissionRequired -> "Yetki gerekli"
    is MetricState.Unsupported -> "Desteklenmiyor"
    is MetricState.Unavailable -> "Veri alınamıyor"
    is MetricState.Error -> "Hata"
    MetricState.Disconnected -> "Bağlantı yok"
}

private fun stateDescription(state: MetricState<Double>): String = when (state) {
    is MetricState.Live -> "${state.metric.source} · ${state.metric.providerId}"
    is MetricState.Stale -> "Güncel değil (${state.ageSeconds} sn)"
    is MetricState.PermissionRequired -> "İzin gerekli"
    is MetricState.Unsupported -> "Desteklenmiyor"
    is MetricState.Unavailable -> state.reason
    is MetricState.Error -> "Hata: ${state.code}"
    MetricState.Disconnected -> "Bağlantı yok"
}

private fun progressForGenericMetric(state: MetricState<Double>): Float = when (state) {
    is MetricState.Live -> (kotlin.math.abs(state.metric.value) / 100.0).toFloat().coerceIn(0.08f, 1f)
    else -> 0.08f
}

private fun progressForAbsMetric(state: MetricState<Double>, max: Double): Float = when (state) {
    is MetricState.Live -> (kotlin.math.abs(state.metric.value) / max).toFloat().coerceIn(0f, 1f)
    else -> 0f
}

@Composable
private fun colorForState(state: MetricState<Double>): Color = when (state) {
    is MetricState.Live -> {
        val v = state.metric.value
        when {
            state.metric.unit == "%" && v < 15 -> MaterialTheme.colorScheme.error
            state.metric.unit == "%" && v < 35 -> Palette.caution
            state.metric.unit == "%" -> Palette.positive
            state.metric.unit == "°C" && v >= 45 -> MaterialTheme.colorScheme.error
            else -> MaterialTheme.colorScheme.primary
        }
    }
    is MetricState.Stale -> Palette.caution
    is MetricState.PermissionRequired -> Palette.caution
    is MetricState.Error -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.outline
}

@Composable
private fun colorForTemperatureState(state: MetricState<Double>): Color = when (state) {
    is MetricState.Live -> when {
        state.metric.value <= 0 -> Color(0xFF7FC8FF)
        state.metric.value < 18 -> Color(0xFF8FDBFF)
        state.metric.value < 30 -> Palette.positive
        else -> Color(0xFFFFA766)
    }
    else -> MaterialTheme.colorScheme.surfaceVariant
}

@Composable
private fun colorForPowerState(state: MetricState<Double>): Color = when (state) {
    is MetricState.Live -> when {
        state.metric.value < 0 -> Palette.positive
        state.metric.value < 40 -> MaterialTheme.colorScheme.primary
        state.metric.value < 120 -> Palette.caution
        else -> MaterialTheme.colorScheme.error
    }
    else -> MaterialTheme.colorScheme.outline
}

private fun format(value: Double): String = if (kotlin.math.abs(value) >= 100) value.toInt().toString() else String.format(java.util.Locale.forLanguageTag("tr-TR"), "%.1f", value)
