package com.sealion7.companion

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.InfoOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.sealion7.core.model.VehicleSnapshot
import com.sealion7.feature.driving.AlertBanner
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.util.Locale

/** Reference catalog, not vehicle error codes. Data never implies an active fault. */
internal data class IndicatorReference(
    val number: Int,
    val title: String,
    val category: String,
    val manualPage: Int,
    val description: String,
    val getter: String,
    val evidenceType: String,
    val evidenceSource: String
)

internal data class FaultReference(
    val number: Int,
    val title: String,
    val system: String,
    val action: String,
    val manualPage: Int,
    val getter: String,
    val evidenceSource: String
)

private val indicatorIcons = intArrayOf(
    R.drawable.byd_indicator_01,
    R.drawable.byd_indicator_02,
    R.drawable.byd_indicator_03,
    R.drawable.byd_indicator_04,
    R.drawable.byd_indicator_05,
    R.drawable.byd_indicator_06,
    R.drawable.byd_indicator_07,
    R.drawable.byd_indicator_08,
    R.drawable.byd_indicator_09,
    R.drawable.byd_indicator_10,
    R.drawable.byd_indicator_11,
    R.drawable.byd_indicator_12,
    R.drawable.byd_indicator_13,
    R.drawable.byd_indicator_14,
    R.drawable.byd_indicator_15,
    R.drawable.byd_indicator_16,
    R.drawable.byd_indicator_17,
    R.drawable.byd_indicator_18,
    R.drawable.byd_indicator_19,
    R.drawable.byd_indicator_20,
    R.drawable.byd_indicator_21,
    R.drawable.byd_indicator_22,
    R.drawable.byd_indicator_23,
    R.drawable.byd_indicator_24,
    R.drawable.byd_indicator_25,
    R.drawable.byd_indicator_26,
    R.drawable.byd_indicator_27,
    R.drawable.byd_indicator_28,
    R.drawable.byd_indicator_29,
    R.drawable.byd_indicator_30,
    R.drawable.byd_indicator_31,
    R.drawable.byd_indicator_32,
    R.drawable.byd_indicator_33,
    R.drawable.byd_indicator_34,
    R.drawable.byd_indicator_35,
    R.drawable.byd_indicator_36,
    R.drawable.byd_indicator_37,
    R.drawable.byd_indicator_38,
    R.drawable.byd_indicator_39,
    R.drawable.byd_indicator_40,
    R.drawable.byd_indicator_41,
    R.drawable.byd_indicator_42,
    R.drawable.byd_indicator_43,
    R.drawable.byd_indicator_44,
    R.drawable.byd_indicator_45,
    R.drawable.byd_indicator_46,
    R.drawable.byd_indicator_47,
    R.drawable.byd_indicator_48
)

private fun loadCatalog(context: android.content.Context): Pair<List<IndicatorReference>, List<FaultReference>> {
    val text = context.assets.open("dashboard_warning_catalog.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val root = JSONObject(text)
    val indicators = root.getJSONArray("indicators")
    val warnings = root.getJSONArray("faultMessages")
    val list = (0 until indicators.length()).map { i ->
        val e = indicators.getJSONObject(i)
        IndicatorReference(
            number = e.getInt("number"),
            title = e.getString("title"),
            category = e.optString("category"),
            manualPage = e.optInt("manualPdfPage"),
            description = e.optString("description"),
            getter = e.optString("oemCandidateGetter"),
            evidenceType = e.optString("oemEvidenceType"),
            evidenceSource = e.optString("oemCandidateSource")
        )
    }
    val messages = (0 until warnings.length()).map { i ->
        val e = warnings.getJSONObject(i)
        FaultReference(
            number = e.getInt("number"),
            title = e.getString("title"),
            system = e.optString("system"),
            action = e.optString("instruction"),
            manualPage = e.optInt("manualPdfPage"),
            getter = e.optString("oemCandidateGetter"),
            evidenceSource = e.optString("oemCandidateSource")
        )
    }
    return list to messages
}

@Composable
private fun CatalogNotice(message: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.InfoOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun DashboardIndicatorCatalog(snapshot: VehicleSnapshot, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val indicators = remember(context) { loadCatalog(context).first }
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(0) }
    val filtered = indicators.filter { row ->
        val search = query.lowercase(Locale.forLanguageTag("tr-TR"))
        val okName = (row.title + " " + row.getter).lowercase(Locale.forLanguageTag("tr-TR")).contains(search)
        val isWarning = row.category.contains("uyarı", ignoreCase = true) || row.category.contains("arıza", ignoreCase = true)
        okName && when(kind) { 1 -> isWarning; 2 -> !isWarning; else -> true }
    }
    Column(modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("48 gösterge ve uyarı simgesi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        CatalogNotice("Bu simgeler BYD kullanım kılavuzu referansıdır. Hiçbiri şu anda doğrulanmış canlı OEM uyarısı değildir. Veri yokluğu 'arıza yok' anlamına gelmez.")
        if (snapshot.alerts.isNotEmpty()) {
            Text("Uygulamanın ayrı ölçüm/uyarı kaynağından gelen bildirimler", style = MaterialTheme.typography.labelMedium)
            AlertBanner(snapshot.alerts)
        }
        OutlinedTextField(
            value = query, onValueChange = {query = it}, modifier = Modifier.fillMaxWidth(),
            label = { Text("Gösterge / metot ara") }, singleLine = true
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tümü", "Uyarı/arıza", "Durum göstergesi").forEachIndexed { index, title ->
                FilterChip(selected = kind == index, onClick = {kind = index}, label = {Text(title)})
            }
        }
        Text("Gösterilen: ${filtered.size} / ${indicators.size} · Kılavuz s. 35–37 (PDF 40–42)", style = MaterialTheme.typography.labelMedium)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(filtered, key = { it.number }) { item ->
                DashboardIndicatorRow(item)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun DashboardIndicatorRow(item: IndicatorReference) {
    val bg = Color(0xFF1D2532) // Keep pale-mode icons legible in both app themes
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier.size(70.dp).background(bg, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(indicatorIcons[item.number - 1]),
                    contentDescription = item.title,
                    modifier = Modifier.size(55.dp)
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text("#${item.number} · Kılavuz PDF s. ${item.manualPage} · Canlı veri doğrulanmadı", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if(item.description.isNotBlank()) {
                    Text(item.description, style = MaterialTheme.typography.bodySmall)
                }
                if(item.getter.isNotBlank()) {
                    Text("Firmware adayı: ${item.getter}()", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                } else {
                    Text("Doğrudan OEM getter tespit edilemedi", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun DashboardFaultMessages(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val messages = remember(context) { loadCatalog(context).second }
    LazyColumn(modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("10 gösterge paneli arıza mesajı", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { CatalogNotice("Bunlar kılavuzdaki olası mesajlardır; araçta etkin oldukları saptanmış değildir. Aynı 'ADAS fonksiyonu sınırlı' metni üç farklı sistem için korunmuştur.") }
        items(messages, key = {it.number}) { item ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.InfoOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                    }
                    Text("${item.system} · Kılavuz PDF s. ${item.manualPage}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Kılavuz önerisi: ${item.action}", style = MaterialTheme.typography.bodySmall)
                    if (item.getter.isNotBlank()) Text("Firmware metot adayı: ${item.getter}()", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("Durum: doğrulanmamış · aktif arıza anlamına gelmez", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
