package com.sealion7.companion

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp class SealionApp : Application()
