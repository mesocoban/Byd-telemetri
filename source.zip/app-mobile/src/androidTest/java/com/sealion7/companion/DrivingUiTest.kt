package com.sealion7.companion

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.sealion7.core.model.*
import com.sealion7.feature.driving.DrivingDashboardScreen
import org.junit.Rule
import org.junit.Test

class DrivingUiTest {
 @get:Rule val rule=createComposeRule()
 @Test fun disconnectedDashboardShowsNoInventedNumbers(){
  rule.setContent {DrivingDashboardScreen(VehicleSnapshot(),MetricState.Disconnected,emptyList(),false)}
  rule.onNodeWithText("Doğrulanmış araç hızı alınamıyor").assertExists()
 }
}
