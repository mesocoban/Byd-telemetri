package com.sealion7.companion

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.sealion7.feature.catalog.FeatureCatalogLoader
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CatalogTest {
 @Test fun catalogContainsAll305ManualEntries(){
  val entries=FeatureCatalogLoader(InstrumentationRegistry.getInstrumentation().targetContext).load()
  assertEquals(305,entries.size)
  assertEquals(305,entries.map{it.id}.distinct().size)
  assertTrue(entries.none{it.apiVerified})
 }
}
