plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.plugin.compose")
 id("com.google.devtools.ksp")
 id("com.google.dagger.hilt.android")
}
android {
 namespace = "com.sealion7.companion"
 compileSdk = 37
 defaultConfig {
  applicationId = "com.sealion.bydtelemetre"
  minSdk = 29
  targetSdk = 37
  versionCode = 23
  versionName = "0.5.9.2"
  testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { compose = true }
 buildTypes { getByName("release") { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro") } }
}
dependencies {
 implementation(project(":core:model"))
 implementation(project(":core:designsystem"))
 implementation(project(":core:database"))
 implementation(project(":core:preferences"))
 implementation(project(":domain:vehicle"))
 implementation(project(":data:vehicle"))
 implementation(project(":feature:driving"))
 implementation(project(":feature:catalog"))
 implementation(project(":feature:diagnostics"))
 implementation(platform("androidx.compose:compose-bom:2026.09.00"))
 implementation("androidx.activity:activity-compose:1.13.0")
 implementation("androidx.compose.foundation:foundation")
 implementation("androidx.compose.animation:animation")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material:material-icons-extended")
 implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")
 implementation("androidx.hilt:hilt-navigation-compose:1.3.0")
 implementation("androidx.core:core-ktx:1.17.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
 implementation("com.google.dagger:hilt-android:2.60.1")
 ksp("com.google.dagger:hilt-compiler:2.60.1")
 testImplementation("junit:junit:4.13.2")
 androidTestImplementation(platform("androidx.compose:compose-bom:2026.09.00"))
 androidTestImplementation("androidx.compose.ui:ui-test-junit4")
 androidTestImplementation("androidx.test.ext:junit:1.3.0")
 debugImplementation("androidx.compose.ui:ui-tooling")
 debugImplementation("androidx.compose.ui:ui-test-manifest")
}
