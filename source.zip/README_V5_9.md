# BYD Telemetre V5.9

- Görünen ad: **BYD Telemetre**.
- Application ID: **com.sealion.bydtelemetre**.
- Java/Kotlin kaynak namespace: com.sealion7.companion (derleme uyumluluğu için korundu).
- Launcher simgesi: beş Android density seviyesi, 2 tema uyumlu PNG (normal/round).
- İzinler: konum ve AAOS okuma izinlerinde kullanıcı eylemiyle açılan açıklama penceresi + Android sistem izin penceresi.
- BYD imza/OEM izinleri için bilgilendirme; sistem izin veremediği için sahte onay yok.
- Tarama: 6.683 katalog girdisi, 226 seçilmiş manuel OEM aday getter. Kalan getter adlarının çoğu parametreli, ayar veya doğrulanmamış API. 6.683 girişin tamamını otomatik çağırmak güvenli değildir.
- Tarama sonucu/JSON+CSV: V5.8 davranışı korundu.
- Gerçek otomobil testi, tam Gradle derleme bu ortamda doğrulanmadı.
