plugins {
 id("com.android.library")
 id("org.jetbrains.kotlin.plugin.compose") }
android { namespace = "com.sealion7.core.designsystem"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 buildFeatures { compose = true }
}
dependencies {  
 implementation(platform("androidx.compose:compose-bom:2026.09.00"))
 implementation("androidx.compose.foundation:foundation")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material:material-icons-extended")
  }
