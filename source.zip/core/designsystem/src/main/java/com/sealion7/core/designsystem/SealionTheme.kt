package com.sealion7.core.designsystem

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*

object Palette {
 val night = Color(0xFF080D16)
 val navy = Color(0xFF131D2C)
 val electric = Color(0xFF7BDAE8)
 val positive = Color(0xFF8FD5B8)
 val caution = Color(0xFFFFC76D)
 val ink = Color(0xFFECF3F9)
}
object CardTokens { val radius = 22.dp; val padding = 18.dp; val gap = 12.dp }
object MotionSpec { const val numberChangeMillis = 320; const val fillMillis = 420 }
private val dark = darkColorScheme(primary=Palette.electric,onPrimary=Palette.night,
 background=Palette.night,onBackground=Palette.ink,surface=Palette.navy,
 onSurface=Palette.ink,secondary=Palette.positive,error=Color(0xFFFF9797))
private val light = lightColorScheme(primary=Color(0xFF055365),
 background=Color(0xFFF2F6F8),surface=Color.White,secondary=Color(0xFF24694F))
@Composable fun SealionTheme(darkMode: Boolean=true, content: @Composable ()->Unit) =
 MaterialTheme(colorScheme=if(darkMode) dark else light, content=content)

@Composable fun DataCard(title:String, modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
 Surface(modifier, shape=RoundedCornerShape(CardTokens.radius),color=MaterialTheme.colorScheme.surface,
  tonalElevation=2.dp) {
  Column(Modifier.padding(CardTokens.padding),verticalArrangement=Arrangement.spacedBy(9.dp)) {
   Text(title, style=MaterialTheme.typography.labelLarge, color=MaterialTheme.colorScheme.onSurfaceVariant)
   content()
  }
 }
}
