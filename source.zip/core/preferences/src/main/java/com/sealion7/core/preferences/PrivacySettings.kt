package com.sealion7.core.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import dagger.hilt.android.qualifiers.ApplicationContext

private val Context.dataStore by preferencesDataStore(name="privacy")
class PrivacySettings @Inject constructor(@ApplicationContext private val context: Context) {
 private val phoneGps = booleanPreferencesKey("phone_gps_opt_in")
 private val darkTheme = booleanPreferencesKey("theme_dark")
 val phoneGpsEnabled: Flow<Boolean> = context.dataStore.data.map { it[phoneGps] ?: false }
 val darkMode: Flow<Boolean> = context.dataStore.data.map { it[darkTheme] ?: true }
 suspend fun setDarkMode(enabled:Boolean) {context.dataStore.edit{it[darkTheme]=enabled}}
 suspend fun setPhoneGpsEnabled(enabled: Boolean) {
  context.dataStore.edit { it[phoneGps] = enabled }
 }
}
