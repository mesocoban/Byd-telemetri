plugins {
 id("com.android.library")  }
android { namespace = "com.sealion7.core.preferences"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }

}
dependencies { implementation("androidx.datastore:datastore-preferences:1.2.0")
 implementation("com.google.dagger:hilt-android:2.60.1")  }
