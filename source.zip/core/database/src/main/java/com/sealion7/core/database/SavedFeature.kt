package com.sealion7.core.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Entity(tableName="saved_features")
data class SavedFeature(@PrimaryKey val id: String, val savedAtEpochMs: Long)

@Dao interface SavedFeatureDao {
 @Query("SELECT * FROM saved_features ORDER BY savedAtEpochMs DESC")
 fun observe(): Flow<List<SavedFeature>>
 @Insert(onConflict = OnConflictStrategy.REPLACE)
 suspend fun add(value: SavedFeature)
 @Query("DELETE FROM saved_features WHERE id = :id")
 suspend fun remove(id: String)
}

@Database(entities=[SavedFeature::class],version=1,exportSchema=false)
abstract class SealionDb : RoomDatabase() { abstract fun savedFeatures(): SavedFeatureDao }

@Module @InstallIn(SingletonComponent::class)
object DatabaseModule {
 @Provides @Singleton fun database(@ApplicationContext context: Context): SealionDb =
  Room.databaseBuilder(context,SealionDb::class.java,"sealion_catalog.db").build()
 @Provides fun dao(db: SealionDb): SavedFeatureDao = db.savedFeatures()
}
