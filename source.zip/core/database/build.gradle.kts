plugins {
 id("com.android.library") 
 id("com.google.devtools.ksp")
 id("com.google.dagger.hilt.android") }
android { namespace = "com.sealion7.core.database"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }

}
dependencies { implementation("androidx.room:room-runtime:2.8.4")
 implementation("androidx.room:room-ktx:2.8.4")
 ksp("androidx.room:room-compiler:2.8.4")
 implementation("javax.inject:javax.inject:1")
 implementation("com.google.dagger:hilt-android:2.60.1")
 ksp("com.google.dagger:hilt-compiler:2.60.1")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")  }
