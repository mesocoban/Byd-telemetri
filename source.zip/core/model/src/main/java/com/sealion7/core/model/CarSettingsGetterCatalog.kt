package com.sealion7.core.model

/** Source: BydCarSettings.apk DEX signatures, NOT verified vehicle outputs.
 * Each entry is deliberately read-only and requires per-module OEM permission.
 */
data class CarSettingsGetter(
    val id: String, val category: String, val title: String,
    val className: String, val method: String, val returnDescriptor: String,
    val permission: String, val requiresWheelIndex: Boolean = false
)
object CarSettingsGetterCatalog {
    val entries: List<CarSettingsGetter> = listOf(
        CarSettingsGetter("CS-01", "Sürüş", "Sürüş modu", "android.hardware.bydauto.setting.BYDAutoSettingDevice", "getDriveMode", "I", "android.permission.BYDAUTO_SETTING_GET", false),
        CarSettingsGetter("CS-02", "Sürüş", "Rejeneratif frenleme ayarı", "android.hardware.bydauto.setting.BYDAutoSettingDevice", "getEnergyFeedback", "I", "android.permission.BYDAUTO_SETTING_GET", false),
        CarSettingsGetter("CS-03", "Sürüş", "Rejeneratif frenleme ayarı (enerji modülü)", "android.hardware.bydauto.energy.BYDAutoEnergyDevice", "getEnergyFeedback", "I", "android.permission.BYDAUTO_ENERGY_GET", false),
        CarSettingsGetter("CS-04", "Sürüş", "Rejeneratif frenleme ayarı (gösterge)", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getEnergyFeedback", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-05", "Sürüş", "Vites", "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice", "getCurrentGear", "I", "android.permission.BYDAUTO_GEARBOX_GET", false),
        CarSettingsGetter("CS-06", "Sürüş", "Fren pedalı modu", "android.hardware.bydauto.setting.BYDAutoSettingDevice", "getBrakePedalMode", "I", "android.permission.BYDAUTO_SETTING_GET", false),
        CarSettingsGetter("CS-07", "Enerji", "Anlık elektrik tüketimi", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getInstantElecConValue", "F", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-08", "Enerji", "Yolculuk ortalama tüketimi", "android.hardware.bydauto.energy.BYDAutoEnergyDevice", "getTripEnergyConAvg", "F", "android.permission.BYDAUTO_ENERGY_GET", false),
        CarSettingsGetter("CS-09", "Enerji", "Son 50 km ortalama tüketim", "android.hardware.bydauto.energy.BYDAutoEnergyDevice", "getLast50KMElectricConAvg", "F", "android.permission.BYDAUTO_ENERGY_GET", false),
        CarSettingsGetter("CS-10", "Enerji", "Mevcut yolculuk elektrik tüketimi", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getCurrentTripElec", "F", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-11", "Enerji", "Mevcut yolculuk elektrik tüketimi birimi", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getCurrentTripElecUnit", "I", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-12", "Enerji", "Mevcut yolculuk mesafesi", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getCurrentTripMileage", "F", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-13", "Enerji", "Mevcut yolculuk mesafesi birimi", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getCurrentTripMileageUnit", "I", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-14", "Enerji", "Toplam kilometre", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getTotalMileageValue", "F", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-15", "Enerji", "Batarya SOC", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getSOCBatteryPercentage", "I", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-16", "Enerji", "Batarya paketi enerji değeri", "android.hardware.bydauto.statistic.BYDAutoStatisticDevice", "getBatteryPackEnergy", "F", "android.permission.BYDAUTO_STATISTIC_GET", false),
        CarSettingsGetter("CS-17", "Şarj", "Şarj gücü", "android.hardware.bydauto.charging.BYDAutoChargingDevice", "getChargingPower", "D", "android.permission.BYDAUTO_CHARGING_GET", false),
        CarSettingsGetter("CS-18", "Şarj", "Kalan şarj süresi", "android.hardware.bydauto.charging.BYDAutoChargingDevice", "getChargingRestTime", "[I", "android.permission.BYDAUTO_CHARGING_GET", false),
        CarSettingsGetter("CS-19", "Şarj", "Şarj bağlantı durumu", "android.hardware.bydauto.charging.BYDAutoChargingDevice", "getChargingGunState", "I", "android.permission.BYDAUTO_CHARGING_GET", false),
        CarSettingsGetter("CS-20", "Şarj", "Şarj voltajı", "android.hardware.bydauto.charging.BYDAutoChargingDevice", "getChargeVoltage", "I", "android.permission.BYDAUTO_CHARGING_GET", false),
        CarSettingsGetter("CS-21", "TPMS", "Lastik basıncı", "android.hardware.bydauto.tyre.BYDAutoTyreDevice", "getTyrePressureValue", "I", "android.permission.BYDAUTO_TYRE_GET", true),
        CarSettingsGetter("CS-22", "TPMS", "Lastik basıncı uyarısı", "android.hardware.bydauto.tyre.BYDAutoTyreDevice", "getTyrePressureWarn", "I", "android.permission.BYDAUTO_TYRE_GET", true),
        CarSettingsGetter("CS-23", "TPMS", "Lastik sinyali arızası", "android.hardware.bydauto.tyre.BYDAutoTyreDevice", "getTyrePressureSysFailHint", "I", "android.permission.BYDAUTO_TYRE_GET", false),
        CarSettingsGetter("CS-24", "TPMS", "Gösterge TPMS arıza lambası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getTyrePressureSYSFailWarnLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-25", "Arıza", "ABS uyarı lambası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getABSFaultWarningLight", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-26", "Arıza", "Fren sistemi arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getBrakeSysFaultLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-27", "Arıza", "Hava yastığı arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getSRSFaultWarningLight", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-28", "Arıza", "ESC arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getESPFailWarnLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-29", "Arıza", "Batarya arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getPowerBatFailWarnLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-30", "Arıza", "Ön far arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getHeadlampFailWarnLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-31", "Arıza", "Direksiyon arızası", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getSteeringSYSFailWarnLightState", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-32", "Arıza", "Toplu arıza kodları", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getMalfunctionInfos", "[I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-33", "Gösterge", "Gösterge ekran parlaklığı", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getInstrumentBrightness", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
        CarSettingsGetter("CS-34", "Gösterge", "Gösterge teması", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", "getInstrumentTheme", "I", "android.permission.BYDAUTO_INSTRUMENT_GET", false),
    )
    init { require(entries.size == 34); require(entries.map { it.id }.distinct().size == 34) }
}
