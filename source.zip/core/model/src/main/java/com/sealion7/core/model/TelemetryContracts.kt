package com.sealion7.core.model

/** Design-time API contract fields derived from the supplied catalog, NOT vendor SDK identifiers. */
enum class FieldType { NUMBER, STATE, BOOLEAN, LOCATION, ALERTS }
data class VehicleField(val id:String,val labelTr:String,val unitOrType:String,val sourceRule:String,val fieldType:FieldType)
object VehicleFieldRegistry {
 val all:List<VehicleField> = listOf(
  VehicleField("vehicle.speed", "Araç hızı", "km/sa", "Araç/izinli donanım; telefon GPS hızı ayrı kaynak", FieldType.NUMBER),
  VehicleField("vehicle.range", "Kalan menzil", "km", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("battery.soc", "Batarya SOC", "%", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("battery.status", "Şarj/deşarj durumu", "enum", "Araç/BYD yetkili veri", FieldType.STATE),
  VehicleField("battery.estimated_remaining_charge_time", "Şarja kalan süre", "dakika", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("battery.power", "Anlık güç / güç ölçer", "kW", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("power.traction", "Çekiş gücü", "kW", "Doğrulanmış motor ölçümü; net batarya gücünden türetilmez", FieldType.NUMBER),
  VehicleField("power.battery_discharge", "Batarya tüketim gücü", "kW", "AAOS belgeli deşarj oranı veya doğrulanmış OEM ölçümü", FieldType.NUMBER),
  VehicleField("power.regen", "Rejenerasyon gücü", "kW", "Yalnız doğrulanmış geri kazanım ölçümü; ayar kademesi kullanılmaz", FieldType.NUMBER),
  VehicleField("battery.regen_level", "Rejeneratif frenleme seviyesi", "enum", "Araç/BYD yetkili veri", FieldType.STATE),
  VehicleField("vehicle.gear", "Vites", "P/R/N/D", "Araç/BYD yetkili veri", FieldType.STATE),
  VehicleField("vehicle.drive_mode", "Sürüş modu", "Konfor/Ekonomik/Spor/Kar", "Araç/BYD yetkili veri", FieldType.STATE),
  VehicleField("vehicle.outside_temp", "Dış sıcaklık", "°C", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("vehicle.odometer", "Toplam kilometre", "km", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("vehicle.trip1", "Kilometre 1", "km", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("vehicle.trip2", "Kilometre 2", "km", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("tires.front_left", "Sol ön lastik basıncı", "kPa/bar", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("tires.front_right", "Sağ ön lastik basıncı", "kPa/bar", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("tires.rear_left", "Sol arka lastik basıncı", "kPa/bar", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("tires.rear_right", "Sağ arka lastik basıncı", "kPa/bar", "Araç/BYD yetkili veri", FieldType.NUMBER),
  VehicleField("climate.cabin_temperature", "Kabin sıcaklığı", "°C", "Yalnız doğrulanmış kaynak", FieldType.NUMBER),
  VehicleField("climate.target_driver_temperature", "Sürücü sıcaklık hedefi", "°C", "Yalnız doğrulanmış kaynak", FieldType.NUMBER),
  VehicleField("climate.target_passenger_temperature", "Yolcu sıcaklık hedefi", "°C", "Yalnız doğrulanmış kaynak", FieldType.NUMBER),
  VehicleField("climate.fan_speed", "Klima fanı", "kademe", "Yalnız doğrulanmış kaynak", FieldType.NUMBER),
  VehicleField("climate.mode", "Klima modu", "enum", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("vehicle.doors", "Kapıların durumu", "enum/list", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("vehicle.windows", "Camların durumu", "enum/list", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("vehicle.locked", "Merkezi kilit durumu", "bool", "Yalnız doğrulanmış kaynak", FieldType.BOOLEAN),
  VehicleField("vehicle.seat_heater", "Koltuk ısıtma durumu", "enum", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("vehicle.alerts", "Arıza ve uyarılar", "list", "Yalnız doğrulanmış kaynak", FieldType.ALERTS),
  VehicleField("adas.acc", "AHSS durumu ve hedef hız", "enum + km/sa", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("adas.aeb", "AEB durumu", "enum", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("adas.lane", "LDA/ELKA uyarıları", "enum", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("adas.tsr", "TSR işaretleri", "km/sa", "Yalnız doğrulanmış kaynak", FieldType.NUMBER),
  VehicleField("adas.blindspot", "Kör nokta uyarıları", "enum", "Yalnız doğrulanmış kaynak", FieldType.STATE),
  VehicleField("vehicle.air_quality_pm25", "PM2.5", "µg/m³ (cihaz birimi doğrulanmalı)", "Yalnız opsiyon ve izinli kaynak", FieldType.NUMBER),
  VehicleField("vehicle.location", "Konum", "enlem/boylam", "Araç/telefon kaynakları ayrı etiketlenir", FieldType.LOCATION),
  VehicleField("phone.gps_speed", "Telefon GPS hızı", "km/sa", "Android konum API; araç ölçümü değildir", FieldType.NUMBER),
 )
 init { require(all.size==38); require(all.map{it.id}.distinct().size==38) }
 fun get(id:String):VehicleField? = all.firstOrNull{it.id==id}
}
