package com.sealion7.core.model

import java.time.Instant

/** An OEM getter result is raw evidence, NOT automatically a valid measurement or fault. */
enum class OemRawStatus {
    NEEDS_AUTHORIZATION, SDK_CLASS_ABSENT, DEVICE_NOT_READY, METHOD_NOT_VERIFIED,
    NO_RESPONSE, RAW_VALUE_UNVERIFIED
}

data class OemRawObservation(
    val id: String,
    val title: String,
    val method: String,
    val className: String,
    val permission: String,
    val status: OemRawStatus,
    val rawValue: String? = null,
    val observedAt: Instant? = null,
    val explanation: String = "",
)

/** OEM flags are untyped integers until proven otherwise; unknown is never equal to CLEAR. */
object CarSettingsRawSafety {
    fun statusLabel(status: OemRawStatus): String = when (status) {
        OemRawStatus.NEEDS_AUTHORIZATION -> "OEM okuma izni gerekli"
        OemRawStatus.SDK_CLASS_ABSENT -> "SDK sınıfı cihazda bulunamadı"
        OemRawStatus.DEVICE_NOT_READY -> "OEM cihaz servisi hazır değil"
        OemRawStatus.METHOD_NOT_VERIFIED -> "Parametre/tekerlek eşlemesi doğrulanmadı"
        OemRawStatus.NO_RESPONSE -> "Getter yanıtı alınmadı"
        OemRawStatus.RAW_VALUE_UNVERIFIED -> "Ham cevap alındı, anlamı henüz doğrulanmadı"
    }
    fun safeRawDisplay(raw: Any?): String? = when(raw) {
        is IntArray -> raw.take(32).joinToString(",", "[", if (raw.size > 32) ",…]" else "]")
        is ByteArray -> null // never dump arbitrary binary blobs
        is Number -> raw.toDouble().takeIf { it.isFinite() }?.let { raw.toString().take(120) }
        is Boolean -> raw.toString()
        else -> null
    }
    /** Signed or unsigned levels must never be guessed to Standart/Yüksek. */
    fun confirmedRegenMode(raw: Int?, verifiedStandard: Int?, verifiedHigh: Int?): String? =
        if (raw == null || verifiedStandard == null || verifiedHigh == null || verifiedStandard == verifiedHigh) null
        else when (raw) { verifiedStandard -> "Standart"; verifiedHigh -> "Yüksek"; else -> null }
    fun confirmedGear(raw: Int?, verifiedCodes: Map<Int,String>): String? =
        raw?.let { verifiedCodes[it]?.takeIf { gear -> gear in setOf("P", "R", "N", "D") } }
    fun confirmedDriveMode(raw: Int?, verifiedCodes: Map<Int,String>): String? =
        raw?.let { verifiedCodes[it]?.takeIf { mode -> mode in setOf("ECO", "NORMAL", "SPORT", "SNOW", "KAR") } }
}
