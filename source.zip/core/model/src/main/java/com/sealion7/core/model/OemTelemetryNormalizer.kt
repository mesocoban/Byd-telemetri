package com.sealion7.core.model

/** Fail-closed plausibility checks; these bounds are guards, not signal verification. */
object OemTelemetryNormalizer {
 fun speed(value: Double?): Double? = value?.takeIf { it.isFinite() && it in 0.0..350.0 }
 fun soc(value: Double?): Double? = value?.takeIf { it.isFinite() && it in 0.0..100.0 }
 fun range(value: Double?): Double? = value?.takeIf { it.isFinite() && it in 1.0..2000.0 }
 fun odometer(value: Double?): Double? = value?.takeIf { it.isFinite() && it in 0.1..5000000.0 }
 /** TS outside temperature zero is ambiguous in source; don't assert 0 C without another source. */
 fun tsOutsideTemperature(value: Double?): Double? = value?.takeIf { it.isFinite() && it in -50.0..60.0 && it != 0.0 }
 fun chargePower(value: Double?, chargingConfirmed: Boolean): Double? =
  if(chargingConfirmed) value?.takeIf { it.isFinite() && it in 0.0..350.0 } else null
}
