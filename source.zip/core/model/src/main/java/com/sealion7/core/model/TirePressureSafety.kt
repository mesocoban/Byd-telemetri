package com.sealion7.core.model

import java.time.Instant

/**
 * A per-wheel LOWER tire pressure limit supplied by an authorized car property configuration.
 * Never populate from the app's visual color bands, a guessed value or a different wheel.
 */
data class TirePressureLimit(
    val wheel: MetricKey,
    val minimumKpa: Double,
    val source: DataSource,
    val providerId: String,
    val evidence: String
)

enum class TirePressureStatus {
    LOW, WITHIN_RECOMMENDED_LOWER_LIMIT, LIMIT_UNKNOWN, READING_UNAVAILABLE, READING_STALE, INVALID_READING
}

data class TirePressureAssessment(
    val wheel: MetricKey,
    val status: TirePressureStatus,
    val pressureKpa: Double?,
    val minimumKpa: Double?,
    val source: String,
    val explanation: String
)

/**
 * Display-level safety evaluation, not an OEM TPMS warning flag or a substitute for the car's
 * instrument cluster. No active warning is raised without a fresh, valid wheel reading AND
 * a manufacturer-defined bound for the same source/provider/wheel.
 */
object TirePressureSafety {
    val wheelKeys = listOf(MetricKey.TIRE_FL, MetricKey.TIRE_FR, MetricKey.TIRE_RL, MetricKey.TIRE_RR)

    fun assess(snapshot: VehicleSnapshot, now: Instant = Instant.now()): List<TirePressureAssessment> =
        wheelKeys.map { key ->
            val state = snapshot.number(key)
            when (state) {
                is MetricState.Live -> {
                    val reading = state.metric
                    val value = reading.value
                    val matchedLimit = snapshot.tirePressureLimits[key]?.takeIf {
                        it.wheel == key && it.source == reading.source && it.providerId == reading.providerId &&
                            it.minimumKpa.isFinite() && it.minimumKpa in 50.0..500.0 &&
                            it.evidence.isNotBlank()
                    }
                    val receivedAge = now.epochSecond - reading.receivedAt.epochSecond
                    val sensorAge = now.epochSecond - reading.sourceTimestamp.epochSecond
                    val fresh = receivedAge in 0..reading.freshnessSeconds && sensorAge in 0..reading.freshnessSeconds
                    val valid = value.isFinite() && value > 0 && value <= 650 &&
                        reading.unit == "kPa" && reading.quality == DataQuality.VALID &&
                        reading.accessScope == AccessScope.OEM_READ && reading.source != DataSource.PHONE_GPS
                    when {
                        !valid -> TirePressureAssessment(key, TirePressureStatus.INVALID_READING, null, null,
                            reading.providerId, "Basınç/birim/kalite doğrulanmadı; uyarı oluşturulmadı")
                        !fresh -> TirePressureAssessment(key, TirePressureStatus.READING_STALE, value, null,
                            reading.providerId, "Basınç ölçümü güncel değil; aktif uyarı oluşturulmadı")
                        matchedLimit == null -> TirePressureAssessment(key, TirePressureStatus.LIMIT_UNKNOWN, value, null,
                            reading.providerId, "Üretici alt basınç sınırı okunamadı; düşük basınç değerlendirilemiyor")
                        value < matchedLimit.minimumKpa -> TirePressureAssessment(key, TirePressureStatus.LOW,
                            value, matchedLimit.minimumKpa, reading.providerId,
                            "Basınç, aynı lastik için AAOS'un bildirdiği üretici alt sınırının altında")
                        else -> TirePressureAssessment(key, TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT,
                            value, matchedLimit.minimumKpa, reading.providerId,
                            "Basınç üretici alt sınırının altında değil; bu, tüm lastik koşullarının güvenli olduğu anlamına gelmez")
                    }
                }
                is MetricState.Stale -> TirePressureAssessment(key, TirePressureStatus.READING_STALE,
                    state.metric.value, null, state.metric.providerId, "Ölçüm eski; aktif basınç uyarısı oluşturulmadı")
                is MetricState.Error -> TirePressureAssessment(key, TirePressureStatus.READING_UNAVAILABLE,
                    null, null, "—", "Basınç okuma hatası: ${state.code}")
                is MetricState.PermissionRequired -> TirePressureAssessment(key, TirePressureStatus.READING_UNAVAILABLE,
                    null, null, "—", "Basınç okumak için araç izni gerekiyor")
                else -> TirePressureAssessment(key, TirePressureStatus.READING_UNAVAILABLE,
                    null, null, "—", "Basınç ölçümü yok; aktif uyarı oluşturulmadı")
            }
        }

    fun alerts(snapshot: VehicleSnapshot, now: Instant = Instant.now()): List<VehicleAlert> = assess(snapshot, now)
        .filter { it.status == TirePressureStatus.LOW }
        .map { a ->
            VehicleAlert(
                code = "TPMS_LOW_${a.wheel.name}",
                message = "${a.wheel.title} lastik basıncı düşük: ${a.pressureKpa?.toInt()} kPa " +
                    "(üretici alt sınırı ${a.minimumKpa?.toInt()} kPa; AAOS ölçümüne göre)",
                severity = Severity.WARNING,
                source = DataSource.AAOS_CAR_HARDWARE,
                observedAt = now
            )
        }
}
