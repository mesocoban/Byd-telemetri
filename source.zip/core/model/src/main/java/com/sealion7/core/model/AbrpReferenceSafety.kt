package com.sealion7.core.model

import java.time.Instant

/** ABRP-SL7 observational evidence: P=1, N=3, D=4. Reverse=2 was only inferred, NOT observed. */
object AbrpReferenceSafety {
    fun shiftCode(raw: Double?): Int? = raw?.takeIf { it.isFinite() && it >= 0.0 && it <= 255.0 && it % 1.0 == 0.0 }?.toInt()
    fun observedGear(raw: Double?): String? = when (shiftCode(raw)) {
        1 -> "P"
        3 -> "N"
        4 -> "D"
        else -> null // 2/R is NOT confirmed, neither is code 0
    }
    fun confirmedParkSelection(raw: Double?): Boolean? = when (shiftCode(raw)) {
        1 -> true
        3, 4 -> false // means P is not selected; NOT evidence the car is moving
        else -> null
    }
    fun chargerCode(raw: Double?): Int? = shiftCode(raw) // raw ONLY; no >0=charging or 2=DC assumption
}

/** A read-only TS client reconnect scheduler; never touches private SDK singleton fields. */
class TsReconnectPolicy {
    private var lastAttemptAt: Long = -1L
    private var failures: Int = 0
    var attemptedConnections: Int = 0
        private set
    var unboundPolls: Int = 0
        private set
    var lastBoundAt: Long? = null
        private set

    fun onBound(nowMs: Long) {
        failures = 0
        unboundPolls = 0
        lastBoundAt = nowMs
        lastAttemptAt = -1L
    }
    fun onUnbound() { unboundPolls++ }
    fun retryDelayMs(): Long = when (failures) {
        0 -> 0L
        1 -> 3000L
        2 -> 6000L
        3 -> 12000L
        else -> 30000L
    }
    fun waitMs(nowMs: Long): Long = if (lastAttemptAt < 0L) 0L
        else (retryDelayMs() - (nowMs - lastAttemptAt)).coerceAtLeast(0L)
    fun canConnect(nowMs: Long): Boolean = waitMs(nowMs) == 0L
    fun markAttempt(nowMs: Long) {
        attemptedConnections++
        failures++
        lastAttemptAt = nowMs
    }
    fun reset(): Unit { failures = 0; lastAttemptAt = -1L }
}

enum class SourceSessionPhase { NO_PERMISSION, SDK_MISSING, WAITING_TO_RETRY, CONNECTING, BOUND_NO_DATA, LIVE, READ_ERROR }
data class SourceSessionDiagnostic(
    val providerId: String,
    val phase: SourceSessionPhase,
    val connectionAttempts: Int,
    val unboundPolls: Int,
    val nextRetryMs: Long,
    val description: String,
    val observedAt: Instant = Instant.now(),
)

/** Optional user-authorized PHONE location, never confused with OEM vehicle navigation. */
data class PhoneGpsFix(
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double?,
    val accuracyMeters: Float,
    val measuredAt: Instant,
)
sealed interface PhoneGpsFixState {
    data class Fresh(val fix: PhoneGpsFix) : PhoneGpsFixState
    data class Stale(val ageSeconds: Long) : PhoneGpsFixState
    data class Unavailable(val reason: String) : PhoneGpsFixState
    data object PermissionRequired : PhoneGpsFixState
}
object PhoneGpsFixSafety {
    fun validated(latitude: Double, longitude: Double, altitude: Double?, accuracy: Float, timestamp: Instant): PhoneGpsFix? {
        if (!latitude.isFinite() || latitude !in -90.0..90.0 || !longitude.isFinite() || longitude !in -180.0..180.0) return null
        if (!accuracy.isFinite() || accuracy !in 0.0f..150.0f) return null
        return PhoneGpsFix(latitude, longitude, altitude?.takeIf { it.isFinite() && it in -500.0..9000.0 }, accuracy, timestamp)
    }
}
