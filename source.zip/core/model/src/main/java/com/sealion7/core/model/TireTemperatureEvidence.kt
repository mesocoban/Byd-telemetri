package com.sealion7.core.model

/**
 * Evidence only. ts-framework.jar CarBodyManager.getTyreTemperatureValue(): Int and
 * getTyreTemperatureState(): Int are present but the firmware index does not
 * establish wheel position, encoding, units or permission compatibility.
 * No live per-wheel temperature must be invented from those global getters.
 */
object TireTemperatureEvidence {
 val keys = listOf(MetricKey.TIRE_TEMP_FL, MetricKey.TIRE_TEMP_FR,
  MetricKey.TIRE_TEMP_RL, MetricKey.TIRE_TEMP_RR)
 const val providerId = "ts-carbody-temperature-firmware-evidence"
 const val reason = "TS firmware getTyreTemperatureValue() bulundu; dört lastiğe eşleme, ölçek ve birim henüz doğrulanmadı"
 fun capabilities(): List<VehicleCapability> = keys.map { key ->
  VehicleCapability(key = key, canRead = false, canWrite = false,
   constraints = listOf(reason,"Doğrulanmış tekerlek kimliği ve OEM okuma yetkisi gerekli"),
   requiredScopes = listOf(AccessScope.OEM_READ), providerId = providerId,
   equipmentOption = false, supportStatus = SupportStatus.NEEDS_INTEGRATION)
 }
}
