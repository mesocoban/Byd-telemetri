package com.sealion7.core.model

/** Maps verified GPS ground-track bearing to Turkish compass labels; not magnetic compass heading. */
fun gpsBearingDirectionTr(degrees: Double): String {
    require(degrees.isFinite()) { "Bearing must be finite" }
    val sectors = arrayOf("K", "KD", "D", "GD", "G", "GB", "B", "KB")
    val index = (((degrees % 360.0 + 360.0) % 360.0 + 22.5) / 45.0).toInt() % sectors.size
    return sectors[index]
}
