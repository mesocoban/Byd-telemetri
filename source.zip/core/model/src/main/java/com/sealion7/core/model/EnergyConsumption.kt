package com.sealion7.core.model

import java.time.Duration
import java.time.Instant
import kotlin.math.abs

/**
 * Read-only arithmetic on explicitly verified, *current* metric readings.
 *
 * kW = kWh / h; km/h = km / h; hence kWh/100 km = 100 * kW / (km/h).
 * This is DC BATTERY consumption (may include cabin/auxiliary loads), NOT motor power.
 * Low speeds are excluded because the distance denominator approaches zero.
 */
object EnergyConsumptionMath {
    const val MIN_SPEED_KMH = 10.0
    const val MAX_SAMPLE_GAP_SECONDS = 10.0

    fun instantaneousKwhPer100Km(dischargeKw: Double?, vehicleSpeedKmh: Double?): Double? {
        if (dischargeKw == null || vehicleSpeedKmh == null) return null
        if (!dischargeKw.isFinite() || !vehicleSpeedKmh.isFinite()) return null
        if (dischargeKw !in 0.0..1000.0 || vehicleSpeedKmh !in MIN_SPEED_KMH..350.0) return null
        return (100.0 * dischargeKw / vehicleSpeedKmh).takeIf { it.isFinite() && it >= 0.0 }
    }

    fun energyKwh(meanPowerKw: Double, seconds: Double): Double? =
        if (meanPowerKw.isFinite() && meanPowerKw in 0.0..1000.0 &&
            seconds.isFinite() && seconds > 0.0 && seconds <= MAX_SAMPLE_GAP_SECONDS)
            meanPowerKw * seconds / 3600.0 else null

    fun averageKwhPer100Km(energyKwh: Double, distanceKm: Double): Double? =
        if (energyKwh.isFinite() && energyKwh >= 0.0 && distanceKm.isFinite() && distanceKm >= 0.05)
            (100.0 * energyKwh / distanceKm).takeIf { it.isFinite() } else null
}

/**
 * In-memory, current observation session only. No claim about the entire Trip A / Trip B
 * (which may have been running since before this app launched), or a past completed trip.
 * No persistent location or driving history is stored.
 *
 * The tracker is created INSIDE the repository's collecting flow. When collection stops
 * the next session begins from zero and cannot fill an unobserved gap with guessed energy.
 */
class EnergyConsumptionSession {
    private data class Input(val at: Instant, val kw: Double, val speedKmh: Double,
                             val battery: VehicleMetric<Double>, val speed: VehicleMetric<Double>)
    private data class Regen(val at: Instant, val powerKw: Double, val metric: VehicleMetric<Double>)
    private data class TripWindow(var lastKm: Double? = null, var energyKwh: Double = 0.0,
                                  var distanceKm: Double = 0.0, var samples: Int = 0)

    private var previous: Input? = null
    private var lastRegen: Regen? = null
    private val tripA = TripWindow()
    private val tripB = TripWindow()
    private var sessionEnergyKwh = 0.0
    private var sessionDistanceKm = 0.0
    private var intervals = 0
    private var regenEnergyKwh = 0.0
    private var regenIntervals = 0

    fun apply(snapshot: VehicleSnapshot, now: Instant = Instant.now()): VehicleSnapshot {
        val consumption = snapshot.number(MetricKey.BATTERY_CONSUMPTION_POWER)
        val speed = snapshot.number(MetricKey.VEHICLE_SPEED)
        val current = validPair(consumption, speed, now)
        val derived = mutableMapOf<MetricKey, MetricState<Double>>()

        derived[MetricKey.INSTANT_CONSUMPTION] = if (current == null) {
            MetricState.Unavailable("Anlık tüketim için güncel batarya deşarj gücü ve araç hızı gerekli")
        } else {
            val value = EnergyConsumptionMath.instantaneousKwhPer100Km(current.kw, current.speedKmh)
            if (value == null) MetricState.Unavailable("Anlık tüketim 10 km/sa altında veya geçersiz veride hesaplanmaz")
            else derivedMetric(MetricKey.INSTANT_CONSUMPTION, value, now, current.battery, current.speed,
                "Hesaplanan: 100 × batarya deşarj kW / araç hızı km/sa")
        }

        if (current == null) {
            previous = null // no integration over missing telemetry or disconnections
            tripA.lastKm = null
            tripB.lastKm = null
        } else {
            val old = previous
            val dt = old?.let { Duration.between(it.at, now).toMillis() / 1000.0 }
            val increment = if (old != null && dt != null && dt > 0.0 && dt <= EnergyConsumptionMath.MAX_SAMPLE_GAP_SECONDS &&
                old.battery.source == current.battery.source && old.battery.providerId == current.battery.providerId &&
                old.speed.source == current.speed.source && old.speed.providerId == current.speed.providerId) {
                val amount = EnergyConsumptionMath.energyKwh((old.kw + current.kw) / 2.0, dt)
                val distance = ((old.speedKmh + current.speedKmh) / 2.0) * dt / 3600.0
                if (amount != null && distance.isFinite() && distance >= 0.0 && distance <= 0.98) amount to distance else null
            } else null

            if (increment != null) {
                sessionEnergyKwh += increment.first
                sessionDistanceKm += increment.second
                intervals++
            }
            updateTrip(tripA, snapshot.number(MetricKey.TRIP_A), increment, dt, now)
            updateTrip(tripB, snapshot.number(MetricKey.TRIP_B), increment, dt, now)
            previous = current
        }

        val provenance = current ?: previous
        derived[MetricKey.TRACKED_ENERGY_CONSUMED] = if (intervals > 0 && provenance != null)
            derivedMetric(MetricKey.TRACKED_ENERGY_CONSUMED, sessionEnergyKwh, now, provenance.battery, provenance.speed,
                "İzleme dönemi: ardışık batarya kW örneklerinin trapez integrali; uygulama çalışırken")
        else MetricState.Unavailable("Tüketilen enerji için ardışık güncel ölçümler bekleniyor")
        val avg = EnergyConsumptionMath.averageKwhPer100Km(sessionEnergyKwh, sessionDistanceKm)
        derived[MetricKey.TRACKED_AVG_CONSUMPTION] = if (intervals > 0 && avg != null && provenance != null)
            derivedMetric(MetricKey.TRACKED_AVG_CONSUMPTION, avg, now, provenance.battery, provenance.speed,
                "İzleme dönemi: 100 × izlenen batarya tüketimi kWh / izlenen hızdan mesafe km; geçmiş yolculuk değildir")
        else MetricState.Unavailable("İzleme ortalaması için en az 50 metre güncel, eşzamanlı araç verisi gerekli")
        derived[MetricKey.LAST_TRIP_AVG_CONSUMPTION] = MetricState.Unavailable(
            "Tamamlanmış geçmiş yolculuğun doğrulanmış tüketim kaynağı henüz yok")

        derived[MetricKey.TRIP_A_AVG_CONSUMPTION] = tripAverage(MetricKey.TRIP_A_AVG_CONSUMPTION, tripA, provenance, now)
        derived[MetricKey.TRIP_B_AVG_CONSUMPTION] = tripAverage(MetricKey.TRIP_B_AVG_CONSUMPTION, tripB, provenance, now)
        derived[MetricKey.TRIP_A_ENERGY_CONSUMED] = tripEnergy(MetricKey.TRIP_A_ENERGY_CONSUMED, tripA, provenance, now)
        derived[MetricKey.TRIP_B_ENERGY_CONSUMED] = tripEnergy(MetricKey.TRIP_B_ENERGY_CONSUMED, tripB, provenance, now)

        val regenState = snapshot.number(MetricKey.REGEN_POWER)
        val regenMetric = (regenState as? MetricState.Live<Double>)?.metric?.takeIf {
            isUsable(it, now, "kW") && it.value in 0.0..1000.0
        }
        if (regenMetric == null) lastRegen = null
        else {
            val old = lastRegen
            if (old != null && old.metric.source == regenMetric.source && old.metric.providerId == regenMetric.providerId) {
                val seconds = Duration.between(old.at, now).toMillis() / 1000.0
                EnergyConsumptionMath.energyKwh((old.powerKw + regenMetric.value) / 2.0, seconds)?.let {
                    regenEnergyKwh += it
                    regenIntervals++
                }
            }
            lastRegen = Regen(now, regenMetric.value, regenMetric)
        }
        // Do not mistake positive NET battery charging or the regeneration setting for brake recovery.
        derived[MetricKey.RECOVERED_ENERGY] = if (regenIntervals > 0 && regenMetric != null)
            MetricState.Live(regenMetric.copy(
                id = MetricKey.RECOVERED_ENERGY.name, value = regenEnergyKwh,
                unit = MetricKey.RECOVERED_ENERGY.unit,
                sourceTimestamp = now, receivedAt = now, freshnessSeconds = 10,
                providerId = "calculated:${regenMetric.providerId}",
                methodEvidence = "İzleme dönemi: doğrulanmış REGEN_POWER kW trapez integrali; şarj gücü değildir"
            ))
        else MetricState.Unavailable("Gerçek rejenerasyon kW kaynağı olmadan geri kazanılan enerji hesaplanamaz")

        return snapshot.copy(readings = snapshot.readings + derived)
    }

    private fun updateTrip(window: TripWindow, state: MetricState<Double>,
                           increment: Pair<Double, Double>?, dt: Double?, now: Instant) {
        val raw = (state as? MetricState.Live<Double>)?.metric?.takeIf {
            isUsable(it, now, "km") && it.value in 0.0..1000000.0
        }
        if (raw == null) { window.lastKm = null; return }
        val last = window.lastKm
        if (last != null && raw.value < last - 0.001) {
            window.energyKwh = 0.0; window.distanceKm = 0.0; window.samples = 0
        } else if (last != null && increment != null && dt != null) {
            val diff = raw.value - last
            // Ensure trip counter and power samples cover a plausible contiguous interval.
            if (diff >= 0.0 && diff <= dt * 350.0 / 3600.0 + 0.2) {
                window.energyKwh += increment.first
                window.distanceKm += diff
                window.samples++
            }
        }
        window.lastKm = raw.value
    }

    private fun tripAverage(key: MetricKey, w: TripWindow, provenance: Input?, now: Instant): MetricState<Double> {
        val avg = EnergyConsumptionMath.averageKwhPer100Km(w.energyKwh, w.distanceKm)
        return if (avg != null && w.samples > 0 && provenance != null)
            derivedMetric(key, avg, now, provenance.battery, provenance.speed,
                "Yalnız uygulamanın izlediği Trip sayacı farkı km + eşzamanlı batarya tüketimi; bütün Trip geçmişi değil")
        else MetricState.Unavailable("Trip kilometre birimi ve eşzamanlı veri doğrulanmalı; yalnız izlenen bölüm hesaplanır")
    }

    private fun tripEnergy(key: MetricKey, w: TripWindow, provenance: Input?, now: Instant): MetricState<Double> =
        if (w.samples > 0 && provenance != null)
            derivedMetric(key, w.energyKwh, now, provenance.battery, provenance.speed,
                "Yalnız uygulamanın izlediği Trip sayaç döneminde batarya kW integrali; tamamı değildir")
        else MetricState.Unavailable("Trip A/B sayacı ve ardışık batarya gücü ölçümü gerekli")

    private fun validPair(battery: MetricState<Double>, speed: MetricState<Double>, now: Instant): Input? {
        val b = (battery as? MetricState.Live<Double>)?.metric ?: return null
        val s = (speed as? MetricState.Live<Double>)?.metric ?: return null
        if (!isUsable(b, now, "kW") || !isUsable(s, now, "km/sa")) return null
        if (b.source == DataSource.PHONE_GPS || s.source == DataSource.PHONE_GPS) return null
        if (b.value !in 0.0..1000.0 || s.value !in 0.0..350.0) return null
        if (abs(Duration.between(b.receivedAt, s.receivedAt).toMillis()) > 3_000L) return null
        return Input(now, b.value, s.value, b, s)
    }

    private fun isUsable(metric: VehicleMetric<Double>, now: Instant, unit: String): Boolean {
        if (!metric.value.isFinite() || metric.unit != unit || metric.quality != DataQuality.VALID ||
            metric.supportStatus != SupportStatus.AVAILABLE || metric.accessScope != AccessScope.OEM_READ) return false
        val age = Duration.between(metric.sourceTimestamp, now).toMillis()
        return age >= -1_000L && age <= metric.freshnessSeconds * 1_000L &&
            abs(Duration.between(metric.receivedAt, now).toMillis()) <= 3_000L
    }

    private fun derivedMetric(key: MetricKey, value: Double, now: Instant,
                              battery: VehicleMetric<Double>, speed: VehicleMetric<Double>,
                              evidence: String): MetricState<Double> = MetricState.Live(battery.copy(
        id = key.name, value = value, unit = key.unit,
        sourceTimestamp = now, receivedAt = now,
        freshnessSeconds = 5,
        providerId = "calculated:battery=${battery.providerId};speed=${speed.providerId}",
        methodEvidence = evidence
    ))
}

/** Capabilities for methods that use existing live sensors rather than an invented BYD PID. */
object EnergyConsumptionEvidence {
    val keys: Set<MetricKey> = setOf(
        MetricKey.INSTANT_CONSUMPTION, MetricKey.TRACKED_AVG_CONSUMPTION,
        MetricKey.LAST_TRIP_AVG_CONSUMPTION, MetricKey.TRIP_A_AVG_CONSUMPTION,
        MetricKey.TRIP_B_AVG_CONSUMPTION, MetricKey.TRACKED_ENERGY_CONSUMED,
        MetricKey.TRIP_A_ENERGY_CONSUMED, MetricKey.TRIP_B_ENERGY_CONSUMED, MetricKey.RECOVERED_ENERGY
    )
    fun capabilities(): List<VehicleCapability> = keys.map { key ->
        VehicleCapability(key, false, false,
            listOf("Türetilmiş salt-okunur alan; güncel doğrulanmış sensörler olmadan canlı sayı üretilmez",
                if (key == MetricKey.LAST_TRIP_AVG_CONSUMPTION)
                    "TS CarBodyManager.getTripEnergyConAvg() firmware imzası bulundu; birimi, zamanı ve geçmiş yolculukla ilişkisi doğrulanmadı"
                else if (key.name.contains("TRIP_A") || key.name.contains("TRIP_B"))
                    "Trip A/B kilometre birimi ve izleme aralığı eşlemesi gerekli"
                else "AAOS batarya deşarjı / araç hızı; kWh enerji entegrasyonu sadece izlenen dönem"),
            listOf(AccessScope.OEM_READ), "calculated-energy-read-only", false,
            SupportStatus.NEEDS_INTEGRATION)
    }
}
