package com.sealion7.core.model

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.ConcurrentHashMap

/** Counts REAL getter and getProperty invocations, not signature discovery or APK methods. */
data class ReadAuditResult(
 val attemptedCalls: Int, val returnedValues: Int,
 val distinctInvokedMethods: Int, val attemptedPaths: Map<String, Int>
)

object VehicleReadAudit {
 private class Capture {
  val tries = AtomicInteger(0)
  val responses = AtomicInteger(0)
  val paths = ConcurrentHashMap.newKeySet<String>()
  val sources = ConcurrentHashMap<String, AtomicInteger>()
  fun attempt(source: String, method: String) {
   tries.incrementAndGet(); paths.add("$source.$method")
   sources.computeIfAbsent(source){ AtomicInteger(0) }.incrementAndGet()
  }
  fun nonNull() { responses.incrementAndGet() }
  fun result() = ReadAuditResult(tries.get(),responses.get(),paths.size,sources.mapValues{it.value.get()})
 }
 @Volatile private var capture: Capture? = null
 @Synchronized fun begin() { check(capture == null) { "Audit already active" }; capture = Capture() }
 fun attempt(source: String, method: String) { capture?.attempt(source,method) }
 fun nonNull() { capture?.nonNull() }
 @Synchronized fun finish(): ReadAuditResult {
  val result = capture?.result() ?: ReadAuditResult(0,0,0,emptyMap())
  capture=null;return result
 }
}

data class VehicleScanReport(
 val sourcesChecked: Int,
 val attemptedGetterCalls: Int,
 val nonNullResponses: Int,
 val distinctInvokedPaths: Int,
 val liveVehicleMetrics: Int,
 val staleVehicleMetrics: Int,
 val sourceCallCounts: Map<String, Int>,
 val connection: VehicleConnectionState,
 val scannedAt: java.time.Instant,
 val note: String = "Çağrılar yalnız izinli sağlayıcılara yapılır; tanımlı firmware getter'ları kendiliğinden okunmuş sayılmaz."
)
