package com.sealion7.core.model

/**
 * Three physically distinct power metrics:
 *  - traction: measured MOTOR output, never inferred from battery draw,
 *  - battery consumption: battery DC discharge (includes auxiliary loads),
 *  - regenerative power: measured brake-energy recovery, never the regen setting.
 *
 * The Android Automotive charge-rate property is signed MILLIWATTS: >0 means
 * charging and <0 means discharging. This normalizer does NOT claim that a
 * positive charge rate necessarily comes from regenerative braking.
 */
object PowerTelemetryNormalizer {
    fun batteryConsumptionKwFromAaosRate(milliWatts: Double?): Double? {
        if (milliWatts == null || !milliWatts.isFinite()) return null
        if (milliWatts > 0.0) return null // charging, NOT traction/discharge
        return (-milliWatts / 1_000_000.0).takeIf { it.isFinite() && it in 0.0..1000.0 }
    }
}

/** Only firmware signature evidence, not proof of units or real sensor readout. */
object BydPowerSourceEvidence {
    val traction = listOf(
        "ts-framework.jar: CarCloudAdapterManager.getDriverMotorTorque()",
        "ts-framework.jar: CarCloudAdapterManager.getDriverMotorSpeed()",
        "ts-framework.jar: CarCloudAdapterManager.getMotorMCUGeneratrixCurrent()",
        "ts-framework.jar: CarCloudAdapterManager.getMotorMCUGeneratrixVolt()"
    )
    val regen = listOf(
        "ts-framework.jar: DriveModeAdapterManager.getDriveBrakingRecovery()",
        "ts-framework.jar: CarBodyManager.getEnergyFeedback()"
    )
    // regen getters describe a setting/status until vehicle-specific type and units are verified.
}
