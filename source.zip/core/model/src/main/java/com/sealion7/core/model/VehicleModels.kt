package com.sealion7.core.model

import java.time.Instant

enum class MetricKey(val title: String, val unit: String) {
 VEHICLE_SPEED("Araç hızı", "km/sa"), RANGE("Kalan menzil", "km"),
 SOC("Batarya SOC", "%"), POWER("Önceki güç alanı (kaynak eşlemesi yok)", "kW"),
 TRACTION_POWER("Çekiş gücü", "kW"),
 BATTERY_CONSUMPTION_POWER("Batarya tüketim gücü", "kW"),
 REGEN_POWER("Rejenerasyon gücü", "kW"),
 INSTANT_CONSUMPTION("Anlık tüketim", "kWh/100 km"),
 TRACKED_AVG_CONSUMPTION("İzlenen dönemin ortalama tüketimi", "kWh/100 km"),
 LAST_TRIP_AVG_CONSUMPTION("Son tamamlanan yolculuğun ortalama tüketimi", "kWh/100 km"),
 TRIP_A_AVG_CONSUMPTION("Trip A · izlenen bölüm ortalama tüketim", "kWh/100 km"),
 TRIP_B_AVG_CONSUMPTION("Trip B · izlenen bölüm ortalama tüketim", "kWh/100 km"),
 TRACKED_ENERGY_CONSUMED("İzlenen dönemde tüketilen enerji", "kWh"),
 TRIP_A_ENERGY_CONSUMED("Trip A · izlenen bölümde tüketilen enerji", "kWh"),
 TRIP_B_ENERGY_CONSUMED("Trip B · izlenen bölümde tüketilen enerji", "kWh"),
 RECOVERED_ENERGY("İzlenen dönemde geri kazanılan enerji", "kWh"),
 ODOMETER("Toplam km", "km"),
 TRIP_A("Kilometre 1 (Trip A)", "km"), TRIP_B("Kilometre 2 (Trip B)", "km"),
 OUTSIDE_TEMP("Dış sıcaklık", "°C"), TIRE_FL("Sol ön", "kPa"),
 TIRE_FR("Sağ ön", "kPa"), TIRE_RL("Sol arka", "kPa"), TIRE_RR("Sağ arka", "kPa"),
 TIRE_TEMP_FL("Sol ön lastik sıcaklığı", "°C"), TIRE_TEMP_FR("Sağ ön lastik sıcaklığı", "°C"),
 TIRE_TEMP_RL("Sol arka lastik sıcaklığı", "°C"), TIRE_TEMP_RR("Sağ arka lastik sıcaklığı", "°C"),
 BATTERY_NET_POWER("Batarya net enerji akışı (+şarj / −deşarj)", "kW"),
 BATTERY_AVG_TEMP("Batarya ortalama sıcaklığı", "°C"),
 REGEN_SETTING("Rejeneratif frenleme", "kademe"),
 CHARGE_POWER("Şarj gücü", "kW"),
 TS_SHIFT_MODE_RAW("TS vites ham kodu (yorum doğrulanmadı)", "kod"),
 TS_CHARGER_STATE_RAW("TS şarj durum ham kodu (yorum doğrulanmadı)", "kod"),
 GROUND_SPEED("DiLink GPS/zemin hızı", "km/sa")
}
enum class DataSource { BYD_OFFICIAL, AAOS_CAR_HARDWARE, TS_CAR_ADAPTER, BYDAUTO_DEVICE, DILINK5_DEVICE, AUTHORIZED_DIAGNOSTIC, PHONE_GPS }
enum class DataQuality { VALID, SUSPECT }
enum class SupportStatus { AVAILABLE, NEEDS_AUTHORIZATION, NEEDS_INTEGRATION, OPTIONAL_UNVERIFIED, UNSUPPORTED }
enum class AccessScope { PUBLIC_ANDROID, OEM_READ, OEM_WRITE, DIAGNOSTIC_READ }

data class VehicleMetric<T>(
 val id: String, val value: T, val unit: String, val source: DataSource,
 val sourceTimestamp: Instant, val receivedAt: Instant,
 val quality: DataQuality, val freshnessSeconds: Long,
 val supportStatus: SupportStatus, val accessScope: AccessScope,
 val providerId: String = source.name, val methodEvidence: String = "",
 val deviceTimestampVerified: Boolean = false
)
sealed interface MetricState<out T> {
 data class Live<T>(val metric: VehicleMetric<T>) : MetricState<T>
 data class Stale<T>(val metric: VehicleMetric<T>, val ageSeconds: Long) : MetricState<T>
 data object Disconnected : MetricState<Nothing>
 data object PermissionRequired : MetricState<Nothing>
 data object Unsupported : MetricState<Nothing>
 data class Unavailable(val reason: String) : MetricState<Nothing>
 data class Error(val code: String) : MetricState<Nothing>
}

enum class VehicleConnectionState { CONNECTED, CONNECTING, DISCONNECTED, REQUIRES_CONSENT, UNSUPPORTED }
sealed interface CommandState {
 data object NotSupported : CommandState
 data object PermissionRequired : CommandState
 data object AwaitingConfirmation : CommandState
 data object Sending : CommandState
 data object Acknowledged : CommandState
 data class Rejected(val reason: String) : CommandState
 data object TimedOut : CommandState
 data class Failed(val reason: String) : CommandState
}
data class VehicleCapability(
 val key: MetricKey, val canRead: Boolean, val canWrite: Boolean,
 val constraints: List<String>, val requiredScopes: List<AccessScope>,
 val providerId: String?, val equipmentOption: Boolean,
 val supportStatus: SupportStatus
)
data class VehicleAlert(val code: String, val message: String, val severity: Severity, val source: DataSource, val observedAt: Instant)
enum class Severity { INFO, WARNING, CRITICAL }
data class VehicleSnapshot(
 val readings: Map<MetricKey, MetricState<Double>> = MetricKey.entries.associateWith {
  MetricState.Unavailable("Doğrulanmış araç telemetri bağlantısı yok")
 },
 val gear: String? = null, val driveMode: String? = null,
 val alerts: List<VehicleAlert> = emptyList(), val connection: VehicleConnectionState = VehicleConnectionState.DISCONNECTED,
 val tirePressureLimits: Map<MetricKey, TirePressureLimit> = emptyMap(),
 val oemRawObservations: List<OemRawObservation> = emptyList(),
 val sourceDiagnostics: Map<String, SourceSessionDiagnostic> = emptyMap()
) {
 fun number(key: MetricKey): MetricState<Double> = readings[key] ?: MetricState.Unavailable("Veri alınamıyor")
}
