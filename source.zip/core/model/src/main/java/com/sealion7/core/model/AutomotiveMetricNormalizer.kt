package com.sealion7.core.model

import kotlin.math.abs

/** Only standardized AAOS VehiclePropertyIds units, never OEM/CAN scaling guesses. */
object AutomotiveMetricNormalizer {
 fun speedKmh(metersPerSecond: Double): Double? =
  (abs(metersPerSecond) * 3.6).takeIf { it.isFinite() && it <= 350.0 }

 fun rangeKm(meters: Double): Double? =
  (meters / 1000.0).takeIf { it.isFinite() && it in 0.0..3000.0 }

 /** EV_BATTERY_LEVEL and EV_CURRENT_BATTERY_CAPACITY are both in Wh. */
 fun socPercent(batteryWh: Double, usableCapacityWh: Double): Double? {
  if (!batteryWh.isFinite() || !usableCapacityWh.isFinite() || usableCapacityWh <= 0.0 || batteryWh < 0) return null
  return (100.0 * batteryWh / usableCapacityWh).takeIf { it in 0.0..100.0 }
 }

 fun odometerKm(value: Double): Double? = value.takeIf { it.isFinite() && it in 0.0..5_000_000.0 }
 fun outsideCelsius(value: Double): Double? = value.takeIf { it.isFinite() && it in -80.0..80.0 }
}

/** Android Automotive VehiclePropertyIds: units documented by the Android Car API. */
object AaosExtendedNormalizer {

 /** EV_BATTERY_INSTANTANEOUS_CHARGE_RATE is in milliwatts, signed. */
 fun batteryNetKw(milliWatts: Double?): Double? = milliWatts?.takeIf { it.isFinite() }
  ?.div(1_000_000.0)?.takeIf { it in -1000.0..1000.0 }
 /** TIRE_PRESSURE is kilopascal, per wheel AreaId. */
 fun tireKpa(value: Double?): Double? = value?.takeIf { it.isFinite() && it in 0.0..1500.0 }
 /** EV_BATTERY_AVERAGE_TEMPERATURE is Celsius. */
 fun batteryTempC(value: Double?): Double? = value?.takeIf { it.isFinite() && it in -50.0..120.0 }
 /** Raw OEM level is not a percent nor an actual regen power measurement. */
 fun regenSetting(raw: Double?): Double? = raw?.takeIf { it.isFinite() && it in 0.0..1000.0 && it % 1.0 == 0.0 }
}
