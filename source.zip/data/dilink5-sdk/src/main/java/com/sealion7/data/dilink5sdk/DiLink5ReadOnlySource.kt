package com.sealion7.data.dilink5sdk

import android.content.Context
import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.ReadOnlyVehicleSource
import com.sealion7.data.oem.OemReadOnlyRuntime
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Separate DiLink 5 poll-only route (BYD Trip Stats/Yoldas research), not an APK clone.
 * Typed push listeners require OEM SDK approval and separately verified callback ABI,
 * so they are NOT registered or emulated here. getSpeedValue is GROUND speed, not cluster speed.
 */
@Singleton class DiLink5ReadOnlySource @Inject constructor(@ApplicationContext ctx:Context):ReadOnlyVehicleSource {
 override val id="dilink5-read-only"
 private val runtime=OemReadOnlyRuntime(ctx, "DiLink5")
 private val stat="android.hardware.bydauto.statistic.BYDAutoStatisticDevice"
 private val speed="android.hardware.bydauto.speed.BYDAutoSpeedDevice"
 @Volatile private var confirmedReadings:Set<MetricKey> = emptySet()
 private val keys=listOf(MetricKey.GROUND_SPEED,MetricKey.SOC,MetricKey.RANGE,MetricKey.ODOMETER)
 private fun authorized()=runtime.mayRead() && runtime.hasClass(stat)
 override suspend fun capabilities():List<VehicleCapability> = keys.map {
  if(authorized() && it in confirmedReadings)runtime.scoped(it,id) else runtime.unauthorized(it,id,
   "DiLink 5: OEM izinleri/servis erişimi ve donanım-sürüm uyumu doğrulanmalı")
 }
 override suspend fun readOnce():VehicleSnapshot=withContext(Dispatchers.IO) {
  if(!authorized())return@withContext VehicleSnapshot()
  val s=runtime.sdkObject(stat)
  val v=runtime.sdkObject(speed)
  val samples=mutableMapOf<MetricKey,MetricState<Double>>()
  fun add(k:MetricKey,x:Double?,m:String,ttl:Long){ samples[k]=runtime.metric(k,x,DataSource.DILINK5_DEVICE,id,m,ttl) }
  // Different DiLink 5 getter: do NOT present this under VEHICLE_SPEED by default.
  add(MetricKey.GROUND_SPEED,OemTelemetryNormalizer.speed(runtime.numeric(v,"getSpeedValue")),"speed.getSpeedValue (ground)",5)
  add(MetricKey.SOC,OemTelemetryNormalizer.soc(runtime.numeric(s,"getElecPercentageValue")),"statistic.getElecPercentageValue",120)
  add(MetricKey.RANGE,OemTelemetryNormalizer.range(runtime.numeric(s,"getElecDrivingRangeValue")),"statistic.getElecDrivingRangeValue",120)
  add(MetricKey.ODOMETER,OemTelemetryNormalizer.odometer(runtime.numeric(s,"getTotalMileageValue")),"statistic.getTotalMileageValue",300)
  confirmedReadings = samples.filterValues { it is MetricState.Live<*> }.keys.toSet()
  VehicleSnapshot(readings=samples,connection=if(samples.values.any { it is MetricState.Live<*> })
   VehicleConnectionState.CONNECTED else VehicleConnectionState.DISCONNECTED)
 }
}
