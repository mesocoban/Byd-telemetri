plugins { id("com.android.library"); id("com.google.dagger.hilt.android"); id("com.google.devtools.ksp") }
android { namespace = "com.sealion7.data.dilink5sdk"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation(project(":core:model")); implementation(project(":domain:vehicle")); implementation(project(":data:oem-common"))
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
 implementation("com.google.dagger:hilt-android:2.60.1")
 ksp("com.google.dagger:hilt-compiler:2.60.1") }
