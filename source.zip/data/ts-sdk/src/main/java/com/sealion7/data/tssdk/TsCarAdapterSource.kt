package com.sealion7.data.tssdk

import android.content.Context
import android.os.SystemClock
import java.lang.reflect.Proxy
import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.ReadOnlyVehicleSource
import com.sealion7.data.oem.OemReadOnlyRuntime
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** ABRP SL7 reference + user firmware ts-framework.jar. No SDK JAR is shipped in the APK. */
@Singleton class TsCarAdapterSource @Inject constructor(@ApplicationContext context:Context):ReadOnlyVehicleSource {
 override val id="ts-caradapter-oem"
 private val runtime=OemReadOnlyRuntime(context, "TS")
 private val mutex=Mutex()
 private var adapter:Any?=null
 private var binderListener:Any?=null
 @Volatile private var binderDropped=false
 private val reconnect=TsReconnectPolicy()
 private var currentDiagnostic = SourceSessionDiagnostic(id,SourceSessionPhase.CONNECTING,0,0,0L,"TS oturumu bekleniyor")
 private fun diagnosis(phase:SourceSessionPhase,note:String,waitMs:Long=0L):VehicleSnapshot {
  confirmedReadings=emptySet() // Old capabilities must not masquerade as current evidence.
  currentDiagnostic=SourceSessionDiagnostic(id,phase,reconnect.attemptedConnections,reconnect.unboundPolls,waitMs,note)
  return VehicleSnapshot(sourceDiagnostics=mapOf(id to currentDiagnostic),
   connection=if(phase==SourceSessionPhase.CONNECTING || phase==SourceSessionPhase.WAITING_TO_RETRY)
    VehicleConnectionState.CONNECTING else VehicleConnectionState.DISCONNECTED)
 }
 /** Listen to public SDK binder state if supported; no private-field patching. */
 private fun attachBinderListener(a:Any) {
  val listener=runCatching {
   val type=Class.forName("com.ts.lib.caradapter.interfaces.OnCarAdapterConnectListener")
   Proxy.newProxyInstance(type.classLoader,arrayOf(type)) { proxy, method, args ->
    when(method.name) {
     "onBinderStateChanged" -> { if(args?.firstOrNull()==false) binderDropped=true; null }
     "equals" -> proxy === args?.firstOrNull()
     "hashCode" -> System.identityHashCode(proxy)
     "toString" -> "Sealion7TSBinderObserver"
     else -> null
    }
   }
  }.getOrNull() ?: return
  runtime.call(a,"setOnManagerConnChangedListener",listener)
  binderListener=listener
 }
 private val sdk="com.ts.lib.caradapter.CarAdapterManager"
 @Volatile private var confirmedReadings:Set<MetricKey> = emptySet()
 private val keys=listOf(MetricKey.VEHICLE_SPEED,MetricKey.SOC,MetricKey.RANGE,
  MetricKey.ODOMETER,MetricKey.TRIP_A,MetricKey.TRIP_B,MetricKey.OUTSIDE_TEMP,MetricKey.CHARGE_POWER,
  MetricKey.TRACTION_POWER, MetricKey.REGEN_POWER, MetricKey.BATTERY_CONSUMPTION_POWER,
  MetricKey.TS_SHIFT_MODE_RAW, MetricKey.TS_CHARGER_STATE_RAW)
 private fun authorized()=runtime.mayReadPublicTs()
 override suspend fun capabilities():List<VehicleCapability> = keys.map { key ->
  if(authorized() && key in confirmedReadings)runtime.scoped(key,id)
  else runtime.unauthorized(key,id,
   if (key in listOf(MetricKey.TRACTION_POWER,MetricKey.REGEN_POWER,MetricKey.BATTERY_CONSUMPTION_POWER))
    "TS motor/enerji getter adayları firmware içinde var; birim ve kaynağın gerçek Sealion 7'de doğrulanması + OEM yetkisi gerekli"
   else "TS public CarAdapter SDK / servis erişimi gerekli; erişim cihaz ve servis politikasına bağlı")
 }
 override suspend fun readOnce():VehicleSnapshot=withContext(Dispatchers.IO){ mutex.withLock {
  // TS public SDK can be attempted without unrelated AAOS vendor-extension permission.
  // Any actual access denial is reported from the service; no privileged APIs are bypassed.
  if(!runtime.hasClass(sdk)) return@withLock diagnosis(SourceSessionPhase.SDK_MISSING,
   "TS CarAdapterManager sınıfı mevcut değil")
  val nowMs=SystemClock.elapsedRealtime()
  val a=adapter ?: runtime.sdkObject(sdk)?.also {
   adapter=it
   attachBinderListener(it)
  } ?:return@withLock diagnosis(SourceSessionPhase.READ_ERROR,"TS getInstance nesnesi oluşturulamadı")
  val bound=runtime.call(a,"isCarServiceBound")==true
  if(bound) binderDropped=false
  if(!bound) {
   reconnect.onUnbound()
   if(reconnect.canConnect(nowMs)) {
    // Repeated failure may leave an obsolete client binder. Only use PUBLIC SDK methods.
    if(reconnect.unboundPolls >= 5 && reconnect.unboundPolls % 5 == 0) {
     runtime.call(a,"disconnect")
     adapter=null
     binderListener=null
    }
    val next = adapter ?: runtime.sdkObject(sdk)?.also { adapter=it; attachBinderListener(it) }
    if(next != null) {
     binderDropped=false
     reconnect.markAttempt(nowMs)
     runtime.call(next,"connect") // bind only, never a car setting command
    }
    return@withLock diagnosis(SourceSessionPhase.CONNECTING,"TS servis bağlantısı başlatıldı; araç cevabı bekleniyor",reconnect.waitMs(nowMs))
   }
   return@withLock diagnosis(SourceSessionPhase.WAITING_TO_RETRY,
    "TS servis bağlı değil; aralıklı yeniden bağlanma",reconnect.waitMs(nowMs))
  }
  reconnect.onBound(nowMs)
  val sm=runtime.call(a,"getCarAdapterManager","sensor")
  val gm=runtime.call(a,"getCarAdapterManager","general")
  val hm=runtime.call(a,"getCarAdapterManager","hvac")
  val cm=runtime.call(a,"getCarAdapterManager","charging")
  val bm=runtime.call(a,"getCarAdapterManager","body")
  // TS firmware provides motor torque/speed/MCU getter signatures, but the unit scaling,
  // electric axle aggregation and runtime provenance are not validated for Sealion 7.
  // Authorized access may probe public getter availability for diagnostics only;
  // raw readings NEVER become fabricated kW values.
  val cloud = runtime.call(a,"getCarAdapterManager","cloud")
  val rawTorque = runtime.numeric(cloud,"getDriverMotorTorque")
  val rawMotorSpeed = runtime.numeric(cloud,"getDriverMotorSpeed")
  val rawBusVoltage = runtime.numeric(cloud,"getMotorMCUGeneratrixVolt")
  val rawBusCurrent = runtime.numeric(cloud,"getMotorMCUGeneratrixCurrent")
  val driveMode = runtime.call(a,"getCarAdapterManager","drivemode")
  val recoverySetting = runtime.numeric(driveMode,"getDriveBrakingRecovery")
  val energyFeedback = runtime.numeric(runtime.call(a,"getCarAdapterManager","body"),"getEnergyFeedback")
  val tractionReason = if(rawTorque != null && rawMotorSpeed != null)
   "TS motor tork/devir getter yanıtladı; birimler ve toplam çekiş gücü eşlemesi doğrulanmadı"
   else "TS motor tork/devir getter yanıtı veya OEM yetkisi yok"
  val samples=mutableMapOf<MetricKey,MetricState<Double>>()
  // Do not infer motor power from unscaled torque/RPM; no blind electrical V*A estimate.
  samples[MetricKey.TRACTION_POWER] = MetricState.Unavailable(tractionReason)
  samples[MetricKey.REGEN_POWER] = MetricState.Unavailable(
   if (recoverySetting != null || energyFeedback != null)
    "TS rejeneratif frenleme durumu/ayarı okundu; bu değer geri kazanılan kW ölçümü değil"
   else "TS getDriveBrakingRecovery/getEnergyFeedback yanıtlamadı; doğrulanmış rejenerasyon kW kaynağı yok")
  samples[MetricKey.BATTERY_CONSUMPTION_POWER] = MetricState.Unavailable(
   if (rawBusCurrent != null && rawBusVoltage != null)
    "TS MCU akım/voltaj ham getter yanıtladı; BMS çıkış gücü oldukları ve birimler doğrulanmadı"
   else "TS batarya deşarj kW veri birimi ve kaynağı henüz doğrulanmadı")
  fun add(k:MetricKey,v:Double?,m:String,age:Long) { samples[k]=runtime.metric(k,v,DataSource.TS_CAR_ADAPTER,id,m,age) }
  add(MetricKey.VEHICLE_SPEED,OemTelemetryNormalizer.speed(runtime.numeric(sm,"getCurrentSpeed")),"sensor.getCurrentSpeed",5)
  add(MetricKey.SOC,OemTelemetryNormalizer.soc(runtime.numeric(gm,"getElecPercentageValue")),"general.getElecPercentageValue",120)
  add(MetricKey.RANGE,OemTelemetryNormalizer.range(runtime.numeric(gm,"getElecDrivingRangeValue")),"general.getElecDrivingRangeValue",120)
  val odometerRaw = runtime.numeric(gm,"getTotalMileageValue")
  samples[MetricKey.ODOMETER] = MetricState.Unavailable(
   if(odometerRaw == null) "TS toplam mesafe getter yanıtı yok" else
    "TS toplam mesafe yanıtladı; getMileageUnit dönüş kodu kilometreye eşlenmedi")
  // The firmware defines getMileageNumberOne/Two and getMileageUnit, but the
  // numeric encoding of mileage units for THIS vehicle is not yet validated.
  // Intentionally do not publish unverified raw values as kilometres.
  val tripUnitCode = runtime.numeric(gm,"getMileageUnit")?.toInt()
  val tripOneRaw = runtime.numeric(gm,"getMileageNumberOne")
  val tripTwoRaw = runtime.numeric(gm,"getMileageNumberTwo")
  samples[MetricKey.TRIP_A] = MetricState.Unavailable(
   if(tripOneRaw == null) "TS Kilometre 1 getter cevap vermedi" else
    "TS Kilometre 1 okundu; mesafe birimi doğrulanmadı (kod: ${tripUnitCode ?: "?"})")
  samples[MetricKey.TRIP_B] = MetricState.Unavailable(
   if(tripTwoRaw == null) "TS Kilometre 2 getter cevap vermedi" else
    "TS Kilometre 2 okundu; mesafe birimi doğrulanmadı (kod: ${tripUnitCode ?: "?"})")
  add(MetricKey.OUTSIDE_TEMP,OemTelemetryNormalizer.tsOutsideTemperature(runtime.numeric(hm,"getTempratureOut")),"hvac.getTempratureOut",120)
  // ABRP source: P=1, N=3, D=4 observed; R=2 inferred and therefore never published.
  val shiftRaw=runtime.numeric(bm,"getShiftMode")
  val gear= AbrpReferenceSafety.observedGear(shiftRaw)
  samples[MetricKey.TS_SHIFT_MODE_RAW] = runtime.metric(MetricKey.TS_SHIFT_MODE_RAW,
   AbrpReferenceSafety.shiftCode(shiftRaw)?.toDouble(),DataSource.TS_CAR_ADAPTER,id,"body.getShiftMode (ham, P/N/D gözlemsel)",5)
  // Never treat charging power as traction/regen power. Only with an asserted charging state.
  val chargerState=runtime.numeric(cm,"getChargerState")?.toInt()
  samples[MetricKey.TS_CHARGER_STATE_RAW] = runtime.metric(MetricKey.TS_CHARGER_STATE_RAW,
   AbrpReferenceSafety.chargerCode(chargerState?.toDouble())?.toDouble(),DataSource.TS_CAR_ADAPTER,id,
   "charging.getChargerState (ham; DC/AC eşlemesi doğrulanmadı)",5)
  val chargeRaw = runtime.numeric(cm,"getChargingPower")
  samples[MetricKey.CHARGE_POWER] = MetricState.Unavailable(
   if (chargeRaw == null) "TS şarj gücü getter yanıtı yok" else
    "TS şarj gücü getter yanıtladı; getChargerState kodu ($chargerState) ve kW birimi doğrulanmadı")
  confirmedReadings = samples.filterValues { it is MetricState.Live<*> }.keys.toSet()
  val anyLive=samples.values.any { it is MetricState.Live<*> }
  currentDiagnostic=SourceSessionDiagnostic(id,
   if(anyLive) SourceSessionPhase.LIVE else SourceSessionPhase.BOUND_NO_DATA,
   reconnect.attemptedConnections,reconnect.unboundPolls,0L,
   if(anyLive) "TS bağlı: güncel izinli okuma var" else "TS binder bağlı, geçerli ölçüm alınamadı")
  VehicleSnapshot(readings=samples,gear=gear,sourceDiagnostics=mapOf(id to currentDiagnostic),
   connection=if(anyLive) VehicleConnectionState.CONNECTED else VehicleConnectionState.CONNECTING)
 } }
}
