package com.sealion7.data.vehicle

import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.sealion7.core.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Read-only, PUBLIC Android Automotive CarPropertyManager API. Does not use a TS/BYD
 * hidden service, send Binder transactions directly, request privilege escalation or write values.
 *
 * Reflection is exclusively used to load public android.car APIs when present; the phone APK
 * must still install on ordinary Android where the optional platform shared library is absent.
 * Platform permissions and getPropertyList() remain the authority for readable capabilities.
 */
@Singleton
class AaosReadOnlyTelemetry @Inject constructor(@ApplicationContext private val context: Context) {
 companion object {
  const val CAR_SPEED = "android.car.permission.CAR_SPEED"
  const val CAR_ENERGY = "android.car.permission.CAR_ENERGY"
  const val CAR_MILEAGE = "android.car.permission.CAR_MILEAGE_3P"
  const val CAR_POWERTRAIN = "android.car.permission.CAR_POWERTRAIN"
  const val CAR_TIRES_3P = "android.car.permission.CAR_TIRES_3P"
 }
 private val lock = Mutex()
 private data class Session(val car: Any, val manager: Any, val ids: Map<String, Int>,
  val readable: Set<Int>, val areasByProperty: Map<Int, Set<Int>>,
  val configsByProperty: Map<Int, Any>)
 private var session: Session? = null

 fun isAutomotiveHost(): Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE)
 fun permissionGranted(name: String): Boolean =
  ContextCompat.checkSelfPermission(context, name) == PackageManager.PERMISSION_GRANTED

 private fun id(name: String): Int? = try {
  Class.forName("android.car.VehiclePropertyIds").getField(name).getInt(null)
 } catch (_: ReflectiveOperationException) { null }

 private fun open(): Session? {
  session?.let { old ->
   val connected = runCatching { old.car.javaClass.getMethod("isConnected").invoke(old.car) as Boolean }.getOrDefault(false)
   if (connected) return old
   close()
  }
  val cls = Class.forName("android.car.Car")
  // Public synchronous createCar; never run on the main/UI thread.
  val car = cls.getMethod("createCar", Context::class.java).invoke(null, context) ?: return null
  try {
   val managerName = cls.getField("PROPERTY_SERVICE").get(null) as String
   val manager = cls.getMethod("getCarManager", String::class.java).invoke(car, managerName)
   if (manager == null) {
    runCatching { cls.getMethod("disconnect").invoke(car) }
    return null
   }
   val configs = manager.javaClass.getMethod("getPropertyList").invoke(manager) as? List<*> ?: emptyList<Any>()
   // getPropertyList is explicitly filtered by the Android Car service for caller permissions.
   val allowed = configs.filterNotNull().mapNotNull {
    runCatching { it.javaClass.getMethod("getPropertyId").invoke(it) as Int }.getOrNull()
   }.toSet()
   val names = listOf("PERF_VEHICLE_SPEED_DISPLAY", "PERF_VEHICLE_SPEED", "RANGE_REMAINING",
    "EV_BATTERY_LEVEL", "EV_CURRENT_BATTERY_CAPACITY", "PERF_ODOMETER", "ENV_OUTSIDE_TEMPERATURE", "GEAR_SELECTION",
    "TIRE_PRESSURE", "EV_BATTERY_AVERAGE_TEMPERATURE", "EV_BATTERY_INSTANTANEOUS_CHARGE_RATE",
    "EV_BRAKE_REGENERATION_LEVEL")
   val areas = configs.filterNotNull().mapNotNull { config ->
    runCatching {
     val propId = config.javaClass.getMethod("getPropertyId").invoke(config) as Int
     val rawAreas = config.javaClass.getMethod("getAreaIds").invoke(config)
     val areaIds = (rawAreas as? IntArray)?.toSet() ?: emptySet()
     propId to areaIds
    }.getOrNull()
   }.toMap()
   // Configurations come from permission-filtered CarPropertyManager.getPropertyList().
   val configMap = configs.filterNotNull().mapNotNull { cfg ->
    runCatching { (cfg.javaClass.getMethod("getPropertyId").invoke(cfg) as Int) to cfg }.getOrNull()
   }.toMap()
   return Session(car, manager, names.mapNotNull { n -> id(n)?.let { n to it } }.toMap(), allowed, areas, configMap)
    .also { session = it }
  } catch (e: Exception) {
   runCatching { cls.getMethod("disconnect").invoke(car) }
   throw e
  }
 }

 private fun close() {
  session?.let { runCatching { it.car.javaClass.getMethod("disconnect").invoke(it.car) } }
  session = null
 }

 private data class Sample(val value: Double, val timestamp: Instant, val ageSeconds: Long)
 private fun read(s: Session, name: String, kind: Class<*> = java.lang.Float::class.java, areaId: Int = 0): Sample? {
  val propertyId = s.ids[name] ?: return null
  if (propertyId !in s.readable) return null
  // Reject non-existent wheel areas instead of querying an unconfigured tire.
  if (name == "TIRE_PRESSURE" && areaId !in (s.areasByProperty[propertyId] ?: emptySet())) return null
  VehicleReadAudit.attempt("AAOS", "$name/$areaId")
  val prop = s.manager.javaClass.getMethod("getProperty", Class::class.java,
   Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
   .invoke(s.manager, kind, propertyId, areaId) ?: return null
  val clazz = prop.javaClass
  val status = clazz.getMethod("getStatus").invoke(prop) as? Int ?: return null
  val available = clazz.getField("STATUS_AVAILABLE").getInt(null)
  if (status != available) return null
  val value = (clazz.getMethod("getValue").invoke(prop) as? Number)?.toDouble() ?: return null
  val elapsedNs = (clazz.getMethod("getTimestamp").invoke(prop) as? Long) ?: return null
  val elapsedNow = SystemClock.elapsedRealtimeNanos()
  // Reject implausible future sample timestamps; do not label them fresh.
  if (elapsedNs > elapsedNow + 1_000_000_000L || elapsedNs < 0L) return null
  val ageNs = (elapsedNow - elapsedNs).coerceAtLeast(0L)
  val now = Instant.now()
  VehicleReadAudit.nonNull()
  return Sample(value, now.minusNanos(ageNs), ageNs / 1_000_000_000)
 }

 private fun result(key: MetricKey, source: Sample?, transformed: Double?, maxAge: Long, evidence: String = ""): MetricState<Double> {
  if (source == null) return MetricState.Unavailable("Araç özelliği okunamadı")
  if (transformed == null) return MetricState.Unavailable("Araçtan gelen ölçüm geçersiz")
  val metric = VehicleMetric(key.name, transformed, key.unit, DataSource.AAOS_CAR_HARDWARE,
   source.timestamp, Instant.now(), DataQuality.VALID, maxAge, SupportStatus.AVAILABLE, AccessScope.OEM_READ,
   providerId = "aaos-car-property-read-only", methodEvidence = evidence, deviceTimestampVerified = true)
  return if (source.ageSeconds > maxAge) MetricState.Stale(metric, source.ageSeconds)
   else MetricState.Live(metric)
 }

 private fun metricPermission(key: MetricKey): String? = when (key) {
  MetricKey.VEHICLE_SPEED -> CAR_SPEED
  MetricKey.RANGE, MetricKey.SOC, MetricKey.BATTERY_NET_POWER,
   MetricKey.BATTERY_CONSUMPTION_POWER, MetricKey.BATTERY_AVG_TEMP -> CAR_ENERGY
  MetricKey.REGEN_SETTING -> CAR_POWERTRAIN
  MetricKey.TIRE_FL, MetricKey.TIRE_FR, MetricKey.TIRE_RL, MetricKey.TIRE_RR -> CAR_TIRES_3P
  MetricKey.ODOMETER -> CAR_MILEAGE
  MetricKey.OUTSIDE_TEMP -> "android.car.permission.CAR_EXTERIOR_ENVIRONMENT"
  else -> null
 }

 /** Attempts only documented AAOS properties and only when the permissions are actually granted. */
 suspend fun readOnce(): VehicleSnapshot = withContext(Dispatchers.IO) {
  if (!isAutomotiveHost()) return@withContext VehicleSnapshot()
  lock.withLock {
   val out = MetricKey.entries.associateWith<MetricKey, MetricState<Double>> { key ->
    val perm = metricPermission(key)
    if (perm == null) MetricState.Unavailable("Belgelenmiş AAOS eşlemesi yok")
    else if (!permissionGranted(perm)) MetricState.PermissionRequired
    else MetricState.Unavailable("Araç özelliği araştırılıyor")
   }.toMutableMap()
   val sessionResult = try { open() } catch (e: Exception) {
    if (e is SecurityException || e.cause is SecurityException) {
     return@withLock VehicleSnapshot(readings = out.mapValues { (_, state) ->
      if (state is MetricState.PermissionRequired) state else MetricState.Unavailable("CarService erişimi reddedildi")
     }, connection = VehicleConnectionState.REQUIRES_CONSENT)
    }
    close(); null
   }
   if (sessionResult == null) return@withLock VehicleSnapshot(readings=out,
     connection = VehicleConnectionState.DISCONNECTED)
   val s = sessionResult
   fun granted(key: MetricKey) = metricPermission(key)?.let(::permissionGranted) == true
   fun safe(name:String,kind:Class<*> = java.lang.Float::class.java): Sample? = try { read(s,name,kind) } catch (e: Exception) {
    // Permission exceptions and service failures must never turn into live values.
    null
   }
   if (granted(MetricKey.VEHICLE_SPEED)) {
    val speed = safe("PERF_VEHICLE_SPEED_DISPLAY") ?: safe("PERF_VEHICLE_SPEED")
    out[MetricKey.VEHICLE_SPEED] = result(MetricKey.VEHICLE_SPEED, speed,
     speed?.value?.let(AutomotiveMetricNormalizer::speedKmh), 5)
   }
   if (granted(MetricKey.RANGE)) {
    val range = safe("RANGE_REMAINING")
    out[MetricKey.RANGE] = result(MetricKey.RANGE, range,
     range?.value?.let(AutomotiveMetricNormalizer::rangeKm), 30)
   }
   if (granted(MetricKey.SOC)) {
    val level = safe("EV_BATTERY_LEVEL")
    val capacity = safe("EV_CURRENT_BATTERY_CAPACITY")
    // Both battery measurements contribute to SOC; the older input determines freshness.
    val oldestSocSample = if (level != null && capacity != null && capacity.ageSeconds > level.ageSeconds) capacity else level
    out[MetricKey.SOC] = result(MetricKey.SOC, oldestSocSample,
     if (level != null && capacity != null) AutomotiveMetricNormalizer.socPercent(level.value, capacity.value) else null, 120)
   }
   if (granted(MetricKey.ODOMETER)) {
    val odo = safe("PERF_ODOMETER")
    out[MetricKey.ODOMETER] = result(MetricKey.ODOMETER, odo,
     odo?.value?.let(AutomotiveMetricNormalizer::odometerKm), 120)
   }
   if (granted(MetricKey.OUTSIDE_TEMP)) {
    val temp = safe("ENV_OUTSIDE_TEMPERATURE")
    out[MetricKey.OUTSIDE_TEMP] = result(MetricKey.OUTSIDE_TEMP, temp,
     temp?.value?.let(AutomotiveMetricNormalizer::outsideCelsius), 120)
   }
   // Newly documented AAOS properties. Absence is not an error or a fabricated measurement.
   if (granted(MetricKey.BATTERY_NET_POWER)) {
    // Same signed raw AAOS property is shared for net battery power and DC discharge,
    // without presenting it as the mechanical motor/traction or regen brake power.
    val net = safe("EV_BATTERY_INSTANTANEOUS_CHARGE_RATE")
    out[MetricKey.BATTERY_NET_POWER] = result(MetricKey.BATTERY_NET_POWER, net,
     AaosExtendedNormalizer.batteryNetKw(net?.value), 10,
     "EV_BATTERY_INSTANTANEOUS_CHARGE_RATE / 1_000_000 (mW→kW)")
    out[MetricKey.BATTERY_CONSUMPTION_POWER] = when {
     net == null -> MetricState.Unavailable("AAOS anlık batarya akış ölçümü alınamadı")
     net.value > 0.0 -> MetricState.Unavailable("Batarya şarj yönünde; deşarj gücü yayımlanmıyor")
     else -> result(MetricKey.BATTERY_CONSUMPTION_POWER, net,
      PowerTelemetryNormalizer.batteryConsumptionKwFromAaosRate(net.value), 10,
      "AAOS EV_BATTERY_INSTANTANEOUS_CHARGE_RATE negatif mW → batarya deşarj kW; motor gücü değildir")
    }
   }
   if (granted(MetricKey.BATTERY_AVG_TEMP)) {
    val temp = safe("EV_BATTERY_AVERAGE_TEMPERATURE")
    out[MetricKey.BATTERY_AVG_TEMP] = result(MetricKey.BATTERY_AVG_TEMP, temp,
     AaosExtendedNormalizer.batteryTempC(temp?.value), 120)
   }
   if (granted(MetricKey.REGEN_SETTING)) {
    val regen = safe("EV_BRAKE_REGENERATION_LEVEL", java.lang.Integer::class.java)
    out[MetricKey.REGEN_SETTING] = result(MetricKey.REGEN_SETTING, regen,
     AaosExtendedNormalizer.regenSetting(regen?.value), 60)
   }
   val tirePressureLimits = mutableMapOf<MetricKey, TirePressureLimit>()
   if (permissionGranted(CAR_TIRES_3P)) {
    // Read wheel properties individually; areaId=0 is invalid for area-based TIRE_PRESSURE.
    val wheelClass = runCatching { Class.forName("android.car.VehicleAreaWheel") }.getOrNull()
    val wheels = listOf(
     MetricKey.TIRE_FL to "WHEEL_LEFT_FRONT", MetricKey.TIRE_FR to "WHEEL_RIGHT_FRONT",
     MetricKey.TIRE_RL to "WHEEL_LEFT_REAR", MetricKey.TIRE_RR to "WHEEL_RIGHT_REAR")
    for ((key, wheel) in wheels) {
     val area = runCatching { wheelClass?.getField(wheel)?.getInt(null) }.getOrNull()
     val sample = if (area != null) try { read(s,"TIRE_PRESSURE",java.lang.Float::class.java,area) }
      catch (_: Exception) { null } else null
     out[key] = result(key,sample,AaosExtendedNormalizer.tireKpa(sample?.value),30)
     // The AAOS per-wheel TIRE_PRESSURE configuration can expose the vehicle manufacturer's
     // minimum recommended pressure, in kPa. This is NOT the original TPMS alert flag.
     // No arbitrary fixed low-pressure threshold is used.
     val propId = s.ids["TIRE_PRESSURE"]
     val cfg = propId?.let { s.configsByProperty[it] }
     val min = if (cfg != null && propId != null && propId in s.readable && area != null &&
       area in (s.areasByProperty[propId] ?: emptySet())) {
      runCatching {
       (cfg.javaClass.getMethod("getMinValue", Int::class.javaPrimitiveType)
        .invoke(cfg, area) as? Number)?.toDouble()
      }.getOrNull()
     } else null
     if (min != null && min.isFinite() && min in 50.0..500.0) {
      tirePressureLimits[key] = TirePressureLimit(
       wheel = key, minimumKpa = min, source = DataSource.AAOS_CAR_HARDWARE,
       providerId = DataSource.AAOS_CAR_HARDWARE.name,
       evidence = "CarPropertyConfig.getMinValue(areaId) · TIRE_PRESSURE · $wheel"
      )
     }
    }
   }
   val gearSample = if (permissionGranted(CAR_POWERTRAIN)) safe("GEAR_SELECTION", java.lang.Integer::class.java) else null
   val gear = gearSample?.takeIf { it.ageSeconds <= 30 }?.let { sample ->
    val c = runCatching { Class.forName("android.car.VehicleGear") }.getOrNull()
    listOf("GEAR_PARK" to "P", "GEAR_REVERSE" to "R", "GEAR_NEUTRAL" to "N", "GEAR_DRIVE" to "D")
     .firstOrNull { (name, _) -> runCatching { c?.getField(name)?.getInt(null) == sample.value.toInt() }.getOrDefault(false) }?.second
   }
   val isLive = out.values.any { it is MetricState.Live<*> }
   val needsPermission = out.values.any { it is MetricState.PermissionRequired }
   VehicleSnapshot(readings = out, gear = gear, tirePressureLimits = tirePressureLimits,
    connection = when {
     isLive -> VehicleConnectionState.CONNECTED
     needsPermission -> VehicleConnectionState.REQUIRES_CONSENT
     else -> VehicleConnectionState.DISCONNECTED
    })
  }
 }

 suspend fun capabilities(): List<VehicleCapability> = withContext(Dispatchers.IO) {
  val automotive = isAutomotiveHost()
  val s = if (automotive) lock.withLock { runCatching { open() }.getOrNull() } else null
  MetricKey.entries.filterNot { it in TireTemperatureEvidence.keys }.map { key ->
   val perm = metricPermission(key)
   val names = when(key) {
    MetricKey.VEHICLE_SPEED -> listOf("PERF_VEHICLE_SPEED_DISPLAY", "PERF_VEHICLE_SPEED")
    MetricKey.RANGE -> listOf("RANGE_REMAINING")
    MetricKey.SOC -> listOf("EV_BATTERY_LEVEL", "EV_CURRENT_BATTERY_CAPACITY")
    MetricKey.ODOMETER -> listOf("PERF_ODOMETER")
    MetricKey.OUTSIDE_TEMP -> listOf("ENV_OUTSIDE_TEMPERATURE")
    MetricKey.BATTERY_NET_POWER, MetricKey.BATTERY_CONSUMPTION_POWER -> listOf("EV_BATTERY_INSTANTANEOUS_CHARGE_RATE")
    MetricKey.BATTERY_AVG_TEMP -> listOf("EV_BATTERY_AVERAGE_TEMPERATURE")
    MetricKey.REGEN_SETTING -> listOf("EV_BRAKE_REGENERATION_LEVEL")
    MetricKey.TIRE_FL, MetricKey.TIRE_FR, MetricKey.TIRE_RL, MetricKey.TIRE_RR -> listOf("TIRE_PRESSURE")
    else -> emptyList()
   }
   val granted = perm != null && permissionGranted(perm)
   val accessible: (String) -> Boolean = { name ->
    val value = s?.ids?.get(name)
    value != null && value in (s?.readable ?: emptySet())
   }
   val wheelKey = when (key) {
    MetricKey.TIRE_FL -> "WHEEL_LEFT_FRONT"; MetricKey.TIRE_FR -> "WHEEL_RIGHT_FRONT"
    MetricKey.TIRE_RL -> "WHEEL_LEFT_REAR"; MetricKey.TIRE_RR -> "WHEEL_RIGHT_REAR"
    else -> null
   }
   val readable = s != null && granted && names.isNotEmpty() &&
    (if (key == MetricKey.VEHICLE_SPEED) names.any(accessible) else names.all(accessible)) &&
    (wheelKey == null || runCatching {
     val areaId = Class.forName("android.car.VehicleAreaWheel").getField(wheelKey).getInt(null)
     val prop = s?.ids?.get("TIRE_PRESSURE")
     prop != null && areaId in (s.areasByProperty[prop] ?: emptySet())
    }.getOrDefault(false))
   VehicleCapability(key, readable, false, listOf(when {
    !automotive -> "Bu cihaz Android Automotive değil; araç telemetrisi telefonda sunulmuyor"
    perm == null -> "Bu metrik için AAOS açık veri eşlemesi tanımlanmadı"
    !granted -> "Sistem izin vermedi: $perm"
    !readable -> "İzinli CarPropertyManager listesinde özellik bulunamadı"
    else -> "Android Automotive okuma API'si mevcut; ölçüm yalnız alınabildiğinde gösterilir"
   }), if (perm != null) listOf(AccessScope.OEM_READ) else emptyList(),
    "aaos-car-property-read-only", false, when {
     readable -> SupportStatus.AVAILABLE
     automotive && perm != null && !granted -> SupportStatus.NEEDS_AUTHORIZATION
     else -> SupportStatus.NEEDS_INTEGRATION
    })
  }
 }
}
