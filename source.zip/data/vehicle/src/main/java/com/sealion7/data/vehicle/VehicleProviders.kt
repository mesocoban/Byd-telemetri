package com.sealion7.data.vehicle

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.core.content.ContextCompat
import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.VehicleRepository
import com.sealion7.domain.vehicle.VehicleSourceMerger
import com.sealion7.data.tssdk.TsCarAdapterSource
import com.sealion7.data.bydautosdk.BydAutoDeviceSource
import com.sealion7.data.dilink5sdk.DiLink5ReadOnlySource
import com.sealion7.data.binderreference.BinderReferenceSource
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import javax.inject.Inject
import javax.inject.Singleton
import java.time.Instant
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

interface VehicleDataProvider {
 val id: String
 fun capability(key: MetricKey): VehicleCapability
}

/** No endpoints are invented. This adapter explicitly remains disconnected until an OEM contract exists. */
class BydOfficialVehicleProvider @Inject constructor() : VehicleDataProvider {
 override val id = "byd-official-unconfigured"
 override fun capability(key: MetricKey) = VehicleCapability(key, false, false,
  listOf("BYD tarafından belgelenmiş kullanıcı/yazılım yetkisi sağlanmadı"),
  listOf(AccessScope.OEM_READ), id, false, SupportStatus.NEEDS_INTEGRATION)
}

/** CarHardware API needs a separately approved Android for Cars app context, not a phone context. */
class CarHardwareProvider @Inject constructor() : VehicleDataProvider {
 override val id = "android-for-cars-not-in-mobile"
 override fun capability(key: MetricKey) = VehicleCapability(key, false, false,
  listOf("Telefon uygulamasında CarContext bulunmuyor"), listOf(AccessScope.OEM_READ),
  id, false, SupportStatus.NEEDS_INTEGRATION)
}

class AuthorizedDiagnosticProvider @Inject constructor() : VehicleDataProvider {
 override val id = "read-only-diagnostics-unconfigured"
 override fun capability(key: MetricKey) = VehicleCapability(key, false, false,
  listOf("Yetkili tanı cihazı ve belgeli PID/protokol eşlemesi sağlanmadı"),
  listOf(AccessScope.DIAGNOSTIC_READ), id, false, SupportStatus.NEEDS_INTEGRATION)
}

@Singleton
class DefaultVehicleRepository @Inject constructor(
 private val official: BydOfficialVehicleProvider,
 private val hardware: CarHardwareProvider,
 private val diagnostic: AuthorizedDiagnosticProvider,
 private val aaos: AaosReadOnlyTelemetry,
 private val ts: TsCarAdapterSource,
 private val bydAuto: BydAutoDeviceSource,
 private val diLink5: DiLink5ReadOnlySource,
 private val binderRef: BinderReferenceSource
) : VehicleRepository {
 private val scanMutex = Mutex()
 private val scope = kotlinx.coroutines.CoroutineScope(
  kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)

 // No background vehicle access when the UI stops collecting: WhileSubscribed.
 // All readings are requested via Android's permission-filtered, read-only property API.
 private val snapshot: StateFlow<VehicleSnapshot> = flow {
  val energySession = EnergyConsumptionSession() // reset on new collection, no gaps or fake past data
  while (kotlinx.coroutines.currentCoroutineContext().isActive) {
   // Each source is a separate adapter. OEM sources fail closed without approval.
   val merged = scanMutex.withLock {
    VehicleSourceMerger.merge(listOf(aaos.readOnce(),ts.readOnce(),bydAuto.readOnce(),diLink5.readOnce()))
   }
   emit(energySession.apply(merged))
   kotlinx.coroutines.delay(1500L)
  }
 }.catch { emit(VehicleSnapshot()) }
  .stateIn(scope, SharingStarted.WhileSubscribed(5000L), VehicleSnapshot())

 override fun observeVehicleSnapshot(): Flow<VehicleSnapshot> = snapshot
 override fun observeMetric(key: MetricKey): Flow<MetricState<Double>> =
  snapshot.map { it.number(key) }.distinctUntilChanged()
 override fun observeWarnings(): Flow<List<VehicleAlert>> =
  snapshot.map { it.alerts }.distinctUntilChanged()
 override suspend fun getCapabilities(): List<VehicleCapability> =
  aaos.capabilities() + ts.capabilities() + bydAuto.capabilities() + diLink5.capabilities() + binderRef.capabilities() + TireTemperatureEvidence.capabilities() + EnergyConsumptionEvidence.capabilities()
 override suspend fun refreshIfAuthorized(): VehicleConnectionState = scanMutex.withLock {
  VehicleSourceMerger.merge(listOf(aaos.readOnce(),ts.readOnce(),bydAuto.readOnce(),diLink5.readOnce())).connection
 }
 override suspend fun scanReadOnlySources(): VehicleScanReport = scanMutex.withLock {
  VehicleReadAudit.begin()
  var audit = ReadAuditResult(0,0,0,emptyMap())
  val observations = try {
   listOf(aaos.readOnce(),ts.readOnce(),bydAuto.readForScan(),diLink5.readOnce())
  } finally { audit=VehicleReadAudit.finish() }
  val merged=VehicleSourceMerger.merge(observations)
  VehicleScanReport(
   sourcesChecked=4,
   attemptedGetterCalls=audit.attemptedCalls,
   nonNullResponses=audit.returnedValues,
   distinctInvokedPaths=audit.distinctInvokedMethods,
   liveVehicleMetrics=merged.readings.values.count{it is MetricState.Live<*>},
   staleVehicleMetrics=merged.readings.values.count{it is MetricState.Stale<*>},
   sourceCallCounts=audit.attemptedPaths,
   connection=merged.connection,
   scannedAt=Instant.now()
  )
 }
 override suspend fun sendAllowedCommand(commandName: String): CommandState = CommandState.NotSupported
}

@Module @InstallIn(SingletonComponent::class)
abstract class VehicleBindings {
 @Binds abstract fun bindVehicleRepository(implementation: DefaultVehicleRepository): VehicleRepository
}

@Singleton
class AndroidPhoneContextProvider @Inject constructor(@ApplicationContext private val context: Context) {
 /** GPS movement bearing, not a compass or an OEM vehicle-heading sensor. */
 fun observeGpsDirection(): Flow<MetricState<Double>> = callbackFlow {
  val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
  val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
  if (!granted) {
   trySend(MetricState.PermissionRequired)
   close()
   return@callbackFlow
  }
  if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
   trySend(MetricState.Unavailable("Telefon GPS sağlayıcısı kapalı"))
   close()
   return@callbackFlow
  }
  val listener = LocationListener { location ->
   val age = TimeUnit.NANOSECONDS.toSeconds(android.os.SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos)
   val reliableSpeed = location.hasSpeed() && location.speed >= 1.5f
   val reliableBearing = location.hasBearing() &&
    (!location.hasBearingAccuracy() || location.bearingAccuracyDegrees <= 45f) &&
    location.bearing.isFinite() && location.bearing >= 0f && location.bearing <= 360f
   val state: MetricState<Double> = if (age !in 0..5 || !reliableSpeed || !reliableBearing) {
    MetricState.Unavailable("GPS hareket yönü doğrulanamadı (hareket/konum doğruluğu gerekli)")
   } else {
    val directionDegrees = location.bearing.toDouble() % 360.0
    MetricState.Live(VehicleMetric("phone.gps_bearing", directionDegrees, "°", DataSource.PHONE_GPS,
     Instant.ofEpochMilli(location.time), Instant.now(), DataQuality.VALID, 5,
     SupportStatus.AVAILABLE, AccessScope.PUBLIC_ANDROID,
     providerId = "android-location-gps", methodEvidence = "Location.bearing (GPS hareket yönü)"))
   }
   trySend(state)
  }
  try {
   lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, listener, Looper.getMainLooper())
   trySend(MetricState.Unavailable("GPS hareket yönü bekleniyor"))
  } catch (_: SecurityException) {
   trySend(MetricState.PermissionRequired)
   close()
   return@callbackFlow
  } catch (_: Exception) {
   trySend(MetricState.Error("GPS_YON_KAYNAK_HATASI"))
   close()
   return@callbackFlow
  }
  awaitClose { lm.removeUpdates(listener) }
 }.distinctUntilChanged()

/** Opt-in Android PHONE location; no coordinates are written to disk or sent to ABRP. */
fun observeGpsFix(): Flow<PhoneGpsFixState> = callbackFlow {
 // This extension is installed in the same vehicle data module, but does not depend on OEM APIs.
 val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
 val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
 if (!granted) { trySend(PhoneGpsFixState.PermissionRequired); close(); return@callbackFlow }
 if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
  trySend(PhoneGpsFixState.Unavailable("Telefon GPS kapalı")); close(); return@callbackFlow
 }
 val listener = LocationListener { location ->
  val ageNs = android.os.SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos
  val ageSec = TimeUnit.NANOSECONDS.toSeconds(ageNs)
  val fix = PhoneGpsFixSafety.validated(location.latitude, location.longitude,
   if(location.hasAltitude()) location.altitude else null,
   if(location.hasAccuracy()) location.accuracy else Float.NaN,
   Instant.ofEpochMilli(location.time))
  val state = when {
   ageSec !in 0..5 -> PhoneGpsFixState.Stale(ageSec)
   fix == null -> PhoneGpsFixState.Unavailable("GPS koordinatının doğruluğu yetersiz")
   else -> PhoneGpsFixState.Fresh(fix)
  }
  trySend(state)
 }
 try {
  lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1200L, 1f, listener, Looper.getMainLooper())
  trySend(PhoneGpsFixState.Unavailable("Konum bekleniyor"))
 } catch (_: SecurityException) {
  trySend(PhoneGpsFixState.PermissionRequired); close(); return@callbackFlow
 } catch (_: Exception) {
  trySend(PhoneGpsFixState.Unavailable("GPS servisine erişilemiyor")); close(); return@callbackFlow
 }
 awaitClose { lm.removeUpdates(listener) }
}.distinctUntilChanged()

  fun observeGpsSpeed(): Flow<MetricState<Double>> = callbackFlow {
  val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
  val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
  if (!granted) {
   trySend(MetricState.PermissionRequired)
   close()
   return@callbackFlow
  }
  if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
   trySend(MetricState.Unavailable("Telefonun GPS sağlayıcısı kapalı"))
   close()
   return@callbackFlow
  }
  val listener = LocationListener { location ->
   val age = TimeUnit.NANOSECONDS.toSeconds(android.os.SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos)
   val speed = if (location.hasSpeed()) location.speed.toDouble() * 3.6 else null
   val accuracyOk = !location.hasSpeedAccuracy() || location.speedAccuracyMetersPerSecond <= 3f
   val now = Instant.now()
   val state = if (age !in 0..5 || speed == null || !accuracyOk || speed < 0 || speed > 350) {
    MetricState.Unavailable("Geçerli telefon GPS hızı alınamıyor")
   } else {
    MetricState.Live(VehicleMetric("phone.gps_speed", speed, "km/sa", DataSource.PHONE_GPS,
     Instant.ofEpochMilli(location.time), now, DataQuality.VALID, 5,
     SupportStatus.AVAILABLE, AccessScope.PUBLIC_ANDROID))
   }
   trySend(state)
  }
  try {
   lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, listener, Looper.getMainLooper())
   trySend(MetricState.Unavailable("Telefon GPS konumu bekleniyor"))
  } catch (_: SecurityException) {
   trySend(MetricState.PermissionRequired)
   close()
   return@callbackFlow
  } catch (e: Exception) {
   trySend(MetricState.Error("GPS_KAYNAK_HATASI"))
   close()
   return@callbackFlow
  }
  awaitClose { lm.removeUpdates(listener) }
 }.distinctUntilChanged()
}

