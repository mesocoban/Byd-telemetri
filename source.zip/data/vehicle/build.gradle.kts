plugins {
 id("com.android.library") 
 id("com.google.devtools.ksp")
 id("com.google.dagger.hilt.android") }
android { namespace = "com.sealion7.data.vehicle"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }

}
dependencies { implementation(project(":core:model"))
 implementation(project(":domain:vehicle"))
 implementation(project(":data:ts-sdk"))
 implementation(project(":data:bydauto-sdk"))
 implementation(project(":data:dilink5-sdk"))
 implementation(project(":data:binder-reference"))
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
 implementation("com.google.dagger:hilt-android:2.60.1")
 implementation("androidx.core:core-ktx:1.17.0")
 ksp("com.google.dagger:hilt-compiler:2.60.1")  }
