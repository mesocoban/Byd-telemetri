plugins { id("com.android.library"); id("com.google.dagger.hilt.android"); id("com.google.devtools.ksp") }
android { namespace = "com.sealion7.data.binderreference"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation(project(":core:model")); implementation(project(":domain:vehicle"))
 implementation("com.google.dagger:hilt-android:2.60.1")
 ksp("com.google.dagger:hilt-compiler:2.60.1") }
