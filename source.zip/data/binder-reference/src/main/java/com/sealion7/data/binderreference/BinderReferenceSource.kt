package com.sealion7.data.binderreference

import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.ReadOnlyVehicleSource
import javax.inject.Inject

/**
 * Separate BYDMate autoservice/BMS data source classification.
 * Never guess transaction codes or FIDs; no Binder transaction is issued.
 * The provider exists so unsupported integration is visible to capability discovery.
 */
class BinderReferenceSource @Inject constructor() : ReadOnlyVehicleSource {
 override val id = "bydmate-binder-fid-evidence-only"
 override suspend fun readOnce() = VehicleSnapshot()
 override suspend fun capabilities() = listOf(MetricKey.SOC,MetricKey.VEHICLE_SPEED,
  MetricKey.RANGE).map { key ->
  VehicleCapability(key,false,false,listOf("BYDMate kaynak kodu autoservice Binder/FID erişimini gösteriyor; bu araç için belgelenmiş yetkili FID sözleşmesi yok"),
   listOf(AccessScope.OEM_READ),id,false,SupportStatus.NEEDS_INTEGRATION)
 }
}
