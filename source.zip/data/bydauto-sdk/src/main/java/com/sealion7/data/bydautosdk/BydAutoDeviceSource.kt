package com.sealion7.data.bydautosdk

import android.content.Context
import android.os.SystemClock
import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.ReadOnlyVehicleSource
import com.sealion7.data.oem.OemReadOnlyRuntime
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.Instant
import com.sealion7.core.model.BatteryChargeGetterCatalog
import javax.inject.Inject
import javax.inject.Singleton

/** Read-only BYDAuto probes, based on the 34 DEX signatures in BydCarSettings.apk.
 * All signature/vendor read permissions and OEM provisioning are required.
 * Raw OEM values are diagnostic evidence only, NOT decoded state/warnings/energy units.
 */
@Singleton class BydAutoDeviceSource @Inject constructor(@ApplicationContext ctx:Context):ReadOnlyVehicleSource {
 override val id="bydauto-device-getters"
 private val runtime=OemReadOnlyRuntime(ctx,"BYDAuto")
 private val statistic="android.hardware.bydauto.statistic.BYDAutoStatisticDevice"
 private val speed="android.hardware.bydauto.speed.BYDAutoSpeedDevice"
 private val charging="android.hardware.bydauto.charging.BYDAutoChargingDevice"
 private val perms=mapOf(
  statistic to "android.permission.BYDAUTO_STATISTIC_GET",
  charging to "android.permission.BYDAUTO_CHARGING_GET"
 )
 private val mutex=Mutex()
 private var lastProbeMillis=0L
 private var lastObservations:List<OemRawObservation> = emptyList()
 @Volatile private var confirmedReadings:Set<MetricKey> = emptySet()
 private val keys=listOf(MetricKey.VEHICLE_SPEED, MetricKey.SOC, MetricKey.RANGE,
  MetricKey.ODOMETER,MetricKey.CHARGE_POWER)
 private fun canRead(permission:String)=runtime.approved() && runtime.granted(permission)
 override suspend fun capabilities(): List<VehicleCapability> = keys.map { key ->
  if (runtime.approved() && key in confirmedReadings) runtime.scoped(key,id) else runtime.unauthorized(key,id,
   "BYD üretici izni ve ilgili BYDAUTO_..._GET izni gerekli; metot imzası bulunması yeterli değil")
 }
 override suspend fun readOnce():VehicleSnapshot=readInternal(force=false)
 /** Used by the user's explicit scan: always attempts a fresh permission-gated read. */
 suspend fun readForScan():VehicleSnapshot=readInternal(force=true)
 private suspend fun readInternal(force:Boolean):VehicleSnapshot=withContext(Dispatchers.IO) { mutex.withLock {
  val ms=SystemClock.elapsedRealtime()
  if(force || lastProbeMillis == 0L || ms-lastProbeMillis >= 8000L) {
   // Extensive candidate probes are manual-only: no 100+ getter polling in the driving loop.
   lastObservations=readCandidateGetters() + if(force) readBatteryChargeCandidates() else emptyList()
   lastProbeMillis=ms
  }
  val samples=mutableMapOf<MetricKey,MetricState<Double>>()
  // Previously connected numeric fields are still read with separate OEM permission gates.
  val s=if(canRead(perms.getValue(statistic))) runtime.sdkObject(statistic) else null
  val v=if(canRead("android.permission.BYDAUTO_SPEED_GET")) runtime.sdkObject(speed) else null
  val c=if(canRead(perms.getValue(charging))) runtime.sdkObject(charging) else null
  fun add(k:MetricKey,x:Double?,m:String,ttl:Long) {
   samples[k]=runtime.metric(k,x,DataSource.BYDAUTO_DEVICE,id,m,ttl)
  }
  add(MetricKey.VEHICLE_SPEED,OemTelemetryNormalizer.speed(runtime.numeric(v,"getCurrentSpeed")),"speed.getCurrentSpeed",5)
  // Explicit percentage semantics in the CarSettings getter name; zero is a valid SOC reading.
  val soc=runtime.numeric(s,"getSOCBatteryPercentage")
   ?:runtime.numeric(s,"getElecPercentageValue")
  add(MetricKey.SOC,OemTelemetryNormalizer.soc(soc),"statistic.getSOCBatteryPercentage/getElecPercentageValue",120)
  add(MetricKey.RANGE,OemTelemetryNormalizer.range(runtime.numeric(s,"getElecDrivingRangeValue")),"statistic.getElecDrivingRangeValue",120)
  // getTotalMileageValue is float, with an additional unit-code getter; don't assume kilometers.
  samples[MetricKey.ODOMETER]=MetricState.Unavailable("BYDAuto toplam kilometre ham metodu bulundu; km birimi/ölçeği doğrulanmadı")
  // Charging gun/state return-code semantics have not been verified for this vehicle.
  // No 1..2=charging shortcut and no unitless raw number presented as kW.
  val chargingRaw=runtime.numeric(c,"getChargingPower")
  samples[MetricKey.CHARGE_POWER]=MetricState.Unavailable(
   if(chargingRaw==null) "BYDAuto şarj gücü getter yanıtı yok" else "BYDAuto şarj gücü ham yanıtı var; durum kodu ve kW birimi doğrulanmadı")
  confirmedReadings=samples.filterValues{it is MetricState.Live<*>}.keys.toSet()
  VehicleSnapshot(readings=samples,oemRawObservations=lastObservations,
   connection=if(confirmedReadings.isNotEmpty()) VehicleConnectionState.CONNECTED else VehicleConnectionState.DISCONNECTED)
 } }
 private fun readCandidateGetters():List<OemRawObservation> {
  val objects=mutableMapOf<String,Any?>()
  return CarSettingsGetterCatalog.entries.map { d ->
   val reason=when {
    !canRead(d.permission) -> OemRawStatus.NEEDS_AUTHORIZATION
    !runtime.hasClass(d.className) -> OemRawStatus.SDK_CLASS_ABSENT
    d.requiresWheelIndex -> OemRawStatus.METHOD_NOT_VERIFIED
    else -> null
   }
   if(reason!=null) return@map OemRawObservation(d.id,d.title,d.method,d.className,d.permission,reason,
    explanation=if(d.requiresWheelIndex && reason==OemRawStatus.METHOD_NOT_VERIFIED)
     "Lastik indekslerinin FL/FR/RL/RR karşılığı belirlenmedi; kör indis taraması yapılmaz" else "")
   val device=objects.getOrPut(d.className){ runtime.sdkObject(d.className) }
   if(device==null) return@map OemRawObservation(d.id,d.title,d.method,d.className,d.permission,
    OemRawStatus.DEVICE_NOT_READY)
   // Name and zero arguments are explicitly allowlisted by OemReadOnlyRuntime.
   val value=runtime.call(device,d.method)
   val raw=CarSettingsRawSafety.safeRawDisplay(value)
   OemRawObservation(d.id,d.title,d.method,d.className,d.permission,
    if(raw==null) OemRawStatus.NO_RESPONSE else OemRawStatus.RAW_VALUE_UNVERIFIED,
    rawValue=raw,observedAt=if(raw==null)null else Instant.now(),
    explanation=if(raw==null) "Okuma reddedilmiş, metot desteklenmiyor veya null döndü" else
     "Ham BYD cevabı: ölçek, enum, arıza aktif/pasif anlamı doğrulanmadı")
  }
 }

 /** Manual, bounded battery/charge discovery. The candidate owner class is a hypothesis;
  * a method is called only when OEM authorization + Android permission + public zero-arg
  * getter have ALL been established. No actuator/setter or hidden API is invoked.
  * Raw return values never generate vehicle alerts or physical units.
  */
 private fun readBatteryChargeCandidates():List<OemRawObservation> {
  val devices=mutableMapOf<String,Any?>()
  return BatteryChargeGetterCatalog.entries.map { d ->
   val status=when {
    !canRead(d.candidatePermission) -> OemRawStatus.NEEDS_AUTHORIZATION
    !runtime.hasClass(d.candidateClass) -> OemRawStatus.SDK_CLASS_ABSENT
    else -> null
   }
   if(status!=null) return@map OemRawObservation(d.id,d.method,d.method,
    d.candidateClass,d.candidatePermission,status,
    explanation="Firmware metot adayı; servis/sınıf eşlemesi araçta doğrulanmadı")
   val obj=devices.getOrPut(d.candidateClass){runtime.sdkObject(d.candidateClass)}
   if(obj==null) return@map OemRawObservation(d.id,d.method,d.method,
    d.candidateClass,d.candidatePermission,OemRawStatus.DEVICE_NOT_READY,
    explanation="BYDAuto servis erişimi yok veya sınıf yerleşimi eşleşmedi")
   val accessible=obj.javaClass.methods.any { it.name==d.method && it.parameterCount==0 }
   if(!accessible) return@map OemRawObservation(d.id,d.method,d.method,
    d.candidateClass,d.candidatePermission,OemRawStatus.METHOD_NOT_VERIFIED,
    explanation="Public sıfır parametreli getter bulunamadı; alternatif TS/SDK sınıfı araştırılmalı")
   val raw=CarSettingsRawSafety.safeRawDisplay(runtime.call(obj,d.method))
   OemRawObservation(d.id,d.method,d.method,d.candidateClass,d.candidatePermission,
    if(raw==null) OemRawStatus.NO_RESPONSE else OemRawStatus.RAW_VALUE_UNVERIFIED,
    rawValue=raw,observedAt=if(raw==null)null else Instant.now(),
    explanation="Ham aday cevap; birim/ölçek ve kod semantiği doğrulanmadı")
  }
 }
}
