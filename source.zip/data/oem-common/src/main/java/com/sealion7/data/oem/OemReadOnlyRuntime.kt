package com.sealion7.data.oem

import android.content.Context
import android.content.pm.PackageManager
import com.sealion7.core.model.*
import java.time.Instant

/**
 * OEM classes are NOT public Android SDK; no privilege escalation or protected API bypass.
 * Explicit OEM approval metadata + Android permission are *necessary*, never sufficient.
 * Real service may still reject access. A missing permission means no reflection or binder use.
 */
class OemReadOnlyRuntime(private val context: Context, private val auditSource: String = "OEM") {
 companion object {
  const val APPROVAL_KEY = "com.sealion7.companion.OEM_READ_APPROVED"
  const val VENDOR_READ = "android.car.permission.CAR_VENDOR_EXTENSION"
 }
 fun approved(): Boolean = runCatching {
  val app = context.packageManager.getApplicationInfo(context.packageName, PackageManager.GET_META_DATA)
  app.metaData?.getBoolean(APPROVAL_KEY, false) == true
 }.getOrDefault(false)
 fun granted(permission: String): Boolean =
  context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
 fun mayRead(): Boolean = approved() && granted(VENDOR_READ)
 /** TS CarAdapter exposes its own public app-facing SDK as used in the Sealion 7 ABRP client.
  * Do NOT require an unrelated AAOS CAR_VENDOR_EXTENSION permission to attempt its
  * public connect/read path. The TS service itself remains the authorization authority:
  * SecurityException/no binder/no method result never becomes a live metric.
  * This does not grant or bypass a BYDAUTO signature permission.
  */
 fun mayReadPublicTs(): Boolean = hasClass("com.ts.lib.caradapter.CarAdapterManager")
 fun hasClass(name: String): Boolean = runCatching { Class.forName(name) }.isSuccess
 fun sdkObject(className: String): Any? = runCatching {
  val clazz = Class.forName(className)
  clazz.getMethod("getInstance", Context::class.java).invoke(null, context.applicationContext)
 }.getOrNull()
 fun call(target: Any?, name: String, vararg args: Any): Any? {
  if(target == null) return null
  return runCatching {
   // Only public methods; never setAccessible, SystemProperties, Runtime.exec, or hidden API exemptions.
   val method = target.javaClass.methods.firstOrNull { m ->
    m.name == name && m.parameterCount == args.size &&
     m.name in setOf("getCurrentSpeed", "getSpeedValue", "getElecPercentageValue",
      "getElecDrivingRangeValue", "getTotalMileageValue", "getMileageNumberOne",
      "getMileageNumberTwo", "getMileageUnit", "getChargingPower",
      "getChargerState", "getChargingGunState", "getTempratureOut",
      "getOutCarTemperature", "getTemprature",
      "getDriverMotorTorque", "getDriverMotorSpeed",
      "getMotorMCUGeneratrixCurrent", "getMotorMCUGeneratrixVolt",
      "getDriveBrakingRecovery", "getEnergyFeedback",
      "getABSFaultWarningLight", "getBatteryPackEnergy", "getBrakePedalMode", "getBrakeSysFaultLightState", "getChargeVoltage",
      "getChargingGunState", "getChargingPower", "getChargingRestTime", "getCurrentGear", "getCurrentTripElec",
      "getCurrentTripElecUnit", "getCurrentTripMileage", "getCurrentTripMileageUnit", "getDriveMode", "getESPFailWarnLightState",
      "getEnergyFeedback", "getHeadlampFailWarnLightState", "getInstantElecConValue", "getInstrumentBrightness", "getInstrumentTheme",
      "getLast50KMElectricConAvg", "getMalfunctionInfos", "getPowerBatFailWarnLightState", "getSOCBatteryPercentage", "getSRSFaultWarningLight",
      "getSteeringSYSFailWarnLightState", "getTotalMileageValue", "getTripEnergyConAvg", "getTyrePressureSYSFailWarnLightState", "getTyrePressureSysFailHint",
      "getTyrePressureValue", "getTyrePressureWarn",
      "getCarAdapterManager", "getShiftMode", "setOnManagerConnChangedListener",
      "isCarServiceBound", "connect", "disconnect", "getInstance",
      "getBatteryPercent", "getRemainingBatteryPower", "getEVRemainingBatteryPower", "getBatteryCapcity", "getBatteryLevelNum", "getBatteryVoltageLevel", "getBatteryType", "getBatteryManagementDeviceState", "getBatteryHealthStatus", "getChargeBatteryLevelBegin", "getChargeBatteryTemp", "getChargeBatteryLimitTemp", "getCarPlanBatteryHeatState", "getBatteryLowVoltageState", "getChargerWorkState", "getChargingState", "getChargingType", "getChargingMode", "getChargePower", "getExternalChargingPower", "getChargeVoltageMax", "getChargeElectric", "getChargingCapacity", "getChargeRestTime", "getChargePercent", "getChargerFaultState", "getChargeAndDischargeSystemState", "getChargingGunNotInsertedState", "getChargingPort", "getChargingCapState", "getChargingCapStateLeft", "getChargingCapStateRight", "getChargingPortLockRebackState", "getChargePortCoverTip", "getPowerBatteryChargeConnectIndicatorState", "getACChargingLimit", "getChargeLimit", "getChargeStopCapacityState", "getChargeStopSwitchState", "getChargeStopSupportConfig", "getChargeLimitSupport", "getSOCTarget", "getSocTarget", "getChargeBatteryLevelNumLimit", "getChargeStopCapacityFullHint", "getChargingScheduleEnableState", "getChargingScheduleState", "getChargingScheduleTime", "getChargingSchedulePeriod", "getChargingStartAndEndTime", "getNextChargingTime", "getChargingTimerInfo", "getChargingRestTimeHourR", "getChargingRestTimeMinuteR", "getChargingScheduleTimeDayR", "getChargingScheduleTimeMonthR", "getChargingScheduleTimeYearR", "getChargingScheduleTimeHourR", "getChargingScheduleTimeMinuteR", "getChargePreheatState", "getChargePreheatAllow", "getChargePreheatSupport", "getChargeTempCtlState", "getDischargeState", "getCarDischargeState", "getDischargeVoltage", "getDischargeElectric", "getDischargeElecEnergy", "getDischargeCapacity", "getDischargeLimit", "getDischargeLimitMin", "getDischargeRemainTime", "getDischargeTotalTime", "getDischargeRequestState", "getDischargeOverReason", "getDischargeWarningState", "getDischargeGunConnectStation", "getDischargeGunTimer", "getVtovDischargeConnectState", "getVtovDischargeQuantity", "getVtovDischargeLimitVal", "getV2GChargeStatus", "getV2GOutputPower", "getAverageElectricConsumption", "getTripElecConAvg", "getTripLast50KMElectricConAvg", "getTotalElecConValue", "getElecConsUnit", "getTripAcPercent", "getTripDrivePercent", "getTripElecAppliancePercent", "getTripOtherPercent", "getEVTripACPercent50KM", "getEVTripDrivePercent50KM", "getEVTripElecAppliancePercent50KM", "getEVTripOtherPercent50KM", "getEnergyCurve", "getEnergyElectricCurveX", "getEnergyElectricCurveY", "getPowerBatFailWarnLightColor", "getPowerBatteryHeatWarnLightState", "getPowerBatteryHeatWarnLightColor", "getLowPowerBatteryWarnLightState", "getPowerSysFailWarnLightState", "getDrivePowerLimitIndicatorState", "getCarDischargeLowWarn", "getBMSWakeNoSenseCharge", "getOBCWakeNoSenseCharge", "getNoSenseChargeState", "getSmartChargingState", "getChargeToggleGuard", "getWirelessChargingState")
   } ?: return null
   if(name.startsWith("get") && name !in setOf("getInstance","getCarAdapterManager"))
    VehicleReadAudit.attempt(auditSource,name)
   method.invoke(target,*args).also { value ->
    if(value != null && name.startsWith("get") && name !in setOf("getInstance","getCarAdapterManager"))
     VehicleReadAudit.nonNull()
   }
  }.getOrNull()
 }
 fun numeric(target: Any?, method: String): Double? =
  (call(target,method) as? Number)?.toDouble()
 fun metric(key:MetricKey,value:Double?,source:DataSource,provider:String,method:String,
  freshFor:Long): MetricState<Double> {
  if(value==null || !value.isFinite())return MetricState.Unavailable("Geçerli ölçüm yok ($provider)")
  val now=Instant.now()
  return MetricState.Live(VehicleMetric(key.name,value,key.unit,source,now,now,
   DataQuality.VALID,freshFor,SupportStatus.AVAILABLE,AccessScope.OEM_READ,
   providerId=provider,methodEvidence=method,deviceTimestampVerified=false))
 }
 fun unauthorized(key:MetricKey,id:String,explanation:String): VehicleCapability =
  VehicleCapability(key,false,false,listOf(explanation),listOf(AccessScope.OEM_READ),id,false,
   SupportStatus.NEEDS_AUTHORIZATION)
 fun scoped(key:MetricKey,id:String): VehicleCapability = VehicleCapability(key,true,false,
  listOf("OEM yetkisi kontrol edildi; getter'ın gerçek ölçüm vermesi ayrıca doğrulanmalıdır"),
  listOf(AccessScope.OEM_READ),id,false,SupportStatus.AVAILABLE)
}
