plugins { id("com.android.library") }
android { namespace = "com.sealion7.data.oem"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation(project(":core:model")); implementation("androidx.core:core-ktx:1.17.0") }
