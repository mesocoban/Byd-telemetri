import com.sealion7.core.model.VehicleReadAudit

fun main() {
    val empty = VehicleReadAudit.finish()
    check(empty.attemptedCalls == 0)
    VehicleReadAudit.begin()
    VehicleReadAudit.attempt("TS", "getCurrentSpeed")
    VehicleReadAudit.nonNull()
    VehicleReadAudit.attempt("TS", "getCurrentSpeed")
    VehicleReadAudit.attempt("AAOS", "TIRE_PRESSURE/2")
    val result = VehicleReadAudit.finish()
    check(result.attemptedCalls == 3)
    check(result.returnedValues == 1)
    check(result.distinctInvokedMethods == 2)
    check(result.attemptedPaths["TS"] == 2)
    check(result.attemptedPaths["AAOS"] == 1)
    check(VehicleReadAudit.finish().attemptedCalls == 0)
    println("V5.4: 7 read-audit checks passed")
}
