package power.validation

import com.sealion7.core.model.*
import java.time.Instant

fun main() {
    val conv = PowerTelemetryNormalizer::batteryConsumptionKwFromAaosRate
    check(conv(-12_500_000.0) == 12.5)
    check(conv(-750_000.0) == 0.75)
    check(conv(-0.0) == 0.0)
    check(conv(0.0) == 0.0)
    check(conv(20_000_000.0) == null) // charging cannot be shown as discharge
    check(conv(Double.NaN) == null)
    check(conv(Double.POSITIVE_INFINITY) == null)
    check(conv(null) == null)
    check(conv(-1_200_000_000.0) == null)

    val keys = listOf(MetricKey.TRACTION_POWER, MetricKey.BATTERY_CONSUMPTION_POWER, MetricKey.REGEN_POWER)
    check(keys.all { it.unit == "kW" })
    check(keys.distinct().size == 3)
    check(MetricKey.REGEN_POWER != MetricKey.REGEN_SETTING)
    check(MetricKey.POWER != MetricKey.TRACTION_POWER)
    check(VehicleFieldRegistry.get("power.traction")?.labelTr == "Çekiş gücü")
    check(VehicleFieldRegistry.get("power.regen")?.unitOrType == "kW")
    check(VehicleFieldRegistry.all.size == 38)
    check(BydPowerSourceEvidence.traction.any { "getDriverMotorTorque" in it })
    check(BydPowerSourceEvidence.regen.any { "getDriveBrakingRecovery" in it })
    println("18/18 power and provenance checks OK")
}
