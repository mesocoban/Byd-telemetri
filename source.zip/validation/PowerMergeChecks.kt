package power.validation

import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.VehicleSourceMerger
import java.time.Instant

fun main() {
    val now = Instant.now()
    fun metric(key: MetricKey, value: Double): MetricState.Live<Double> = MetricState.Live(
        VehicleMetric(key.name, value, key.unit, DataSource.AAOS_CAR_HARDWARE, now, now,
            DataQuality.VALID, 10, SupportStatus.AVAILABLE, AccessScope.OEM_READ,
            "aaos-car-property-read-only", "source sample")
    )
    val aaos = VehicleSnapshot(readings = mapOf(
        MetricKey.BATTERY_CONSUMPTION_POWER to metric(MetricKey.BATTERY_CONSUMPTION_POWER, 12.5),
        MetricKey.BATTERY_NET_POWER to metric(MetricKey.BATTERY_NET_POWER, -12.5)),
        connection = VehicleConnectionState.CONNECTED)
    val emptyByd = VehicleSnapshot(readings = mapOf(
        MetricKey.TRACTION_POWER to MetricState.Unavailable("motor unit not verified"),
        MetricKey.REGEN_POWER to MetricState.Unavailable("regen kW not verified")),
        connection = VehicleConnectionState.DISCONNECTED)
    val merged = VehicleSourceMerger.merge(listOf(aaos, emptyByd))
    check((merged.number(MetricKey.BATTERY_CONSUMPTION_POWER) as MetricState.Live).metric.value == 12.5)
    check(merged.number(MetricKey.TRACTION_POWER) !is MetricState.Live)
    check(merged.number(MetricKey.REGEN_POWER) !is MetricState.Live)
    check(merged.number(MetricKey.BATTERY_NET_POWER) is MetricState.Live)
    check(merged.connection == VehicleConnectionState.CONNECTED)
    println("5/5 repository merge power isolation checks OK")
}
