import com.sealion7.core.model.*
import com.sealion7.domain.vehicle.VehicleSourceMerger
import java.time.Instant

private val now = Instant.parse("2026-10-25T10:00:00Z")
private val wheel = MetricKey.TIRE_FL

private fun reading(value: Double, key: MetricKey = wheel, offsetSeconds: Long = 1,
                    providerId: String = DataSource.AAOS_CAR_HARDWARE.name,
                    state: Boolean = true): VehicleSnapshot {
    val metric = VehicleMetric(key.name, value, "kPa", DataSource.AAOS_CAR_HARDWARE,
        now.minusSeconds(offsetSeconds), now.minusSeconds(offsetSeconds), DataQuality.VALID, 30,
        SupportStatus.AVAILABLE, AccessScope.OEM_READ, providerId)
    return VehicleSnapshot(readings = mapOf(key to if (state) MetricState.Live(metric) else MetricState.Stale(metric, 90)))
}
private fun limit(key: MetricKey = wheel, min: Double = 220.0,
                  provider: String = DataSource.AAOS_CAR_HARDWARE.name) = TirePressureLimit(
    key, min, DataSource.AAOS_CAR_HARDWARE, provider, "TIRE_PRESSURE per-wheel OEM min")

fun main() {
    var checks = 0
    fun verify(condition: Boolean, message: String) { check(condition) { message }; checks++ }
    val low = reading(210.0).copy(tirePressureLimits = mapOf(wheel to limit()))
    verify(TirePressureSafety.assess(low, now).first().status == TirePressureStatus.LOW, "low")
    verify(TirePressureSafety.alerts(low, now).size == 1, "alert for low")
    val normal = reading(220.0).copy(tirePressureLimits = mapOf(wheel to limit()))
    verify(TirePressureSafety.assess(normal, now).first().status == TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT, "equal should not warn")
    verify(TirePressureSafety.alerts(normal, now).isEmpty(), "no alert for limit")
    val missing = reading(195.0)
    verify(TirePressureSafety.assess(missing, now).first().status == TirePressureStatus.LIMIT_UNKNOWN, "missing min")
    verify(TirePressureSafety.alerts(missing, now).isEmpty(), "no guessed alarm")
    val wrongWheel = reading(190.0).copy(tirePressureLimits = mapOf(wheel to limit(MetricKey.TIRE_FR)))
    verify(TirePressureSafety.assess(wrongWheel, now).first().status == TirePressureStatus.LIMIT_UNKNOWN, "wrong wheel")
    val wrongProvider = reading(190.0).copy(tirePressureLimits = mapOf(wheel to limit(provider="OTHER")))
    verify(TirePressureSafety.alerts(wrongProvider, now).isEmpty(), "no cross provider")
    val old = reading(180.0, offsetSeconds = 40).copy(tirePressureLimits = mapOf(wheel to limit()))
    verify(TirePressureSafety.assess(old, now).first().status == TirePressureStatus.READING_STALE, "expired live")
    verify(TirePressureSafety.alerts(old, now).isEmpty(), "stale no active alert")
    val nonfinite = reading(Double.NaN).copy(tirePressureLimits = mapOf(wheel to limit()))
    verify(TirePressureSafety.assess(nonfinite, now).first().status == TirePressureStatus.INVALID_READING, "not finite")
    val disallowed = low.copy(readings = mapOf(wheel to MetricState.PermissionRequired))
    verify(TirePressureSafety.alerts(disallowed, now).isEmpty(), "permission required")
    val other = reading(210.0, MetricKey.TIRE_FR).copy(tirePressureLimits = mapOf(MetricKey.TIRE_FR to limit(MetricKey.TIRE_FR)))
    verify(TirePressureSafety.alerts(other, now).single().code == "TPMS_LOW_TIRE_FR", "per wheel label")
    val merged = VehicleSourceMerger.merge(listOf(low, VehicleSnapshot()))
    // Merger uses real current time, so only assert matching per-wheel metadata; no fake cross-source substitution.
    verify(merged.tirePressureLimits[wheel] != null, "merged threshold")
    verify(merged.number(wheel) is MetricState.Live, "merged live reading")
    verify(VehicleSourceMerger.merge(listOf(missing, VehicleSnapshot())).tirePressureLimits.isEmpty(), "no inferred threshold")
    val invalidLimit = reading(190.0).copy(tirePressureLimits = mapOf(wheel to limit(min = 0.0)))
    verify(TirePressureSafety.alerts(invalidLimit, now).isEmpty(), "invalid threshold fails closed")
    println("TPMS checks passed: $checks")
}
