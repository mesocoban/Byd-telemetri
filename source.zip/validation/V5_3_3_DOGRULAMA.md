# V5.3.3 doğrulama notları

- Ayrı Kotlin/JVM kontrolü: `validation/TirePressureChecks.kt` ile 17 senaryo başarılı (düşük, sınıra eşit, eşik yok, yanlış tekerlek, kaynak farklı, eski veri, NaN, izin engeli, kaynak birleştirme vb.).
- Android Studio JUnit testleri kaynaklara eklendi: `TirePressureSafetyTest.kt`.
- Full Gradle APK denemesi: **başlamadı**. Bu çalışma ortamında Gradle 9.6.0 dağıtımı `services.gradle.org` adresine DNS erişimi olmadığı için indirilemedi; log: `validation/v5_3_3_build_attempt.log`.
- AAOS OEM min eşik okuma kodu ve Compose UI kaynakları tam Android SDK ile derlenemedi, gerçek araçta test edilmedi.
- OEM `getTyrePressureWarn...` kodları çözümlenmediği için entegre edilmedi.
