import com.sealion7.core.model.*
import java.time.Instant
import kotlin.math.abs

private var checks = 0
private fun checkThat(condition: Boolean, info: String) {
    checks++
    if (!condition) error("FAIL $checks: $info")
}
private fun close(actual: Double, expected: Double, tol: Double = 0.00001): Boolean = abs(actual - expected) < tol
private fun m(key: MetricKey, value: Double, at: Instant, source: DataSource = DataSource.AAOS_CAR_HARDWARE,
              unit: String = key.unit, provider: String = "aaos-read-only"): MetricState.Live<Double> =
    MetricState.Live(VehicleMetric(
        id = key.name, value = value, unit = unit, source = source,
        sourceTimestamp = at, receivedAt = at, quality = DataQuality.VALID, freshnessSeconds = 10,
        supportStatus = SupportStatus.AVAILABLE, accessScope = AccessScope.OEM_READ,
        providerId = provider, methodEvidence = "read-only-verified-property"
    ))
private fun s(at: Instant, kw: Double = 20.0, speed: Double = 100.0,
              tripA: Double? = null, tripB: Double? = null,
              regen: Double? = null): VehicleSnapshot = VehicleSnapshot(readings = buildMap {
    put(MetricKey.BATTERY_CONSUMPTION_POWER, m(MetricKey.BATTERY_CONSUMPTION_POWER, kw, at))
    put(MetricKey.VEHICLE_SPEED, m(MetricKey.VEHICLE_SPEED, speed, at))
    if (tripA != null) put(MetricKey.TRIP_A, m(MetricKey.TRIP_A, tripA, at))
    if (tripB != null) put(MetricKey.TRIP_B, m(MetricKey.TRIP_B, tripB, at))
    if (regen != null) put(MetricKey.REGEN_POWER, m(MetricKey.REGEN_POWER, regen, at))
})
private fun value(snapshot: VehicleSnapshot, k: MetricKey): Double? =
    (snapshot.number(k) as? MetricState.Live<Double>)?.metric?.value

fun main() {
    checkThat(close(EnergyConsumptionMath.instantaneousKwhPer100Km(20.0, 100.0)!!, 20.0), "20kW at 100kmh")
    checkThat(EnergyConsumptionMath.instantaneousKwhPer100Km(15.0, 0.0) == null, "zero speed excluded")
    checkThat(EnergyConsumptionMath.instantaneousKwhPer100Km(15.0, 9.9) == null, "below 10 excluded")
    checkThat(EnergyConsumptionMath.instantaneousKwhPer100Km(-15.0, 80.0) == null, "negative input refused")
    checkThat(EnergyConsumptionMath.instantaneousKwhPer100Km(Double.NaN, 80.0) == null, "nan refused")
    checkThat(close(EnergyConsumptionMath.instantaneousKwhPer100Km(0.0, 60.0)!!, 0.0), "zero draw okay")
    checkThat(EnergyConsumptionMath.energyKwh(20.0, 30.0) == null, "no long-gap energy")
    checkThat(close(EnergyConsumptionMath.energyKwh(20.0, 2.0)!!, 20.0*2/3600), "energy unit")
    checkThat(EnergyConsumptionMath.averageKwhPer100Km(1.0, 0.0) == null, "avg no distance")
    checkThat(close(EnergyConsumptionMath.averageKwhPer100Km(2.0, 10.0)!!, 20.0), "avg 20")
    val t = Instant.parse("2026-10-25T08:00:00Z")
    val tracker = EnergyConsumptionSession()
    val start = tracker.apply(s(t), t)
    checkThat(close(value(start, MetricKey.INSTANT_CONSUMPTION)!!, 20.0), "instant derived")
    checkThat(value(start, MetricKey.TRACKED_ENERGY_CONSUMED) == null, "no invented energy first sample")
    val second = tracker.apply(s(t.plusSeconds(2)), t.plusSeconds(2))
    checkThat(close(value(second, MetricKey.TRACKED_ENERGY_CONSUMED)!!, 20*2.0/3600), "integrated energy")
    checkThat(close(value(second, MetricKey.TRACKED_AVG_CONSUMPTION)!!, 20.0), "monitored average")
    checkThat(value(second, MetricKey.LAST_TRIP_AVG_CONSUMPTION) == null, "past trip is not invented")
    checkThat(value(second, MetricKey.RECOVERED_ENERGY) == null, "battery draw is not regen")
    val phone = s(t.plusSeconds(3)).copy(readings = s(t.plusSeconds(3)).readings +
        (MetricKey.VEHICLE_SPEED to m(MetricKey.VEHICLE_SPEED, 60.0, t.plusSeconds(3), DataSource.PHONE_GPS)))
    checkThat(value(EnergyConsumptionSession().apply(phone, t.plusSeconds(3)), MetricKey.INSTANT_CONSUMPTION) == null, "GPS cannot stand in for car")
    val badUnit = s(t).copy(readings = s(t).readings +
        (MetricKey.VEHICLE_SPEED to m(MetricKey.VEHICLE_SPEED, 100.0, t, unit = "mph")))
    checkThat(value(EnergyConsumptionSession().apply(badUnit, t), MetricKey.INSTANT_CONSUMPTION) == null, "mph not kmh")
    val disjoint = s(t).copy(readings = s(t).readings +
        (MetricKey.VEHICLE_SPEED to m(MetricKey.VEHICLE_SPEED, 100.0, t.minusSeconds(4))))
    checkThat(value(EnergyConsumptionSession().apply(disjoint, t), MetricKey.INSTANT_CONSUMPTION) == null, "old car speed")
    val stopped = EnergyConsumptionSession().apply(s(t, speed = 0.0), t)
    checkThat(value(stopped, MetricKey.INSTANT_CONSUMPTION) == null, "stopped no instantaneous distance ratio")
    val trips = EnergyConsumptionSession()
    trips.apply(s(t, tripA = 40.0, tripB = 70.0), t)
    val tripLater = trips.apply(s(t.plusSeconds(2), tripA=40.1, tripB=70.1), t.plusSeconds(2))
    checkThat(value(tripLater, MetricKey.TRIP_A_ENERGY_CONSUMED) != null, "verified Trip A window")
    checkThat(value(tripLater, MetricKey.TRIP_A_AVG_CONSUMPTION) != null, "Trip A observed average")
    checkThat(value(tripLater, MetricKey.TRIP_B_AVG_CONSUMPTION) != null, "Trip B observed average")
    val noTrips = EnergyConsumptionSession()
    noTrips.apply(s(t), t)
    checkThat(value(noTrips.apply(s(t.plusSeconds(2)),t.plusSeconds(2)), MetricKey.TRIP_A_ENERGY_CONSUMED) == null, "not invent Trip A")
    val recovery = EnergyConsumptionSession()
    recovery.apply(s(t,regen=10.0),t)
    val recovered = recovery.apply(s(t.plusSeconds(2), regen=10.0),t.plusSeconds(2))
    checkThat(close(value(recovered, MetricKey.RECOVERED_ENERGY)!!, 10*2.0/3600), "regen measured kW only")
    val gap = EnergyConsumptionSession()
    gap.apply(s(t),t)
    val afterGap = gap.apply(s(t.plusSeconds(20)),t.plusSeconds(20))
    checkThat(value(afterGap, MetricKey.TRACKED_ENERGY_CONSUMED)==null, "disconnect gap not integrated")
    checkThat(EnergyConsumptionEvidence.capabilities().size == 9, "all 9 discovery definitions")
    println("OK: $checks checks")
}
