# V5.3.1 doğrulama

- Kotlin pusula yönü hesaplama: 11/11 kontrol geçti (`kotlinc`, saf Kotlin).
- Android SDK tabanlı tam APK derlemesi: **gerçekleştirilemedi**. `services.gradle.org` DNS erişimi yok; wrapper Gradle dağıtımını indiremedi.
- Gerçek BYD Sealion 7 araç testi: **yapılmadı**.
- V5.3 7 grup, OEM okuma izinleri, salt-okunur sağlayıcılar korunmuştur.
- Yön bilgisi OEM kaynak değil; GPS hareket yönü ve yalnız koşullar sağlandığında canlı.
- Süre cihazın yerel HH:mm saatidir, yolculuk süresi değildir.
- Rejeneratif frenleme görünen etikettir; telemetri yalnız rejenerasyon ayar seviyesi (kademe).
