import com.sealion7.core.model.*
fun main(){
 check(AaosExtendedNormalizer.batteryNetKw(12_500_000.0)==12.5)
 check(AaosExtendedNormalizer.batteryNetKw(-40_000_000.0)==-40.0)
 check(AaosExtendedNormalizer.batteryNetKw(Double.NaN)==null)
 check(AaosExtendedNormalizer.tireKpa(250.0)==250.0)
 check(AaosExtendedNormalizer.tireKpa(-1.0)==null)
 check(AaosExtendedNormalizer.tireKpa(2000.0)==null)
 check(AaosExtendedNormalizer.batteryTempC(30.0)==30.0)
 check(AaosExtendedNormalizer.batteryTempC(200.0)==null)
 check(AaosExtendedNormalizer.regenSetting(2.0)==2.0)
 check(AaosExtendedNormalizer.regenSetting(2.5)==null)
 check(MetricKey.entries.map { it.name }.toSet().size==MetricKey.entries.size)
 println("PASS: 11 bağımsız Kotlin model denetimi")
}
