#!/usr/bin/env python3
# Existing V5.3.5 project directory, no third-party dependencies needed.
import argparse
from pathlib import Path

RELATIVE = Path("feature/driving/src/main/java/com/sealion7/feature/driving/DrivingDashboard.kt")
IMPORT = "import androidx.compose.ui.geometry.Offset\n"
ANCHOR = "import androidx.compose.ui.Modifier\n"

def fix(root: Path):
    target = root / RELATIVE
    if not target.is_file():
        raise FileNotFoundError(f"Sürüş ekranı bulunamadı: {target}")
    original = target.read_text(encoding="utf-8")
    if IMPORT in original:
        print("Zaten düzeltilmiş; değişiklik gerekmedi:", target)
        return
    if original.count(ANCHOR) != 1 or "Offset(" not in original:
        raise ValueError("Dosya beklenen V5.3.5 kaynağı değil; elle kontrol edin.")
    backup = target.with_suffix(target.suffix + ".bak")
    if not backup.exists():
        backup.write_text(original, encoding="utf-8")
    target.write_text(original.replace(ANCHOR, ANCHOR + IMPORT), encoding="utf-8")
    print("Eksik Offset importu eklendi. Yedek:", backup)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="V5.3.5 Kotlin Sürüş derleme importunu düzelt")
    p.add_argument("project_root", type=Path, help="Android Studio proje kökü")
    fix(p.parse_args().project_root)
