#!/usr/bin/env python3
"""Local, conservative fix for separately maintained SealionTelemetry ExpressiveLight.
Usage: python expressivelight_compile_fix.py "C:/.../SealionTelemetry"
Makes *.v5-backup copies before editing. Never changes telemetry/firmware code.
"""
from pathlib import Path
import sys

if len(sys.argv)!=2:
 print('Kullanım: python expressivelight_compile_fix.py "C:/path/to/SealionTelemetry"')
 raise SystemExit(2)
root=Path(sys.argv[1])
activity=root/'app/src/main/java/com/sealion/telemetry/MainActivity.kt'
build=root/'app/build.gradle.kts'
if not activity.is_file() or not build.is_file():
 raise SystemExit('Kaynak MainActivity.kt veya app/build.gradle.kts yok; yanlış proje klasörü seçildi.')
s=activity.read_text(encoding='utf-8')
# Correct Kotlin package import, independent from `androidx.compose.animation.core.*`.
wrong='import androidx.compose.animation.core.animateColorAsState'
right='import androidx.compose.animation.animateColorAsState'
if wrong in s:
 updated=s.replace(wrong,right)
elif right not in s:
 lines=s.splitlines(keepends=True)
 first_import=next((i for i,ln in enumerate(lines) if ln.startswith('import ')),None)
 if first_import is None: raise SystemExit('Kotlin import bloğu bulunamadı; elle kontrol gerekli.')
 lines.insert(first_import,right+'\n')
 updated=''.join(lines)
else: updated=s
if updated != s:
 activity.with_name(activity.name+'.v5-backup').write_text(s,encoding='utf-8')
 activity.write_text(updated,encoding='utf-8')
 print('MainActivity.kt: animateColorAsState import düzeltildi')
else: print('MainActivity.kt: doğru import zaten mevcut')
g=build.read_text(encoding='utf-8')
if 'androidx.compose.animation:animation' not in g:
 pos=g.find('dependencies {')
 if pos<0: raise SystemExit('Gradle dependencies bloğu yok; elle kontrol gerekli.')
 pos+=len('dependencies {')
 new=g[:pos]+'\n    implementation("androidx.compose.animation:animation")'+g[pos:]
 build.with_name(build.name+'.v5-backup').write_text(g,encoding='utf-8')
 build.write_text(new,encoding='utf-8')
 print('app/build.gradle.kts: Compose animation bağımlılığı eklendi')
else: print('app/build.gradle.kts: Compose animation bağımlılığı mevcut')
print('Sonrasında Gradle Sync -> :app:compileDebugKotlin komutunu çalıştırın.')
