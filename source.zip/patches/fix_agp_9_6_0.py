#!/usr/bin/env python3
"""User-owned V5 project: patch only two Android Gradle plugin lines.
Usage: python fix_agp_9_6_0.py "C:/BYD S7 izleyici/Sealion7Companion_Android17_Telemetri_V5"
Only edits root build.gradle.kts, creates timestamped .bak.
"""
import sys, pathlib, shutil, datetime

def main():
    if len(sys.argv) != 2:
        print('Kullanım: python fix_agp_9_6_0.py <proje_klasoru>'); return 2
    root = pathlib.Path(sys.argv[1]); file = root / 'build.gradle.kts'
    if not file.is_file(): print('Kök build.gradle.kts bulunamadı:',file); return 2
    text=file.read_text(encoding='utf-8')
    pairs={
     'id("com.android.application") version "9.6.0" apply false': 'id("com.android.application") version "9.4.0" apply false',
     'id("com.android.library") version "9.6.0" apply false': 'id("com.android.library") version "9.4.0" apply false',
    }
    if all(new in text for new in pairs.values()): print('Düzeltme zaten uygulanmış'); return 0
    if not all(old in text for old in pairs):
        print('Beklenen V5 plugin satırları bulunamadı; güvenlik için değiştirilmedi'); return 1
    backup=file.with_name(file.name+'.bak.'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
    shutil.copy2(file,backup)
    for old,new in pairs.items(): text=text.replace(old,new,1)
    file.write_text(text,encoding='utf-8')
    print('Düzeltildi:',file,'\nYedek:',backup)
    return 0

if __name__=='__main__': raise SystemExit(main())
