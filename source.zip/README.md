# BYD Sealion 7 Companion — V5.6

V5.4.5 temelinde **112 yeni batarya, şarj, planlama, BMS, termal, tüketim ve V2L/V2V/V2G getter adayı** eklendi. Önceki 34 CarSettings ham OEM okuyucusu korunur.

YENİ GETTER'LAR OTOMATİK SÜRÜŞ DÖNGÜSÜNDE ÇAĞRILMAZ. **Tanımlama → Verileri tara** manuel taramasında, OEM onayı ve ilgili Android izni varsa sıfır parametreli public getter denenir.

İlgili ekranlarda ham yanıt ve durumu görünür; canlı ölçüme veya arıza alarmına birim doğrulaması olmadan dönüştürülmez.

Teknik ayrıntılar için `docs/V5_6_DOGRULAMA_VE_SINIRLAR.md` dosyasına bakın.


## V5.7 Tanımlama OEM keşif
226 seçilmiş salt-okunur getter adayı, 6.683 isim tam referans kataloğu, manuel tarama, sayımlı durum filtreleri, otomatik Downloads/Sealion7 JSON raporu. Teknik notlar: docs/V5_7_TARAMA_RAPORU.md


## V5.8 — çift bölüm tarama ve otomatik rapor

Tanımlama > Okunanlar içindeki OEM keşif paneli iki bölüm içerir:
1. Firmware OEM: 226 seçilmiş salt-okunur parametresiz getter. İzin ve OEM onayı zorunlu.
2. Yüklü sistem: Android paket görünürlüğü, erişilebilir araç SDK sınıfları ve servis nesnelerinin keşfi. Bu bölüm sistemin özel verilerini okumaz; servis mevcut olması canlı araç telemetrisi demek değildir. Android 11+ paket görünürlüğü sonuçları sınırlar.

Hızlı: önceki taramada ham yanıt alınanlar; daha önce başarılı tarama yoksa ilk çalıştırmada tüm güvenli adaylar. Ayrıntılı: tüm seçilmiş adaylar. Ayrıntılı tarama, kullanıcı araç durumunu park veya şarj olarak işaretlemedikçe başlatılamaz. Kullanıcı seçimi araç ECU tarafından doğrulanmış park durumu değildir.

Her taramada sonuç kategorileri READ/PERMISSION/UNSUPPORTED/UNAVAILABLE/ERROR, gerçek getter çağrı sayısı, önceki taramaya göre yeni yanıt/kaybolan yanıt/izin değişimi gösterilir. JSON ve Excel uyumlu UTF-8 BOM CSV, MediaStore ile İndirilenler/Sealion7 altına kaydedilir. Yazma hatası kullanıcıya gösterilir.

Önemli: Yüklü sistem taraması kullanıcının arabasındaki tüm yüklü uygulamaları veya tüm araç verilerini listeleyemez; Android görünürlük ve OEM izin sınırları geçerlidir. Canlı tarama ve tam Android derlemesi araç/SDK ortamında ayrıca doğrulanmalıdır.
