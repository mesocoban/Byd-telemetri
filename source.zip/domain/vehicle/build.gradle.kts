plugins {
 id("com.android.library")  }
android { namespace = "com.sealion7.domain.vehicle"; compileSdk = 37
 defaultConfig { minSdk = 29 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }

}
dependencies { implementation(project(":core:model"))
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")  }
