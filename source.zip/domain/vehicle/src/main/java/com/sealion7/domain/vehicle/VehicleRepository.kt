package com.sealion7.domain.vehicle

import com.sealion7.core.model.*
import kotlinx.coroutines.flow.Flow

interface VehicleRepository {
 fun observeVehicleSnapshot(): Flow<VehicleSnapshot>
 fun observeMetric(key: MetricKey): Flow<MetricState<Double>>
 fun observeWarnings(): Flow<List<VehicleAlert>>
 suspend fun getCapabilities(): List<VehicleCapability>
 suspend fun refreshIfAuthorized(): VehicleConnectionState
 suspend fun scanReadOnlySources(): VehicleScanReport
 suspend fun sendAllowedCommand(commandName: String): CommandState
}

object VehicleSafetyPolicy {
 // A phone GPS reading must never be substituted for an OEM speed reading.
 fun canPresentAsVehicleSpeed(metric: VehicleMetric<*>): Boolean =
  metric.source != DataSource.PHONE_GPS && metric.quality == DataQuality.VALID &&
  metric.accessScope == AccessScope.OEM_READ

 // A positive, authenticated OEM acknowledgement and parked status are prerequisites.
 fun canEnableRemoteCommand(authorizedWriteApi: Boolean, parkedConfirmed: Boolean,
                           userConfirmed: Boolean): Boolean =
  authorizedWriteApi && parkedConfirmed && userConfirmed
}
