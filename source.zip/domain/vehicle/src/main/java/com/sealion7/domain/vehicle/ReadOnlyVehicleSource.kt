package com.sealion7.domain.vehicle

import com.sealion7.core.model.VehicleCapability
import com.sealion7.core.model.VehicleSnapshot

/** Read-only port. Every OEM adapter is independently gated and must fail closed. */
interface ReadOnlyVehicleSource {
 val id: String
 suspend fun readOnce(): VehicleSnapshot
 suspend fun capabilities(): List<VehicleCapability>
}
