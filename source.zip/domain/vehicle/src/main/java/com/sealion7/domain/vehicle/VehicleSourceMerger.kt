package com.sealion7.domain.vehicle

import com.sealion7.core.model.*

/** No mixed-value arithmetic; select one complete reading with explicit provenance. */
object VehicleSourceMerger {
 fun merge(snapshots: List<VehicleSnapshot>): VehicleSnapshot {
  val values: Map<MetricKey, MetricState<Double>> = MetricKey.entries.associateWith { key ->
   val states = snapshots.map { it.number(key) }
   // A phone-derived speed can never become a vehicle speed.
   val valid = states.filterIsInstance<MetricState.Live<Double>>().firstOrNull {
    it.metric.quality == DataQuality.VALID &&
     (key != MetricKey.VEHICLE_SPEED || it.metric.source != DataSource.PHONE_GPS)
   }
   valid ?: states.filterIsInstance<MetricState.Stale<Double>>().firstOrNull()
    ?: states.firstOrNull { it is MetricState.PermissionRequired }
    ?: states.firstOrNull { it is MetricState.Error }
    ?: states.firstOrNull { it is MetricState.Unavailable }
    ?: MetricState.Unavailable("İzinli kaynaklardan veri alınamıyor")
  }
  val live = values.values.any { it is MetricState.Live<*> }
  val locked = values.values.any { it is MetricState.PermissionRequired }
  // Keep only manufacturer lower limits whose source/provider matches the chosen wheel reading.
  // A cached threshold from a disconnected provider must never be applied to another source.
  val limits = TirePressureSafety.wheelKeys.mapNotNull { key ->
   val selected = values[key] as? MetricState.Live<Double> ?: return@mapNotNull null
   snapshots.firstNotNullOfOrNull { source -> source.tirePressureLimits[key]?.takeIf {
    it.wheel == key && it.source == selected.metric.source && it.providerId == selected.metric.providerId
   } }?.let { key to it }
  }.toMap()
  val upstream = snapshots.filter { it.connection == VehicleConnectionState.CONNECTED }.flatMap { it.alerts }
  val merged = VehicleSnapshot(values, gear = snapshots.firstNotNullOfOrNull { it.gear },
   driveMode = snapshots.firstNotNullOfOrNull { it.driveMode },
   alerts = upstream,
   tirePressureLimits = limits,
   oemRawObservations = snapshots.flatMap { it.oemRawObservations }.distinctBy { it.id },
   sourceDiagnostics = snapshots.flatMap { it.sourceDiagnostics.entries }.associate { it.key to it.value },
   connection = when {
    live -> VehicleConnectionState.CONNECTED
    locked -> VehicleConnectionState.REQUIRES_CONSENT
    snapshots.any { it.connection == VehicleConnectionState.CONNECTING } -> VehicleConnectionState.CONNECTING
    else -> VehicleConnectionState.DISCONNECTED
   })
  return merged.copy(alerts = (upstream + TirePressureSafety.alerts(merged)).distinctBy { it.code })
 }
}
