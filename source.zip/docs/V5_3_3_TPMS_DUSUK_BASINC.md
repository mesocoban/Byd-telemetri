# V5.3.3 — Lastik basıncı düşük uyarısı

## Kapsam

- Dört lastik ayrı değerlendirilir: TIRE_FL, TIRE_FR, TIRE_RL, TIRE_RR.
- Düşük basınç yalnız **AAOS `TIRE_PRESSURE` canlı kPa değeri** ile, aynı tekerleğe ait izinli `CarPropertyConfig.getMinValue(areaId)` **üretici alt sınırı** birlikte geldiğinde ve kaynak/provider/freshness eşleştiğinde üretilir.
- `VehicleSourceMerger` doğrulanmış koşullardan `VehicleAlert(code="TPMS_LOW_TIRE_...")` oluşturur, veri yanlış veya eskiyse aktif uyarıyı kaldırır. Sahte OEM uyarısı yapılmaz.
- **Panel** ve **Sürüş** `AlertBanner` ile; **Araç Durumu** hem banner hem kırmızı lastik kartı ile; **Tanımlama → Okunanlar** eşik, basınç, okuma kaynağı ve değerlendirme nedeni ile gösterir.
- Verideki eski/sorunlu ölçüm için “güncel değil / değerlendirilemiyor”; eşik yoksa “alt sınır bilinmiyor” gösterilir. Bu, lastiğin güvenli olduğu anlamına gelmez.
- Lastik sıcaklıkları hâlâ tekerlek başına ayrı boş ölçüm alanlarıdır; uydurma veri kullanılmaz.

## OEM TPMS doğrudan uyarı arayüzleri

Firmware `ts-framework.jar` metot indeksinde aşağıdaki tanımlar bulundu:

- `CarBodyManager.getTyrePressureWarnLeftFront(): int`
- `CarBodyManager.getTyrePressureWarnRightFront(): int`
- `CarBodyManager.getTyrePressureWarnLeftRear(): int`
- `CarBodyManager.getTyrePressureWarnRightRear(): int`
- `getTyrePressureWarnHint(): int` ve `getTyrePressureSysFailHint(): int`

**Bu sürümde etkin okuyucu değillerdir.** Uyarı enum kodları, çağrılacak servis, yetki ve Sealion 7 eşleşmesi doğrulanmamıştır; yalnız metot varlığı bir alarm anlamına gelmez.

## AAOS yetki / sınır

`TIRE_PRESSURE` için tekerlek kimliği ve `CAR_TIRES_3P` izni gerekir. Android Automotive (AAOS) özelliğinin araçta bulunacağı garanti değildir. Android telefon API 37 olması bu hizmete erişim vermez.

`CRITICALLY_LOW_TIRE_PRESSURE` ayrı AAOS özelliğidir; üretici eşiklerine ilişkin salt-okunur meta veridir. Güncel belgelerde bu özelliğe erişim ayrı sistem/ayrıcalıklı izinle kısıtlıdır. Sürüm 5.3.3 bu özelliği **erişmeye çalışmaz ve OEM'in asıl TPMS ikaz bayrağı olduğunu iddia etmez**.

Referanslar:
- https://developer.android.com/reference/android/car/VehiclePropertyIds#TIRE_PRESSURE
- https://developer.android.com/reference/android/car/hardware/CarPropertyConfig#getMinValue(int)

## Test

- `validation/TirePressureChecks.kt`: Kotlin/JVM bağımsız kontroller
- `app-mobile/src/test/.../TirePressureSafetyTest.kt`: JUnit kaynak testleri
- **Gerçek araç / tam Android Gradle derlemesi bu ortamda doğrulanmadı.**

**Güvenlik:** Bu uygulama fabrika TPMS ikaz sisteminin yerine geçmez. Lastik etiketindeki önerilen basınç ve üreticinin fiziksel uyarılarını esas alın.
