# V5.3.6 — Kotlin sürüş derlemesi

## Kullanıcının gönderdiği hata

`:feature:driving:compileDebugKotlin` görevi başarısız. Paylaşılan günlük yalnız genel Gradle stack trace içeriyor, `e: file:///...:line:col` gibi Kotlin hata satırları bulunmuyor.

## Kodda tespit edilen somut hata

`feature/driving/src/main/java/com/sealion7/feature/driving/DrivingDashboard.kt` dosyasındaki telefon GPS mini çizgisel grafiği `Offset(...)` oluşturuyor. Bu dosyada `Offset` sınıfının importu eksik. Eklendi:

```kotlin
import androidx.compose.ui.geometry.Offset
```

* APK'nin derlendiği iddia edilmez; Android SDK ve Gradle bağımlılıkları bu ortamda mevcut değil.
* 7 ana grup, TPMS, yön/saat, üçlü güç ve enerji tüketim hesapları aynen korundu.
* V5.3.6 sürüm numarası 0.5.3.6, versionCode 13.

## Windows'ta doğrulama

ZIP içindeki `Sealion7Companion_Android17_V5_3_6_KotlinBuildFix` proje klasörünü Android Studio ile açın.
Terminal (PowerShell):

```powershell
.\gradlew.bat :feature:driving:compileDebugKotlin --console=plain --rerun-tasks 2>&1 | Tee-Object driving_compile.log
.\gradlew.bat :app-mobile:assembleDebug --console=plain 2>&1 | Tee-Object full_build.log
```

Hata sürerse `driving_compile.log` içinde özellikle `e: file:///...`, `Unresolved reference`, `Type mismatch`, `Compilation error` satırlarını gönderin. Genel `* Exception is:` altındaki uzun stack trace gerçek Kotlin hatasının yerini tutmaz.

## Var olan projeyi ZIP çıkarmadan düzeltme

```powershell
python patches\fix_v535_driving_import.py "C:\BYD S7 izleyici\Sealion7Companion_Android17_V5_3_5_Enerji_Tuketim"
```

(Betiğin bulunduğu klasöre göre dosya yolunu güncelleyin. Betik orijinal dosyayı `.kt.bak` olarak yedekler.)
