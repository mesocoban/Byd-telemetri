# V5.6 Batarya ve Şarj — teknik sınırlar

V5.4.5 kaynakları korunarak 112 benzersiz yeni getter **adayı** eklendi; önceki 34 CarSettings metoduna ilavedir.

- Envanter metot adı bazındadır, üretici servisindeki destek ve erişim kanıtı değildir.
- Yeni adaylar yalnız **manuel tarama** sırasında denenir; 1,5 saniyelik normal polling döngüsünde onlarca getter çağrılmaz.
- Sadece `BYDAUTO_*_GET` izni ve uygulama OEM onayı varsa BYDAuto servisinin public sıfır parametreli getter'ları çağrılabilir.
- Sınıf/sahiplik eşlemeleri eldeki isim envanterine göre **tahminidir**. TS `CarVendorChargingManager` metotları aynı BYDAuto sınıfına ait olmayabilir; bu durumda ilgili alan açıkça `METHOD_NOT_VERIFIED` olur.
- Ham dönüşler birim doğrulanmadan kW, kWh, SOH, °C veya arıza olarak sunulmaz.
- Hiçbir kontrol komutu (`set*`) çağrılmaz, OEM izinleri aşılmaz.
- V2G özellik adlarının bulunması araçtaki donanımın V2G desteklediğini kanıtlamaz.
- Tam Android derlemesi ve gerçek araç okuması bu ortamda doğrulanmadı.
