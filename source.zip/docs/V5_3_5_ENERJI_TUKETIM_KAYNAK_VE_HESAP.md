# V5.3.5 — Enerji Tüketimi, Kaynaklar ve Güvenilirlik

## Kaynak ve doğrulama

- **Batarya tüketim gücü (kW):** Var olan V5.3.4 `BATTERY_CONSUMPTION_POWER` alanı. AAOS `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` negatif mW → deşarj kW; yalnız destekli Android Automotive, verilmiş izin ve geçerli ölçüm varsa.
- **Araç hızı (km/sa):** Doğrulanmış `VEHICLE_SPEED`. Telefon GPS hızı hiçbir şekilde OEM araç hızının yerine kullanılmaz.
- **Anlık tüketim (kWh/100 km):** `100 × batarya tüketim gücü (kW) / araç hızı (km/sa)`. Her iki ölçüm de güncel, aynı zaman aralığında (3 sn) ve birimleri doğru olmalıdır. Hız 10 km/sa altındayken oran yayımlanmaz.
- **İzlenen tüketilen enerji (kWh):** Ardışık güncel batarya deşarj gücü değerleri trapez yöntemle zamana göre entegre edilir. Ölçüm aralığı 10 sn üzerindeyse o aralık atlanır; bağlantı yokken aradaki enerji uydurulmaz. Hızın da aynı aralıkta geçerli olması istenir.
- **İzlenen ortalama (kWh/100 km):** `100 × izlenen enerji kWh / hızın zaman integralinden izlenen mesafe km`; en az 50 metre gerekir. Araç sayacındaki bütün yolculuğun ortalaması **değildir**.
- **Trip A/B izlenen bölüm ortalamaları:** Ancak Trip sayaçlarının kM cinsinden doğrulanmış canlı değerleri sağlanırsa ve eşzamanlı batarya deşarj örnekleri varsa hesaplanır. Sayaç sıfırlanırsa ilgili izleme penceresi sıfırlanır. Katalogda alanlar vardır; mevcut TS kaynaklarında `getMileageUnit()` eşlemesi doğrulanmadığından Trip A/B metrikleri bilinçli olarak canlı yayımlanmıyor.
- **Trip A/B izlenen tüketilen enerji:** Yukarıdaki Trip süre aralığında entegre edilen batarya deşarjı kWh'dir; tam Trip geçmişi değildir.
- **Son tamamlanan yolculuğun ortalama tüketimi:** `getTripEnergyConAvg()` TS `CarBodyManager` firmware imzası var, ancak araç sürümüne özgü anlamı ve birimi doğrulanmadı. Canlı sayı üretilmez.
- **Geri kazanılan enerji (kWh):** Yalnız gerçek ölçülen `REGEN_POWER` (kW) gelirse entegre edilir. Rejenerasyon ayar kademesi veya pozitif batarya şarjı **asla** doğrudan frenleme enerjisi sayılmaz.

## Ekran yerleşimi

| Alanlar | Panel | Sürüş | Pil ve Şarj | Tanımlama |
|---|:---:|:---:|:---:|:---:|
| Anlık tüketim, izlenen dönem ortalaması | ✓ | ✓ | ✓ | ✓ |
| İzlenen tüketilen enerji, geri kazanılan enerji | ✓ | ✓ | ✓ | ✓ |
| Trip A/B izlenen bölüm ortalamaları ve enerji | — | ✓ | ✓ | ✓ |
| Son tamamlanan yolculuk ortalaması (kaynak bekliyor) | — | ✓ | ✓ | ✓ |

Tüm gösterge alanları tek `VehicleSnapshot` içinden okunur; her sayfa OEM servisini tekrar çağırmaz.

## Sınırlar

- Android araçta gerçek veri denemesi **yapılmadı**.
- Bu ortamda Gradle Wrapper dağıtımı internet erişimi nedeniyle indirilemedi; APK **derlenmedi**.
- Kotlin-only tüketim hesaplaması kontrolleri `validation/EnergyConsumptionChecks.kt` dosyasındadır.
- Otomatik tüketim entegrasyonu uygulama açıkken veri akışının devam ettiği dönemi kapsar; uygulama kapanınca ve yeniden açılınca yeni bir izleme dönemi başlar. Geçmiş konum kaydı tutulmaz.
- Bağlı ve destekli BYD/AAOS telemetrisi olmadan göstergeler bilinmiyor durumundadır; sahte ölçüm gösterilmez.
- Tüketim hesapları batarya DC çekişini yansıtır; motorun mekanik çıkışı veya fabrika yol bilgisayarının resmî tüketimi değildir.
