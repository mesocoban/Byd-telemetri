# V5.3.4 — Çekiş, Batarya Tüketimi ve Rejenerasyon Gücü

## Amaç ve kesin ayrımlar

1. **TRACTION_POWER (Çekiş gücü, kW)** = motor/aktarma sisteminin doğrulanmış mekanik çıkış gücü. Batarya net gücünden, şarj gücünden, tork/devir *ham* metot adlarından hesaplanmaz.
2. **BATTERY_CONSUMPTION_POWER (Batarya tüketim gücü, kW)** = batarya DC deşarj gücü. Motor + yardımcı elektrik tüketimini içerebilir. `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` (AAOS, mW) negatifse `-değer/1_000_000` ile üretilir. Pozitif değer bataryanın şarjda olduğunu gösterir, deşarj gücü olarak yayımlanmaz.
3. **REGEN_POWER (Rejenerasyon gücü, kW)** = rejeneratif frenleme nedeniyle geri kazanılan **ölçülmüş** güç. AAOS'un `EV_BRAKE_REGENERATION_LEVEL` özelliği sadece **ayar kademesi** verir; AAOS pozitif net batarya şarjı, AC/DC şarj veya başka kaynaklardan gelebileceği için rejenerasyon gücüne otomatik çevrilmez.

## Durum

| Alan | Kaynak yöntemi | Kod durumu | Canlı araç doğrulaması |
|---|---|---|---|
| `BATTERY_CONSUMPTION_POWER` | AAOS izinli `CarPropertyManager` / `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` | Ölçüm ve normalize etme kodu var; yalnız negatif mW (deşarj) | Yapılmadı; BYD DiLink'in AAOS desteği doğrulanmadı |
| `TRACTION_POWER` | BYD TS `CarCloudAdapterManager.getDriverMotorTorque`, `getDriverMotorSpeed`; MCU voltaj/akım adayları | OEM izni varsa salt-okunur getter kullanılabilirliği yoklanır; birim/ölçek doğrulanmadığı için kW **üretilmez** | Yapılmadı |
| `REGEN_POWER` | BYD TS `DriveModeAdapterManager.getDriveBrakingRecovery`, `CarBodyManager.getEnergyFeedback` | Ham getter cevapları yalnız durum/ayar adayı; kW **üretilmez** | Yapılmadı |

**Gizli API, OEM izni atlama, doğrudan CAN/OBD komutları veya yazma işlemleri yok.** `OEM_READ_APPROVED=false` ve Android OEM `CAR_VENDOR_EXTENSION` kontrolü önceki sürümde olduğu gibi korunur. Motor/enerji için isim benzerliği fiziksel eşdeğerlik sayılmaz.

## Görüntüleme

- **Panel:** Üç farklı kW alanı, renkli animasyonlu ayrı barlar.
- **Sürüş:** Çekiş gücü, batarya tüketim gücü ve rejenerasyon gücü ayrı kartlar; net batarya gücü ve rejenerasyon ayar kademesi de ayrı korunur.
- **Pil ve Şarj:** Üçlü güç akışı, ayrıca net batarya ve şarj gücü.
- **Tanımlama > Okunanlar:** Ölçüm alındığında kaynak, zaman ve yöntem kanıtı; alınmazsa bu sekmede canlı görünmez.
- **Tanımlama > Belirlenenler:** Üç alanın okunabilirlik/izin/eşleme durumu ayrı.
- **Yatay hızlı bakış:** Üç kW alanı ayrı gösterilir.

## Birim ve kaynak kanıtı

- Android Automotive [VehiclePropertyIds](https://developer.android.com/reference/android/car/VehiclePropertyIds): `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` mW, pozitif şarj, negatif deşarj. `EV_BRAKE_REGENERATION_LEVEL` bir ayar seviyesidir, kW değildir.
- Kullanıcının `ts-framework.jar` firmware metot indeksi (`docs/firmware_okuma_metot_indeksi.csv`): belirtilen BYD getter imzaları. İmza varlığı metot sonucunun ünitesini veya araç uyumluluğunu kanıtlamaz.

## Sonraki araç doğrulaması için gerekenler

OEM imzasına sahip izinli cihazda *salt-okunur* yerinde ölçüm: motor torku/deviri birimleri, tek/çift tahrik motoru ayrımı, ham getter'ın sinyal kalitesi, deşarj ve rejenerasyon olaylarında örnekler, CAN/servis loglarıyla uyum karşılaştırması, örnek zaman damgası ve hata kodları. Bunlar doğrulanmadan `TRACTION_POWER` veya `REGEN_POWER` canlı karta bağlanmayacak.
