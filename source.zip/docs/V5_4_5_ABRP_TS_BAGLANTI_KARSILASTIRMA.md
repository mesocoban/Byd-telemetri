# V5.4.5 — ABRP SL7 ile TS CarAdapter karşılaştırması

Referans ZIP: `abrp-telemetry-sl7-main(1).zip`, özellikle `VehicleDataManager.kt` ve `TelemetryService.kt`.
Hedef: V5.4.4 Companion'ın izinli salt-okunur TS adaptörü. Bu uygulama ABRP istemcisi değildir ve veri göndermez.

## Doğrudan veri karşılaştırması

| Kaynak veri | ABRP yaklaşımı | V5.4.4 | V5.4.5 ve sınırları |
|---|---|---|---|
| SOC | `general.getElecPercentageValue` | TS okuma var | Korundu, 0 geçerli, % birim korumalı |
| Hız | `sensor.getCurrentSpeed` | TS okuma var | Korundu; telefon GPS hızı ayrı |
| Menzil | `general.getElecDrivingRangeValue` | TS okuma var | Korundu |
| Dış sıcaklık | `hvac.getTempratureOut` | TS okuma var | Korundu; sıfır/sınır dışı reddedilir |
| Odometer | `general.getTotalMileageValue` | Getter deneniyor, birimi şüpheli | Ham cevap var; km birimi doğrulanmadan canlı sayılmaz |
| Şarj gücü | `charging.getChargingPower` | Ham okunuyor, durum birimi şüpheli | Durum doğrulanmadan kW kabul edilmez |
| Vites | `body.getShiftMode` | TS okuyucu bağlı değildi | Gerçek getter sorgusu eklendi; ham kod ayrı. ABRP'de gözlenen P=1/N=3/D=4, R=2 gözlenmedi |
| Şarj durum kodu | `charging.getChargerState` | Oku ama görünür değil | Ham kod canlı okuma alanı olarak eklendi; 1=AC/2=DC kabul EDİLMEDİ |
| Park durumu | ABRP vites/hız/şarj ile hesaplıyor | Ayrı doğrulanmış park alanı yok | Yalnız P vites seçimi yorumlanabilir; hız<2 park demek değildir; otomatik park bayrağı üretilmez |
| DCFC | ABRP chargerState==2 tahmini | Doğrulanmış bayrak yok | Hâlâ doğrulanmamış; yalnız ham kod gösterilir |
| Enlem-boylam, rakım | Android GPS | Sadece GPS hızı / hareket yönü | İzinli telefon GPS koordinatı, geçerli rakım, doğruluk ve zaman Tanımlama ekranında |
| SOH | ABRP veri alanı tanımlı, değeri yok | Yok | Uydurulmadı |

## Bağlantı yaşam döngüsü

| Konu | ABRP referans kodu | Eski Companion | V5.4.5 |
|---|---|---|---|
| SDK nesnesi | `CarAdapterManager.getInstance(applicationContext)` | OEM onayı ardından `sdkObject` | Korundu |
| İlk bağlanma | `connect()` | Binder bağlı değilken her 1,5 sn connect | İlk bağlantı hemen; sonra 3, 6, 12, 30 sn (üst sınır) aralık |
| Durum kontrolü | `isCarServiceBound()` | Her okuma | Korundu |
| Binder bildirimi | `setOnManagerConnChangedListener` | Yok | Genel/public dinleyici; kopma işaretlenir |
| Alt yöneticiler | `sensor/general/charging/hvac/body` | Her başarılı okumada yeniden çözülür | Korundu; bağlantısızken getter kullanılmaz |
| Zorla yeniden başlatma | ABRP özel statik singleton alanını reflection ile sıfırlar | Yok | **KOPYALANMADI**; yalnız genel `disconnect/connect` metotları kullanılabilir |
| Kopuk veri | ABRP eski cache'i tutar, `connected=false` yapar | Geçerli TS yoksa boş snapshot | Kopukken **hiçbir TS değerine Live verilmez**, durum ayrı kartta |
| Arka plan servisi | ABRP foreground service; 2s ölçüm; 10/30/60s sunucu aktarımı | UI toplarken 1,5s okuma | Korundu; arka planda kalıcı daemon veya upload EKLENMEDİ |
| Gerçek çağrı sayımı | Log bazlı | Manuel denetimde mevcut | Getter denemeleri gerçek sayaca girer; bağlantı/SDK metotları getter sayılmaz |

## Güvenlik ve doğrulama

- `CarAdapterManager` sınıfının varlığı tek başına izin sağlamaz. OEM onay bayrağı ve Android `CAR_VENDOR_EXTENSION` erişimi hâlâ gereklidir; kullanıcının bu izni gerçekten almış olması garanti değildir.
- Ref. proje `R=2` kodunu *tahmin* olarak işaretliyor. Companion bu değeri doğrulanmış geri vites olarak sunmaz.
- Ref. projede `chargerState>0` şarj kabul edilir ve `==2` DCFC olarak yorumlanır. Bu eşlemelerin gerçek Sealion 7 üzerindeki anlamı kanıtlanmadığından Companion şarj türü veya kW üretmez.
- GPS yalnız kullanıcı ayarlardan açmışsa ve Android konum izni verilmişse çalışır. Koordinat ve rakım yalnız telefon verisidir, kayıt veya uzak sunucu gönderimi yoktur.
- Bağlı olmak, belirli bir sensörü başarıyla okumak anlamına gelmez. "Tanımlama → Okunanlar" hem bağlantı denemelerini hem gerçek okuma çağrılarını ayrı gösterir.
- Araç üzerinde OEM servis ve izin testi, R/şarj kodu gözlemi ve tam Android APK derlemesi bu ortamda yapılmadı.

## Testler

`validation/AbrpReconnectChecks.kt` — 34 kural (yeniden bağlanma/backoff, vites gözlemi, ham kod güvenliği, GPS geçerliği).
Ayrıca V5.4.4 model, enerji, TPMS, kaynak birleştirme ve okuma sayacı kontrolleri yeniden çalıştırıldı.

> **Sürüş güvenliği**: Bu uygulama gösterge panelinin veya üretici arıza bildirimlerinin yerini almaz.
