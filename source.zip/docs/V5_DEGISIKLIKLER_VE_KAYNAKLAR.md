# V5 — Ölçüm katmanları, düzeltme ve doğrulama

## Düzeltmeler
- V4 üzerine **AAOS salt-okunur** `TIRE_PRESSURE` (dört ayrı wheel areaId), `EV_BATTERY_AVERAGE_TEMPERATURE`, `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` ve `EV_BRAKE_REGENERATION_LEVEL` eklendi.
- Basınç `kPa`; net batarya akışı `mW / 1_000_000 -> kW` ve işaretli (pozitif şarj, negatif deşarj); batarya sıcaklığı `°C`; rejenerasyon ayarı **kademe**, ölçülen geri kazanım gücü değildir.
- Sayı boş, yetki eksik veya güncel değilse telemetri uydurulmaz. Lastik sensörü her bir teker `areaId` ile okunur.
- Üretici TS, BYDAuto, DiLink 5 adaptörleri bağımsız kalır, OEM yetkisi **varsayılan olarak yoktur**.
- Android manifesti `CAR_TIRES_3P` isteğini ekler; üretici ve Android platformu bunu vermeyebilir.
- Enerji ekranına batarya net akışı, sıcaklığı, dört lastik, regen ayar kartları eklendi.
- JVM testleri yeni birimler için eklendi.

## Yanlış eşitlemelerden kaçınma
- `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE` **motor/çekiş gücü değildir**.
- `EV_BRAKE_REGENERATION_LEVEL` **geri kazanılan kW değil araçtaki ayar kademesidir**.
- `TIRE_PRESSURE` **kPa**, aracın kılavuzdaki referans basıncı değildir.
- `EV_BATTERY_AVERAGE_TEMPERATURE` batarya hücrelerinin ayrı ayrı sıcaklıkları değildir.
- `CAR_TIRES_3P` izni istenebilir ama servis sağlamıyorsa canlı değer dönmez.
- 12 V voltajı, özel BMS akımı/gerilimi, güvenlik-kritik ADAS uyarıları ve klima durumu hâlâ doğrulanmış API ile bağlı değildir.

## Paylaşılan ayrı projenin compileDebugKotlin hatası
`Yapıştırılan metin.txt` derleme günlüğü V4'ten **farklı** `SealionTelemetry_Android17_v0.3.0_ExpressiveLight` projesine aittir. Bu projenin `MainActivity.kt` kaynak dosyası yüklenmediği için doğrudan dosyada değişiklik yapılamadı.

- `import androidx.compose.animation.core.animateColorAsState` yerine `import androidx.compose.animation.animateColorAsState`
- `app/build.gradle.kts` modülünde, Compose BOM altında `implementation("androidx.compose.animation:animation")`
- Gerekirse 249 ve 254. satırdaki renk hedefi açıkça `Color` ile tiplenmeli; fonksiyon çözüldüğünde 251 ve 256 tür çıkarımı hatalarının da düzelmesi beklenir.
- Ayrı kaynak kodunu test ederek doğrulamak **mümkün olmadı**.

## Kaynaklar (2026-10-24 kontrol)
- https://developer.android.com/reference/android/car/VehiclePropertyIds : PropertyIds, birimler, erişim türleri ve izinler.
- https://developer.android.com/reference/kotlin/androidx/compose/animation/animateColorAsState.composable : gerçek `animateColorAsState` paketi ve gerekli artifact.
- Kullanıcı firmware analiz paketleri: `firmware-evidence/`.

## Doğrulama sınırları
- Lokal Android SDK/Gradle indirimi yoksa APK veya UI instrumentasyon testi **başarılı deneme olarak raporlanmaz**.
- Yalnız saf Kotlin model/testleri komut satırında derlenerek sınanabilir.
- OEM SDK izin ve araç bazlı ölçümler Sealion 7 üzerinde henüz doğrulanmadı.
