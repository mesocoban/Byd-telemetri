# V4 — Ayrık BYD telemetri kaynakları

```
:app-mobile :feature:driving :feature:diagnostics
       |              |            |
       +---------- :domain:vehicle (ReadOnlyVehicleSource + VehicleSourceMerger)
                            ^
       :data:vehicle (Hilt repository, kaynak bazlı sorgu)
             |-> AaosReadOnlyTelemetry (public Android Automotive)
             |-> :data:ts-sdk (CarAdapterManager, OEM gated)
             |-> :data:bydauto-sdk (BYDAutoDevice, OEM gated)
             |-> :data:dilink5-sdk (DiLink 5 getter, OEM gated)
       |-> :data:binder-reference (BYDMate veri yolu, kanıt-only)
                          \-> :data:oem-common (izin kapısı, reflection, veri metadata)
```

## Kaynaklar / varsayılan erişim

- **AAOS**: Var olan belgelenmiş kamusal özellik/izin koşulları altında etkin. Normal Android telefonunda erişim yok.
- **TS CarAdapter**: Kullanıcının `ts-framework.jar`/`CarAdapterService.apk` imzaları ve ABRP projesiyle eşleşiyor; TS izin JSON'u mevcut `com.sealion7.companion` paketini kapsamadığı için varsayılan kapalı.
- **BYDAuto**: `BydAutoService.apk` ve Electro/Trip Stats API izleri; OEM izinleri yokken varsayılan kapalı.
- **DiLink 5**: BYD Trip Stats / Yoldaş APK'sı veri mimarisinden yalnız güvenle tanımlanabilen getter'lar özgün uygulanır. Özellikle `getSpeedValue()` **zemin hızı** diye ayrı `GROUND_SPEED` alanında saklanır, ana `VEHICLE_SPEED` yerine geçirilmez. Typed listener sınıfları OEM SDK/JAR onayı olmadan bir arayüzmüş gibi yapılmaz.
- **BYDMate Binder/FID**, **Yoldaş native hook**: kaynak analizine alındı ancak güvenli/izinli veri anlamı ve yetkileri kanıtlanmadığı için uygulamada çağrı yok.
- **Telefon GPS**: Ayrı Android `LocationManager` kaynağı, araç hızına asla karıştırılmaz.

## Güvenlik ve yetkilendirme

`AndroidManifest.xml` içinde `com.sealion7.companion.OEM_READ_APPROVED=false` bulunur. Tasarlanan OEM adaptörleri, bu bayrak açık **ve** ilgili `android.car.permission.CAR_VENDOR_EXTENSION` gerçekten verilmiş **ve** OEM sınıfı görünürse ancak o zaman sınıfı yükleyip read-only getter çalıştırır. Sadece bayrağı değiştirmek bir OEM onayı veya servis izni vermez; gerçek üretici yetkisi şarttır. Üçüncü taraf uygulamayı firmware allowlist'ine ekleme/bypass önerilmez. Android hidden API exemption, shell/root, FID tahmini, SET komutu, yazma yok.

## Ölçüm/doğruluk

Her getter dönüşü aralık/finite sınamasından geçirilir. Her ölçüm `source`, `providerId`, `methodEvidence`, `receivedAt` bilgisini taşır. OEM getter'ların **fiziksel örnek zaman damgası** bilinmediğinden `deviceTimestampVerified=false`: zaman olarak okumanın alındığı an tutulur; bu, sensörde o anda ölçüm yapıldığına kanıt değildir. Resmî AAOS `CarPropertyValue.timestamp` gerçek örnek yaşına dayanır.

`CHARGE_POWER` çekiş motorunun anlık gücü değildir; yalnız şarj durumu doğrulanırsa potansiyel veri olarak saklanır. Lastik basıncı, şarj tabancası bitleri, sürüş modu enumları, geri vites olayları ve D5 callback'leri model/firmware sahada teyit edilmeden aktif telemetriye dönüştürülmez.

## Tamamlanamayan canlı doğrulamalar

Baş üniteden `PackageManager` izin verisi, OEM SDK görünürlüğü, CarService bağlantısı, gerçek Getter sonuçları ve araç gösterge paneliyle karşılaştırma bulunmuyor. Bu nedenle TS/BYDAuto/D5 için canlı veri desteği iddia edilmez. Gradle/SDK derlemesi ayrıca raporlanacaktır.
