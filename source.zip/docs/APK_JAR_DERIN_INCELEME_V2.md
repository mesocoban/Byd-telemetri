# BYD Sealion 7 — APK / JAR Derin İnceleme ve Android 17 Entegrasyonu (v2)

**Tarih:** 24.10.2026 | **Kaynak:** Kullanıcının sağladığı orijinal firmware olarak tanımlanan iki ZIP dosyası, 305 girdilik katalog, önceki Android Studio projesi.

## Soru: Veriler gerçekten nereden okunuyor?

**Firmware içinden kanıt:** `ts-framework.jar` içinde `CarAdapterManager`, `CarSensorAdapterManager`, `CarGeneralAdapterManager`, `ChargingAdapterManager`, `ICarSensorService` ve `ICarGeneralService` tanımlı. `CarAdapterService.apk` uygulaması veri sağlayıcı yöntem gövdelerini içeriyor. `BydMyCar.apk` ve `BydMyCarTs.apk` içinde aynı TS fonksiyonlarına DEX çağrı başvuruları bulunuyor. 

**Yöntem gövdesi ile metot referansı farklı:** Önceki raporda çıkarılan DEX `method_id` kayıtları her zaman uygulamanın metodu implemente ettiğini kanıtlamaz. Bu defa `class_defs` ve `class_data` içindeki `code_off` alanları ayrıştırılarak aşağıdaki kanıt seviyesi belirlenmiştir.

| Dosya | DEX inceleme sonucu |
|---|---|
| `ts-framework.jar` | `getCurrentSpeed`, `getElecPercentageValue`, `getElecDrivingRangeValue`, `getTotalMileageValue`, `getChargingPower`: **tanımlı sınıf + kod gövdesi var** |
| `CarAdapterService.apk` | Belirtilen getter'lar obfuske `.../c/j`, `.../c/i`, `.../c/g` sınıflarında **kod gövdesiyle var** |
| `BydAutoService.apk` | TS sınıfları/metotları için **haricî başvuru**; kendisinde aynı TS kod gövdesi yok |
| `BydMyCar.apk` | TS yöntemleri için **haricî başvuru**; kendisinde aynı TS kod gövdesi yok |
| `BydMyCarTs.apk` | Aynı şekilde TS API'sine **haricî başvuru** |
| `android.car.jar` | AAOS `CarPropertyManager.getPropertyList` platform yöntemi tanımlı |

Bu, kodun araçta gerçekten belirli bir sinyali okuduğunu veya üçüncü taraf çağrılarına izin verildiğini **kanıtlamaz**; yöntem bytecode'u baştan sona tüm akışlarıyla emüle edilmedi.

## APK manifestleri ve uygulama paketleri

Manifestler Android binary XML'den ayrıştırıldı; tam `uses-permission`, `service`, `provider` ve `activity` listesi `apk_manifest_bilesen_izinleri.csv` dosyasında.

| APK | Paket | Manifest gözlemi |
|---|---|---|
| `CarAdapterService.apk` | `com.ts.appservice.caradapter` | `CarAdapterService` dışa açık (`exported=true`); TS paylaşımlı kütüphaneye referans; çok sayıda privileged CAR izni istiyor |
| `BydAutoService.apk` | `com.byd.autoservice` | `CoreService`; TS platform servisi |
| `BydMyCar.apk` | `com.byd.mycar` | `PersistentService`, MyCar provider; BYDAUTO `GET`/`SET` izin talepleri |
| `BydMyCarTs.apk` | `com.byd.mycar.ts` | Aynı tür servis/provider adları fakat ayrı paket ve farklı DEX |
| `CarService.apk` | `com.android.car` | AAOS CarService ve OEM privileged izinleri |

**Önemli:** Manifestte exported=true olması bile OEM erişiminin açık olduğunu garanti etmez. Runtime servis/Binder güvenlik kontrolleri ve SELinux/izin politikası geçerlidir.

## Standart Android Automotive salt-okunur bağlantı

Bu turda `data/vehicle/AaosReadOnlyTelemetry.kt` eklendi, `VehicleRepository` polling akışına ve büyük hız göstergeli Compose ekranına bağlandı. **Yalnızca belgelenmiş kamusal `android.car.Car`, `CarPropertyManager.getPropertyList`, `getProperty` çağrıları kullanılır.** Runtime'da `FEATURE_AUTOMOTIVE`, izinler ve erişilebilir property listesi denetlenir. İzinli servis yoksa hız, menzil, SOC vs. gerçek değer gösterilmez.

| Veri | Kamusal AAOS kaynak | Dönüşüm | İzin |
|---|---|---|---|
| Araç hızı | `PERF_VEHICLE_SPEED_DISPLAY` (alternatif `PERF_VEHICLE_SPEED`) | m/s × 3.6; geri viteste mutlak hız | `CAR_SPEED` |
| Kalan menzil | `RANGE_REMAINING` | metre / 1000 | `CAR_ENERGY` |
| SOC | `EV_BATTERY_LEVEL`, `EV_CURRENT_BATTERY_CAPACITY` | Wh oranı × 100 | `CAR_ENERGY` |
| Toplam kilometre | `PERF_ODOMETER` | km | `CAR_MILEAGE_3P` |
| Dış sıcaklık | `ENV_OUTSIDE_TEMPERATURE` | °C | `CAR_EXTERIOR_ENVIRONMENT` |
| Vites | `GEAR_SELECTION` | belgeli `VehicleGear` enum değerleri | `CAR_POWERTRAIN` |

Anlık çekiş gücü, regen, sürüş modu, ADAS uyarıları, lastik basınçları ve uzaktan kontrol fonksiyonları **bağlanmadı**: kaynak/izin/ölçüm anlamı doğrulanmıyor. Özellikle AAOS `EV_BATTERY_INSTANTANEOUS_CHARGE_RATE`, çekiş motorunun `POWER` göstergesi olarak yanlış sunulmadı.

Not: Android 17 telefonda `FEATURE_AUTOMOTIVE` bulunmadığından bu sağlayıcı, normal şartlarda veri üretmez. BYD baş ünitesinin android.car kütüphanesini taşıması bile uygulamanın kurulabildiğini, izin alacağını veya standart VHAL property yayınladığını ispatlamaz.

## Test ve çalıştırılabilirlik ayrımı

- İki arşivin mevcut APK/JAR içeriği ayrıştırıldı. 9 APK binary manifesti okundu; 11 APK/JAR için hedef DEX sınıf tanımları ve kod-gövdesi durumları ayrıştırıldı.
- `AutomotiveMetricNormalizer.kt` için 10 JVM davranış kontrolü başarılı. AAOS adaptörünün Kotlin sözdizimi, Android/coroutine API yer tutucu **yalnız derleme stublarıyla** kontrol edildi; bu gerçek Android derlemesi değildir.
- `./gradlew --offline :app-mobile:assembleDebug` denendi; **Gradle 9.6.0 indirmesi için DNS/ağ erişimi yok (`UnknownHostException: services.gradle.org`)**. Bu ortamda Android SDK/platform-37 olmadığı için APK üretilemedi.
- Araç cihazı, çalışır CarService, kullanıcı izin durumu, OEM onayı ve araç logları sağlanmadı; **canlı telemetri bağlantısı doğrulanmadı**.

## Araç üzerinde güvenli ve izinli doğrulama

1. Aracın park halinde olduğu güvenli koşullarda, araç üreticisinin üçüncü taraf uygulama kurulumuna izin verdiğini doğrulayın.
2. `adb shell pm list features` çıktısında `android.hardware.type.automotive` ve `adb shell getprop ro.build.version.sdk` ile sistem sürümünü gözleyin (yalnız onaylı geliştirici erişiminde).
3. Proje Android Studio'da ağ bağlantısı olan JDK 17 / Android SDK 37 ile `./gradlew :app-mobile:assembleDebug` kullanılarak derlenmeli; gerçekte derlendiği doğrulanmadan APK sunulamaz.
4. Uygulamada **Ayarlar > Araç okuma izinlerini iste** seçeneği yalnız AAOS host üzerinde belirir. İzin reddedilirse veya özellik servis tarafından listelenmezse değer `—` kalır.
5. Tanılama ekranında hangi property'sinin gerçekten okunabildiğini kontrol edin; araç göstergesi ile farkların kaynağı/ölçüm birimi onaylanmadan kalite iddiasında bulunmayın.
6. Root, SELinux politikası değiştirme, ADB ile imtiyaz yükseltme, OEM APK/JAR kopyalama, Binder transact/FID veya araç ECU yazması **yapılmıyor**.

**Resmî belgeler:**
- https://developer.android.com/reference/android/car/Car
- https://developer.android.com/reference/android/car/hardware/property/CarPropertyManager
- https://developer.android.com/reference/android/car/VehiclePropertyIds
- https://developer.android.com/reference/android/car/VehicleGear

**Ek dosyalar:** `apk_jar_dex_tanim_kanitlari.csv`, `apk_jar_dex_ozet.csv`, `apk_manifest_bilesen_izinleri.csv`, `AAOS_SALT_OKUNUR_API_MATRISI.csv`, `OEM_IZIN_DENETIMI.md`.
