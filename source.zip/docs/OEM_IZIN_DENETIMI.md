# Firmware TS izin politikası: salt-okunur inceleme

**Kaynak:** `BYD_Telemetri_Ortak.zip` > `2_2_la_vendor_a/etc/data/ts_permission_config.json` ve ilgili APK `AndroidManifest.xml` dosyaları.

- JSON sürümü: `1`; kural sayısı: `2`.
- Kural 1: priority `1000`, authorizationType `1`, paket sayısı `25`, açık izin girdisi `0`.
  - `com.byd.mycar` listede: `true`; `com.byd.mycar.ts`: `false`; `com.sealion7.companion`: `false`.
- Kural 2: priority `900`, authorizationType `2,2,2,2,2,2,2,2,2`, paket sayısı `9`, açık izin girdisi `184`.
  - `com.byd.mycar` listede: `false`; `com.byd.mycar.ts`: `false`; `com.sealion7.companion`: `false`.

Manifest bulguları:

- `CarAdapterService.apk`: servis `com.ts.appservice.caradapter.CarAdapterService`, manifestte `exported=true`. Bu **dış uygulamanın Binder verisine yetkili olduğu anlamına gelmez**; uygulama kodu ve TS izin/SELinux kuralları ayrıca belirler.
- `BydMyCar.apk`: paket `com.byd.mycar`, hem `android.permission.BYDAUTO_INSTRUMENT_GET` hem `_SET` ve diğer GET/SET izinlerini talep ediyor. İzin **talebi**, izin **verilmesi** değildir.
- `BydMyCarTs.apk`: paket `com.byd.mycar.ts`. Paket adları farklı, binary içerikleri farklı.
- `ts-framework.xml`: Java paylaşımlı kitaplık adı **`ts.framework`**, sistem JAR yolu `/system/framework/ts-framework.jar`.

**Karar:** Kullanıcının orijinal firmware erişimi, üçüncü taraf uygulama yetkilendirmesi veya lisanslı SDK anlamına gelmez. Yeni proje, üretici TS/Binder servisine yetki testi olmadan bağlanmaz. Gizli transact/FID kodu, root, ayrıcalık atlatma veya araç komutu yoktur.
