# 115 firmware tanımı, 172 getter ve gerçek okuma sayacı

- 115: eşleştirilmiş özellik başlıkları. Bunların tümü uygulamaya **kaynak kanıtıyla** ve 7 ekran grubuna yönlendirmeyle eklendi.
- 172: özellik başlıklarının aday getter imzalarındaki tekil adlar. Yüksek sayıda imza paketlerin içinde bulunan nesnelere/packet sınıflarına aittir; bunlar otomatik olarak çağrılabilir anlamına gelmez.
- 566.283: iki ZIP'ten çıkarılmış DEX metot tanımı satırları; çoğu araç telemetrisi değildir ve farklı APK'larda tekrarlanır.
- 4: mevcut aktif kaynak sağlayıcıları (AAOS, TS, BYDAuto, DiLink5). Binder/FID referans modülü aktif araç okuması yapmıyor.
- 4.560: kullanıcının geçmişteki bir taramaya ilişkin ilettiği rakam, bu projede doğrulanmış tarama adedi değil.
- `Okuma çağrısı`: Android Automotive getProperty ya da erişim izinli OEM public getter'ının gerçekten çalıştırılmaya çalışılması. İzin nedeniyle bloklanan, yalnız listede bulunan veya sadece sınıfı tespit edilen getter sayılmaz.
- `Yanıt`: getProperty kullanılabilir bir değer döndürür veya OEM getter null olmayan sonuç verir. Yanıtın doğrulanmış telemetri anlamına gelmediği durumlar olabilir.
- `Geçerli araç ölçümü`: Kaynak birleştirmeden sonra MetricState.Live olan ayrı MetricKey sayısı. Telefon GPS ve hesaplanmış dönem tüketimi bu sayıya karıştırılmaz.
- OEM_READ_APPROVED varsayılan `false`. İmza izni/üretici onayı olmadan OEM servisine bağlanıldığı iddia edilmez. Meta-data anahtarını tek başına değiştirmek yetki sağlamaz.
- Firmware'de tanımlı kapı, klima, ADAS vb. alanlar, kaynaklarıyla ve ekranda `Tanımlı · bağlı değil` durumuyla yer alır. Dönüş tipi/birim/status eşlemesi ve OEM yetkisi doğrulanmadan gerçek canlı değer yayımlanmaz.
