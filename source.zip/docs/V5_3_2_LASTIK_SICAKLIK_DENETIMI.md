# V5.3.2 — Lastik sıcaklıkları veri modeli ve görünümü

## Neden önce dört sıcaklık görünmüyordu?

- Önceki `VehicleModels.MetricKey` yalnız `TIRE_FL`, `TIRE_FR`, `TIRE_RL`, `TIRE_RR` **basınç** alanlarını içeriyordu.
- `AaosReadOnlyTelemetry` tekerlek alan kimlikleriyle **TIRE_PRESSURE (kPa)** okuyordu. AAOS `TIRE_TEMPERATURE` diye desteklenen ve burada doğrulanan standart bir eşleme mevcut değildi.
- Orijinal firmware DEX metot indeksi, `ts-framework.jar` içindeki `CarBodyManager.getTyreTemperatureValue(): int` ve `getTyreTemperatureState(): int` yöntemlerini gösterir. Bu tanımların **her lastiğe özel konum, ölçek veya °C karşılığı** gösterilmemiştir. `getTyreTemperatureValue` parametre almayan tek sonuçtur. Dört sıcaklığı temsil ettiğini varsaymak hatalıdır.

## Yapılan

1. Dört ayrı sıcaklık `MetricKey` eklendi: `TIRE_TEMP_FL`, `TIRE_TEMP_FR`, `TIRE_TEMP_RL`, `TIRE_TEMP_RR`.
2. `TireWheelSummary`, her lastikte **basınç** ve **sıcaklık** satırlarını birlikte gösterir. **Araç Durumu** ve **Sürüş** ekranları aynı bileşeni kullanır.
3. `TireTemperatureEvidence` dört alanı `NEEDS_INTEGRATION` olarak belirtir; `canRead=false`, `canWrite=false`. Tanımlama > Belirlenenler bölümünde bu durum raporlanır.
4. AAOS yetenek listesinde bu dört sıcaklık alanı standart araç özelliği gibi yanlış ilan edilmez.
5. Gerçek OEM kaynağı, konum, izin ve birim doğrulaması olmadan hiçbir lastik sıcaklığına sahte değer atanmamıştır.

## Test / sınırlamalar

- Bu paket Android Studio kaynak kodudur; Android SDK / Gradle bağımlılıkları burada erişilemediğinde APK derlemesi doğrulanmış sayılmaz.
- Gerçek Sealion 7 üzerinde ölçüm testi yapılmadı.
- Sıcaklıklar **şimdilik “— °C”** olarak kalır; dört doğru konumlu ölçüm sağlamak için belgeli OEM protokolü veya doğrulanmış veri alanı gerekir.
