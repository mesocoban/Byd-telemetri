# BYD SEALION 7 — Firmware, kaynak kod ve API inceleme raporu

**Tarih:** 24 Ekim 2026  
**Kapsam:** Verilen 2 orijinal firmware arşivi, 3 kaynak kod arşivi, 2 bağımsız APK (biri zip içinde), 305 özellikli JSON ve Türkçe sistem envanteri.  
**Araç üstünde test:** Yapılmadı. **Derleme:** Android SDK/Gradle indirme ortamı yok; tam Android derlemesi doğrulanmadı.

## 1. İncelemenin temeli ve kesinlik seviyeleri

- **DOSYA İÇERİĞİYLE DOĞRULANAN:** ZIP üyeleri, DEX sınıf ve string tabloları, kaynak Kotlin/Java ve dağıtıcı izin JSON'u incelendi.
- **KAYNAK KODU GÖSTERİYOR:** Dış projelerin veri okuma yaklaşımı ve amaçlanan çalışma platformu. Bu, tüm yöntemlerin kullanıcının aracında test edilip çalıştığı anlamına gelmez.
- **KILAVUZ/KATALOG:** İsimler, tanımlar, referans sayfa ve opsiyon statüsü; API hakları sağlamaz.
- **UYGULAMA TASARIMI:** Kendi Kotlin/Compose kodumuz. Tescilli BYD kodu, ikonu, API şeması veya özel CAN/PID talimatı kopyalanmadı.

**Eksik dosyalar:** Kaynak promptta 222 sayfalık orijinal PDF (`sealion-7-kullanim-kilavuzu-soldan-direksiyon-tr-20250617.pdf`) ve `kilavuz_tam_metin.json` anılıyor; bu iki dosya mevcut eklerde yer almıyor. Dolayısıyla PDF görselleri, bazı sayfa indeksleri ve tüm ham metin doğrulanamadı. Sağlanan katalog dosyasındaki kanıt seviyeleri korunmuştur.

## 2. Firmware envanteri

- `BYD_Telemetri_Ortak.zip`: **149 ZIP üyesi**, açılmış boyut yaklaşık **576,11 MiB**; 8 APK, 5 JAR, 8 ODEX, 10 VDEX, 4 ART, 4 OAT, vendor yerel `.so` kütüphaneleri, konfigürasyon ve izin dosyaları.
- `BydMyCar.zip`: **34 ZIP üyesi**, açılmış boyut yaklaşık **536,22 MiB**; 2 APK, 2 ODEX, 2 VDEX ve native `.so` dosyaları.
- 10 OEM APK ve 5 JAR uygulama/servis düzeyinde araştırıldı; `DEX` string tablosu ve tür imzaları sınıflandırıldı. Ek `firmware_okuma_metot_indeksi.csv` dosyası, beş seçili firmware APK/JAR içindeki okuma/abonelik türü DEX `method_id` imzalarından **19.592 referans satırı** içerir; bunlar yöntem gövdesi veya tekilleştirilmiş fiilî tanım listesi değildir. Kod akışı her metot için tam decompile edilmedi; bu nedenle 'her yöntemin çalıştığı' iddiası yoktur.

### 2.1 Sistem rolleri

| OEM bileşen | Dosyadan saptanan unsur | İşlev hipotezi / güven düzeyi |
| --- | --- | --- |
| `ts-framework.jar` | `CarAdapterManager`, `ICarAdapterService`, `CarGeneralAdapterManager`, `VehicleVendorProperty`, `HalPropertyIds` | TS araç SDK/adaptör sözleşmeleri; **yüksek (türlerin varlığı)** |
| `CarAdapterService.apk` | `CarAdapterService`, `getCurrentSpeed` ve adaptör yöntem imzaları | Servis/araç verisi broker'ı; **yüksek (sınıf/metot dizgesi)** |
| `android.car.jar` | `android.car.*` sınıfları | AAOS Car API çerçevesi; platformda bulunması telefon erişimi vermez |
| `CarService.apk` / `car-frameworks-service.jar` | AAOS araç servis sınıfları | Sistem hizmetleri / izinle erişilebilirlik OEM dağıtımına bağlı |
| `BydAutoService.apk` | BYDAuto izin dizgeleri ve `CarAdapterManager` | BYD/TS araç servisleriyle ilişki; birebir veri kapsamı ispatlanmadı |
| `BydDataCollect.apk` | `VehicleData`, `TravelBean`, `DriverMotorData`, `CarAdapterManager` | Araç telemetri/yolculuk verisi toplama izleri |
| `BydCarSettings.apk` | `IAdasDataRepository` ve BYD ayar sayfası sınıfları | Araç ayarları / donanım seçenekleri; üçüncü taraf yazma yetkisi yok |
| `BydHvac.apk` | `com.byd.hvac.*`, `CarAdapterManager` | HVAC arayüzü ve adaptör ilişkisi |
| `BydCarSystemUI.apk` | `ChargingAdapterManager`, `CarBodyManager`, `OnBodyChangedListener` | Sistem UI ve araç durumu göstergeleri |
| `BydISA.apk` | TS araç adaptör sınıfları | Araç sistem entegrasyonu; spesifik fonksiyon kanıtı sınırlı |
| `BydMyCar.apk`, `BydMyCarTs.apk` | `com.byd.mycar.*`, `CarAdapterManager`, `ICarAdasManager` | Araç ekranı/işlevleri; iki sürümün DEX'leri **birebir aynı değil** |
| `ts-platform-library.jar` | TS Android Auto/CarPlay ve yardımcı servis sınıfları | Projeksiyon/platform hizmetleri; araç verisi izni kanıtı değil |
| `QnxHelperService.jar` | `QnxHelperService` | QNX ile iletişim olasılığı; protokol kanıtı bulunmadı |

### 2.2 OEM arayüz ve grafik varlıkları

`BydMyCar.apk` içinde çok sayıda PNG/XML, JSON yapılandırması ve **Kanzi `.kzb`** arayüz kaynakları yer alıyor. `BydMyCarTs.apk` sürümünde görsel kaynak sayısı farklı; `BydHvac.apk` içinde `aircondition-mc.kzb`, `BydCarSystemUI.apk` içinde yaklaşık 1.966 PNG, 813 WebP ve 16 MP4 üyeli kaynak türü tespit edildi. Bunlar üreticinin gelişmiş 2D/3D araç arayüzüne dair kanıttır. Ancak `.kzb` dosyasının telifli içeriği açılıp yeniden dağıtılmadı; özgün Compose kartları ve çizimleri oluşturuldu.

### 2.3 OEM erişimi ve izinler

`system/etc/permissions/android.hardware.type.automotive.xml`, `android.hardware.type.automotive` özelliğini bildiriyor. `ts-framework.xml`, `/system/framework/ts-framework.jar` kütüphanesini sistem düzeyinde tanımlıyor. `vendor/etc/data/ts_permission_config.json` içinde **2 kural bloğu**, izin tanımları ve uygulama paketlerinden oluşan beyaz liste mantığı bulunuyor; incelenen kurallarda toplam **85 farklı izin adı**, bunun içinde **29 BYDAUTO izin adı** tespit edildi. `BYDAUTO_SPEED_GET`, `BYDAUTO_STATISTIC_GET`, `BYDAUTO_CHARGING_GET` ve `BYDAUTO_INSTRUMENT_GET` gibi örnekler var.

Önemli sonuç: sisteme ön yüklü ve/veya imzalı uygulamalara tahsis edilmiş izinlerin varlığı, kullanıcı uygulamasının bu izinleri alabileceğini **göstermez**. Android Auto, Android Automotive ve normal Android telefon birbirinden ayrılmalıdır.

`vendor/etc/byd/config` altındaki `CanArray.conf`, `ExtensionCanArray.conf`, `EvExtension.conf` yapılandırmaları CAN özellik eşlemesini işaret ediyor. Bu dosyalar bir üretici şeması kanıtıdır, ancak VIN/ECU varyantı, ölçeklendirme, güvenlik onayı ve resmi doküman olmaksızın üçüncü taraf CAN erişimi ya da komut üretimi için güvenilir temel değildir. Rapora özel CAN ID/değerleri veya denetim çerçeveleri konulmadı.

## 3. Yüklenen bağımsız projelerin yöntem karşılaştırması

| Kaynak | Saptanan okuma yolu | Bağlam / sınırlama | Kod lisansı |
| --- | --- | --- | --- |
| `abrp-telemetry-sl7-main.zip` | `VehicleDataManager.kt`: `CarAdapterManager.getInstance()`, `connect()`, `getCarAdapterManager("sensor"/"general"/"charging"/"hvac"/"body")`; `LocationManager` | README DiLink 5.0 / Sealion 7 araç içi kurulumu anlatıyor; üretici izinlerinin genel Android telefonda geçerli olduğunu kanıtlamaz | ZIP içinde bağımsız LICENSE dosyası saptanmadı; kopyalama izni varsayılmadı |
| `byd-trip-stats-develop.zip` | `BydVehicleDataSource.kt`, `Dilink5Client.kt`: `BYDAutoStatisticDevice`, `AbsBYDAutoStatisticListener`, olay dinleyicileri; eski platform varyantlarında farklı toplama stratejisi | Araca kurulan ayrı DiLink varyantları ve ayrı platform/izin koşulları; README'de ADB yetkilendirmesi anlatılıyor | BUSL 1.1; bağımsız kod kopyalanmadı |
| `BYDMate-main.zip` | `HelperDaemon.kt`, `HelperClient.kt`: sistem Binder, `autoservice`, FID olay/okuma yaklaşımı, yardımcı süreç; `TrackingService.kt` | Shell/ADB ile ayrıcalık alan yaklaşım; telefonda taşınabilir genel OEM API değil; güvenlik ve firmware sürüm bağımlılığı yüksek | PolyForm Noncommercial; bağımsız kod kopyalanmadı |
| `Electro-Car-App.zip` | Sadece `Electro-Car-App.apk` ve hash tarzında bir readme. APK'de tek `classes.dex` var | Kaynak kod ve güvenilir API belgeleri bulunmuyor; yalnız paket envanteri incelendi | Belirlenemedi |
| `yoldas-arac-249.apk` | `assets/otomasyon-sinyalleri.json` içinde Türkçe/çok dilli araç sinyal ve tazelik tanımları; ayrıca `guvenli-kullanim.json` | Uygulama varlığı canlı OEM erişimi veya güvenli kontrolün doğrulandığı anlamına gelmiyor; DEX çalışma akışı ayrıntılı decompile edilmedi | Belirlenemedi |

### 3.1 Saptanan örnek getter ↔ hedef metrik ilişkisi

| Hedef | Dış kaynak koddaki yöntem | Doğrulama durumu |
| --- | --- | --- |
| Araç hızı | `CarSensorAdapterManager.getCurrentSpeed()` | ABRP kodunda kullanılıyor; bu araçta çalışma kanıtı henüz yok |
| SOC | `CarGeneralAdapterManager.getElecPercentageValue()` | Aynı |
| Kalan menzil | `CarGeneralAdapterManager.getElecDrivingRangeValue()` | Aynı |
| Toplam kilometre | `CarGeneralAdapterManager.getTotalMileageValue()` | Kaynak kodundan tespit |
| Klima dış sıcaklık | `HvacAdapterManager.getTempratureOut()` | Kaynakta bu yanlış yazılmış metod adı mevcut; geçerli değer filtresi gerekiyor |
| Şarj durumu/güç | `ChargingAdapterManager.getChargerState()` / `getChargingPower()` | Şarj dışı anlarda yanlış değer riski kaynakta belirtilmiş |
| DiLink 5 istatistikleri | `BYDAutoStatisticDevice.registerListener(...)` | Dinleyici/izinli sistem varlığı, uygulama yetkisinin kanıtı değil |

Kaynaklardaki özel servis `Binder` transact numaraları, FID katalogları, kök/ADB kalıcılık yöntemleri, hak yükseltme mantığı **yeni uygulamaya aktarılmadı**. Bunları kullanarak yetkisiz uzaktan kumanda veya güvenlik fonksiyonları üretmek hedeflenmiyor.

## 4. Katalogun sayısal doğruluk kontrolü

**Toplam:** 305 özellik. **Opsiyonel:** 12. **API doğrulandı:** 0. Kılavuz tam ad eşleşmesi **207**, bölüm referansıyla kayıt **92**, eşleşmeyen **6**. Bunlar destek/erişim kanıtı değildir.

| Kılavuz sistem grubu | Kayıt sayısı | Uygulama bölümü |
| --- | ---: | --- |
| Temel gösterge paneli | 13 | Sürüş |
| Gösterge işaretleri ve uyarıları | 51 | Uyarılar |
| Araç anahtarları, erişim ve kapılar | 16 | Sistemler |
| Fiziksel düğmeler ve kontroller | 16 | Sistemler |
| Şarj, batarya ve enerji | 25 | Enerji |
| Sürüş durumu ve park | 18 | Sistemler |
| ADAS ve sürücü destek sistemleri | 26 | ADAS |
| Sürüş güvenliği ve aktif güvenlik | 14 | Sistemler |
| Bilgi eğlence, iletişim ve jestler | 29 | Sistemler |
| Klima ve kabin hava kalitesi | 18 | Sistemler |
| BYD mobil uygulaması | 24 | Sistemler |
| Donanım, bakım ve acil durum | 22 | Sistemler |
| Teknik özellikler ve kimlik | 33 | Kılavuz/Teknik |

**Tam ayrıntı:** `firmware_okuma_metot_indeksi.csv`, `ozellik_api_matrisi_305.csv`, `onerilen_veri_sozlesmesi_35.csv`, `kisaltmalar_42.csv`. JSON kaynak dosyası uygulamanın `app-mobile/src/main/assets/feature_catalog.json` yolundadır. Mevcut uygulama 305 kaydı arayıp filtreler, kaynak kanıtını gösterir; tüm 305 sistem için canlı ekran veya gerçek kontrol iddiası bulunmaz.

## 5. Gerçek API / izin matrisi

| Sağlayıcı | Hedef ortam | Okuma | Yazma | Bu projede gerçekten çalışıyor mu? |
| --- | --- | --- | --- | --- |
| BYD resmî / belgeli OEM API | Yetki verilirse ilgili ortam | Yetki koşullu | Ayrı yetki şart | **Hayır — belgeler/kapsam yok** |
| Android for Cars `CarInfo`, `CarHardwareManager` | Uygun Android Auto/AAOS uygulaması | Destek/izin koşullu | Kısıtlı/yetki koşullu | **Hayır — telefon CarContext vermez** |
| AAOS `CarPropertyManager` | Onaylı gerçek AAOS host ve uygun araç izni | OEM/platform izinli | OEM/platform izinli | **Hayır — varsayılamaz** |
| Yetkili salt-okunur teşhis | Onaylı cihaz/PID/cihaz eşlemesi | Koşullu | **Yok** | **Hayır — gerekli bilgiler yok** |
| Telefon GPS `LocationManager` | Kullanıcı telefonu, konum izni | **Evet**, ayrı etiketli | Yok | **Kod var, cihaz üstünde test edilmedi** |
| Room özellik kaydetme | Android telefonu | Evet | Yalnız yerel yer imi | **Kod var, derleme testi yapılmadı** |
| DataStore GPS tercihi | Android telefonu | Evet | Yerel ayar | **Kod var, derleme testi yapılmadı** |

Google'ın belgelerinde Android for Cars CarInfo için gerçek hız, batarya seviyesi, menzil ve kilometre verisi uygun destek/izin koşullarında mümkündür. Normal bir telefon projesine bu izinlerin eklenmesi, araçtan veri alınacağını ispatlamaz.

## 6. Mimari / bağımlılık grafiği

```mermaid
flowchart TD
    UI[app-mobile / Compose] --> FD[feature:driving]
    UI --> FC[feature:catalog]
    UI --> DX[feature:diagnostics]
    UI --> D[domain:vehicle]
    UI --> R[data:vehicle]
    R --> D
    R --> M[core:model]
    D --> M
    UI --> DB[core:database / Room]
    UI --> PREF[core:preferences / DataStore]
    FD --> M
    FD --> THEME[core:designsystem]
    FC --> THEME
    DX --> M
    R --> P[Android Phone GPS]
    R -. entegrasyon koşulu .-> OEM[Belgeli BYD/CarHardware/Teşhis]
```

- **Telefon sürüş paneli:** En büyük hız rakamı, büyük SOC ve menzil, sürüş modu/vites, güç ve dış sıcaklık. Doğrulanmış OEM kaynak yoksa sayı `—` ve açıkça “Veri alınamıyor”.
- **GPS:** Gerçek ölçüm varsa `Telefon GPS hızı · araç hızı değil` kartı. Tekil taze konum güncellemeleri grafiğe girer. OEM aracın hızıymış gibi sunulmaz.
- **Enerji:** Veri, menzil ve şarj kartları; kontrol yoksa düğme yok.
- **Sistemler ve Tanımlar:** 305 özellik adı, kılavuz bölüm sayfası, opsiyon, kanıt türü, yerel arama ve yer imi.
- **Tanılama:** Sağlayıcı/izin/kullanılabilirlik; hiçbir fiziksel kontrole hükmetmez.
- **Ayarlar:** Konum rızası, yerel saklama hakkında açıklama, devre dışı araç komutları.
- **Güvenlik:** Üreticinin ADAS, fren, direksiyon, kilit, emniyet, hava yastığı, HV/şarj sistemleri için yürütülebilir kontrol yok.

## 7. Sürüşte veri güvenilirliği ilkeleri

1. OEM ölçümü kaynak, zaman, birim, kalite ve tazelikle kaydedilir; `MetricState.Live/Stale/Unavailable` geçişi korunsun.
2. Veri gelmezse **0 göstermeyin**: sıfır hız ile ölçümsüzlük farklı şeylerdir.
3. Telefon GPS hızı yalnız kullanıcı izniyle çalışsın; `vehicle.speed` ile eşleştirilmesin.
4. SOC, menzil ve güç için aralık/plausibility kontrolü eklemeden resmi API verisi canlı kabul edilmesin.
5. Uyarılar veri yokken aktif kritik hata gibi yanmasın; kullanıcıya OEM uyarı bağlantısının mevcut olmadığı açıklansın.
6. Araç kontrolü yazma izni, park durumunun kanıtı, kullanıcı onayı ve karşı taraf onayı olmadan etkinleştirilmesin.
7. Üretici kılavuzunun sürüş güvenliği uyarıları bu uygulamadan daha üst önceliklidir.

## 8. Test, yapılmayanlar ve tamamlanması gereken koşullar

| Çıktı | Durum |
| --- | --- |
| 2 ZIP dosyasına erişim ve üye envanteri | Gerçek dosyadan doğrulandı |
| OEM APK/JAR içinde DEX string/sınıf taraması | Yapıldı (tam decompile değil) |
| 305 özellik matrisi, 42 kısaltma, 35 önerilen sözleşme alanı | Dosyadan üretildi |
| Bağımsız üç kaynak kodunun okuma yaklaşımı | İlgili Kotlin sınıfları incelendi |
| Compose, Hilt, Room, DataStore, LocationManager, ekranlar | Kotlin proje dosyaları oluşturuldu |
| Kotlin model/domain sözdizimi | Yerel `kotlinc` ile derlendi |
| Kotlin saf mantık smoke testi (35 alan / 0-sahte veri / GPS ayrımı / komut kapatma) | Yerel JVM üzerinde başarıyla çalıştırıldı |
| Tam `assembleDebug` | Yapılamadı: Android SDK/Gradle bağımlılık erişimi bulunmadı |
| Emülatör/gerçek telefon UI testi | Gerçekleştirilmedi |
| BYD araç içi canlı telemetri | Gerçekleştirilmedi; yetki ve araç erişimi bulunmadı |
| Android Auto/AAOS dağıtımı | Doğrulanmadı; resmi uygunluk/izin bekliyor |
| OEM UI kaynak grafiklerinin lisanslı kullanımı | Yapılmadı; arayüz özgün Compose ile yazıldı |
| PDF'nin tamamının görsel analiz edilmesi | Orijinal PDF dosyası mevcut değil |

## 9. Sonraki doğrulama için ihtiyaç duyulan bilgiler

- BYD SEALION 7 araçtaki DiLink/Android sistem sürümü ve hedef ekranın telefon mu yoksa bilgi-eğlence birimi mi olduğu.
- Gerçek cihaz üzerinde izinli, belgelenmiş OEM API/SDK kapsamı; mevcutsa sertifikalı read-only ara bağlantı.
- Orijinal PDF'nin tabloları ve gösterge şekilleri için ayrıca paylaşılması; mevcut JSON 222 sayfanın tamamını doğrulama amacıyla ikame etmiyor.
- Android Studio'da derleme sonucu / hata kaydı ve sürüşte güvenli yerde yapılacak salt-okunur bağlanabilirlik sınaması.

## 10. Dış resmi kaynaklar

- Android 17 SDK: https://developer.android.com/about/versions/17/setup-sdk
- Android 17 adaptif tasarım: https://android-developers.googleblog.com/2026/06/Android-17.html
- Car Hardware API: https://developer.android.com/training/cars/apps/library/car-hardware-api
- Compose BOM: https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler
- Hilt yapılandırma: https://dagger.dev/hilt/gradle-setup
- Firmware'de araştırılmış olsa da kamuya açık eski BYD SDK bağlantıları, güncel Sealion 7'de yetki kanıtı değildir.
