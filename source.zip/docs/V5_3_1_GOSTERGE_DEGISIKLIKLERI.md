# Gösterge değişikliği — V5.3.1

| Gösterge | Görünen başlık | Kaynak | Kısıt |
|---|---|---|---|
| Rejenerasyon ayar seviyesi | Rejeneratif frenleme | İzinli AAOS / OEM `REGEN_SETTING` | Geri kazanılmış enerji ölçülmez; değer ayar kademesidir |
| Yön | Yön | Android telefon GPS `Location.bearing` | Hareket halinde, konum izni ve güvenilir güncelleme gerekir; OEM değil |
| Süre | Süre | Cihaz yerel saati | Yolculuk süresi değildir; OEM değil |

Panel, Sürüş, yatay Hızlı Bakış ve Tanımlama / Okunanlar güncellenmiştir.
