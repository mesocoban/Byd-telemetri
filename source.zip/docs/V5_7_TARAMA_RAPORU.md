# V5.7 OEM tanılama ve tarama

* Orijinal 6.683 tekil getter adı tam referans CSV'dedir. Bunların hepsi sensör veya çağrılabilir metot değildir.
* Android uygulamasında 226 seçilmiş parametresiz BYDAuto sayısal/boolean okuyucu adayı vardır.
* Seçim yalnız DEX imza kanıtı üzerinden yapıldı; araç üzerinde hiçbiri test edilmedi.
* "Tanımlama > Okunanlar > OEM Ölçüm Keşfi" üzerinden kullanıcı başlatır.
* İzin, servis sınıfı, public metot, nesne ve ham dönüş ayrı ayrı denetlenir.
* Otomatik JSON raporu Downloads/Sealion7 altına MediaStore ile kaydedilir.
* Araçtaki OEM izinleri manifestte beyan edilmiş olsa bile ayrı onay/üretici imzası gerekir; projenin onay anahtarı varsayılan false.
* Tarama yapılabilmesi için kurumsal/üretici tarafından yetkilendirilmiş bir cihaz gerekir. Kod bu izni aşmaz.
* İçerik sürücü güvenliği veya arıza teşhisi için doğrulanmış değildir. Ham fault kodunu arıza ışığına dönüştürmeyin.
* Tarama her bir sınıf için SDK nesnesini önbellekler; parametreli, yazma/sıfırlama ve özel veri işleyen API'leri çağırmaz.
* İndirmeye otomatik kayıt Android 10+ MediaStore Downloads destekli koşullara bağlıdır; hata UI'da gösterilir.
* Android SDK/Gradle ortamında tam uygulama derlemesi doğrulanamamıştır.
