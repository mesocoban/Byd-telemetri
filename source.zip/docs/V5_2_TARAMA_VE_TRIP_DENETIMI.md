# V5.2 — Tarama, kilometre ve Trip 1/2 incelemesi

## Kullanıcı tarafından bildirilen eksiklikler

- `ODOMETER` daha önce TS/BYDAuto/DiLink 5/AAOS üzerinden vardı; sürüş arayüzünde gösterilmiyordu. Artık sürüş ve enerji ekranında var.
- `TRIP_A` (Kilometre 1) ve `TRIP_B` (Kilometre 2) daha önce `MetricKey` olarak bulunmuyordu. Artık modellerde ve kartlarda var.
- `ts-framework.jar` / `CarGeneralAdapterManager` kanıtı: `getMileageNumberOne(): float`, `getMileageNumberTwo(): float`, `getMileageUnit(): int`.
- Bu firmware'de **`getMileageUnit` birim kodlarının anlamı kesinleşmediğinden** Trip değerleri km/sa gibi uydurulmaz; getter'ın cevabı varsa `Birim doğrulanmadı` raporlanır. Bu durum ancak araç üstünde OEM'nin belgeli birim eşlemesiyle açılabilir.
- Android Automotive standart `PERF_ODOMETER` toplam km içindir, otomatik Trip A/B anlamına gelmez.

## Tarama neden önceden yoktu?

Önceki `DiagnosticsScreen` yalnızca bir yetenek listesini gösteriyordu. `MainViewModel` sadece açılışta ve izin isteme sonucunda `getCapabilities()` çağırıyordu. `Sistemler ve Tanımlar` ekranı 305 maddelik **statik kılavuz dizini**, cihaz tarayıcısı değildir.

## V5.2 tarama davranışı

Tanılama ekranındaki **Kaynakları yeniden tara** butonu `repository.getCapabilities()` ve `repository.refreshIfAuthorized()` çağırır. Sonuç olarak alınabilen erişim aday sayısını, durumları, her metrik için gerçek kaynak/metot/zaman bilgisini gösterir; bağlantı yoksa açıkça yazar. Bu yalnızca **izinli, salt-okunur keşiftir**; araçtaki tüm OEM paketlerini taramaz, gizli servisleri zorlamaz.

## OEM sınırlaması

Manifest `OEM_READ_APPROVED=false` ve normal uygulamaya verilmemiş `CAR_VENDOR_EXTENSION` izni nedeniyle TS/BYDAuto/D5 varsayılan olarak çalışmaz. Bir bayrağı değiştirmek yetki elde etmek değildir. Gerçek araç bağlantı testi yapılmadı.

## Derleme durumu

Proje kaynak kodu hazırlanmıştır; bu ortamda Android SDK/Gradle ağ çözümlemesi olmadığından `assembleDebug` ile doğrulanmadı. İlk araç kurulumundan sonra ADB/logcat ve OEM yetki analizi gereklidir. Güvenlik açısından araca herhangi bir komut gönderilmez.
