# V5.1 — Gradle plugin çözümleme düzeltmesi (24 Ekim 2026)

## Kullanıcı hata kaynağı
`C:\BYD S7 izleyici\Sealion7Companion_Android17_Telemetri_V5\build.gradle.kts` satır 1:

```
Plugin [id: 'com.android.application', version: '9.6.0', apply: false] was not found
```

Bu hata, Gradle **konfigürasyon aşamasındadır**; APK derlenmedi. Bu hata herhangi bir telemetri getter'ının çalışıp çalışmadığını göstermez.

## Uygulanan düzeltme
- Kök `build.gradle.kts` içindeki hem Android application hem Android library plugin sürümleri `9.6.0` → `9.4.0`.
- `gradle/wrapper/gradle-wrapper.properties` içindeki Gradle dağıtımı `9.6.0` **korundu**.
- `compileSdk=37` ve `targetSdk=37` **korundu**.
- Kotlin Compose compiler, KSP ve Hilt plugin sürümleri değiştirilmedi.
- Firmware analizi, TS/BYDAuto/DiLink5 adaptörleri, AAOS veri modelleri ve yerel katalog verileri değişmedi.
- Bu sürüm henüz gerçek araç bağlantısında test edilmedi.

## Gerekçelendirme
Android'in resmî AGP 9.4 sürüm sayfası API 37 ve minimum Gradle 9.6 / JDK 17 uyumunu belgeliyor.
Kaynak: https://developer.android.com/build/releases/agp-9-4-0-release-notes
Kotlin'in Compose Compiler Gradle plugin dokümantasyonu: https://kotlinlang.org/docs/compose-compiler-migration-guide.html

## Derleme / kalan hata olasılıkları
Windows PowerShell ile proje kökünde:

```powershell
.\gradlew.bat --stop
.\gradlew.bat --refresh-dependencies :app-mobile:assembleDebug --stacktrace
```

Android Studio'da `File > Sync Project with Gradle Files`. `Settings > Build Tools > Gradle > Gradle JDK` için JDK 17, SDK Manager'da Android 17 / API 37.
Google Maven bağlantısı yoksa Gradle doğru sürümü yine indiremeyebilir. Önbelleğe alınan Gradle plugin'leri ve çevrimdışı derleme seçenekleri yanlış sürümü engelleyebilir; proxy/VPN/DNS ayarlarını kontrol edin.

**Doğrulama sınırı:** Burada Android SDK ve erişilebilir Gradle dağıtımı olmadığı için `assembleDebug` gerçekleştirilemedi; `BUILD SUCCESSFUL` veya APK oluşturuldu denilemez. Sadece kaynak metni, arşiv bütünlüğü ve sürüm eşleşmesi denetlenmiştir.
