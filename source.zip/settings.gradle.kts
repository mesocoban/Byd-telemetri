pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
 repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
 repositories { google(); mavenCentral() }
}
rootProject.name = "Sealion7Companion"
include(":app-mobile", ":core:model", ":core:designsystem", ":core:database",
 ":core:preferences", ":domain:vehicle", ":data:vehicle",
 ":feature:driving", ":feature:catalog", ":feature:diagnostics",
 ":data:oem-common", ":data:ts-sdk", ":data:bydauto-sdk", ":data:dilink5-sdk", ":data:binder-reference")
