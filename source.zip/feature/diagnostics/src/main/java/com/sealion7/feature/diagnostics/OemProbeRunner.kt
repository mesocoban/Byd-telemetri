package com.sealion7.feature.diagnostics

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.time.Instant
import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.InvocationTargetException

internal enum class ProbeStatus { READ, PERMISSION, UNSUPPORTED, UNAVAILABLE, ERROR }
internal data class ProbeResult(val item:Probe,val status:ProbeStatus,val value:String?,val note:String,val invoked:Boolean)
internal data class ProbeSummary(val results:List<ProbeResult>,val savedUri:String?,val saveError:String?) {
    val attempted:Int get()=results.count { it.invoked }
    fun count(s:ProbeStatus)=results.count { it.status==s }
}
/** One-shot read-only probe; vendor permission, app provisioning and public method checks are mandatory. */
internal object OemProbeRunner {
    private const val vendor="android.car.permission.CAR_VENDOR_EXTENSION"
    private const val approval="com.sealion7.companion.OEM_READ_APPROVED"
    private fun permitted(ctx:Context, cls:String):Boolean {
        val family=cls.removePrefix("android.hardware.bydauto.").substringBefore('.')
        val permission="android.permission.BYDAUTO_${when(family){"tyre"->"TYRE";"gearbox"->"GEARBOX";else->family.uppercase()}}_GET"
        return ctx.checkSelfPermission(vendor)==PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED
    }
    private fun provisioned(ctx:Context):Boolean = runCatching {
        ctx.packageManager.getApplicationInfo(ctx.packageName,PackageManager.GET_META_DATA)
            .metaData?.getBoolean(approval,false)==true
    }.getOrDefault(false)
    fun scan(ctx:Context, selected:List<Probe> = OemProbeCatalog.entries):List<ProbeResult> {
        val authorized=provisioned(ctx)
        val objects=mutableMapOf<String,Any?>()
        return selected.map { p ->
            if(!authorized || !permitted(ctx,p.clazz)) return@map ProbeResult(p,ProbeStatus.PERMISSION,null,"OEM onayı veya sistem izni gerekli",false)
            val cl=runCatching { Class.forName(p.clazz) }.getOrNull()
                ?:return@map ProbeResult(p,ProbeStatus.UNSUPPORTED,null,"SDK sınıfı bulunamadı",false)
            val method=cl.methods.firstOrNull { it.name==p.method && it.parameterCount==0 &&
                java.lang.reflect.Modifier.isPublic(it.modifiers) && it.name.startsWith("get") }
                ?:return@map ProbeResult(p,ProbeStatus.UNSUPPORTED,null,"Public parametresiz getter yok",false)
            val obj=objects.getOrPut(p.clazz) {
                runCatching { cl.getMethod("getInstance",Context::class.java).invoke(null,ctx.applicationContext) }.getOrNull()
            } ?:return@map ProbeResult(p,ProbeStatus.UNAVAILABLE,null,"SDK nesnesi/servisi elde edilemedi",false)
            try {
                val raw=method.invoke(obj)
                if(raw==null) ProbeResult(p,ProbeStatus.UNAVAILABLE,null,"Null yanıt",true)
                else {
                    val value=when(raw) {
                        is IntArray->raw.joinToString(",",limit=32)
                        is FloatArray->raw.joinToString(",",limit=32)
                        is DoubleArray->raw.joinToString(",",limit=32)
                        is Number,is Boolean->raw.toString()
                        else->null
                    }
                    if(value==null) ProbeResult(p,ProbeStatus.UNAVAILABLE,null,"Beklenmeyen dönüş tipi",true)
                    else ProbeResult(p,ProbeStatus.READ,value.take(500),"Ham OEM cevabı; birim/kod doğrulanmadı",true)
                }
            } catch(e:Exception) {
                val cause=(e as? InvocationTargetException)?.targetException ?: e
                val status=if(cause is SecurityException) ProbeStatus.PERMISSION else ProbeStatus.ERROR
                ProbeResult(p,status,null,cause.javaClass.simpleName.take(100),true)
            }
        }
    }
    /** MediaStore Downloads, no broad storage permission. Save all results, including failures. */
    fun save(ctx:Context,results:List<ProbeResult>):Pair<String?,String?> {
        val stamp=java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
            .withZone(java.time.ZoneId.systemDefault()).format(Instant.now())
        val name="Sealion7_OEM_Tarama_${stamp}.json"
        val root=JSONObject()
        root.put("generatedAt",Instant.now().toString())
        root.put("model","Sealion7 Companion V5.7")
        root.put("notVerifiedLiveMetrics",true)
        root.put("attemptedCalls",results.count { it.invoked })
        root.put("counts",JSONObject().also { j -> ProbeStatus.entries.forEach { j.put(it.name,results.count { r->r.status==it }) } })
        root.put("results",JSONArray().also { a ->results.forEach { r->a.put(JSONObject().apply {
            put("group",r.item.group);put("class",r.item.clazz);put("method",r.item.method)
            put("returnType",r.item.resultType);put("status",r.status.name)
            put("raw",r.value?:JSONObject.NULL);put("note",r.note);put("getterInvoked",r.invoked)
        }) } })
        return try {
            val values=ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME,name)
                put(MediaStore.Downloads.MIME_TYPE,"application/json")
                put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Sealion7")
                put(MediaStore.Downloads.IS_PENDING,1)
            }
            val uri=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
                ?:error("Downloads kaydı oluşturulamadı")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
                    ?:error("Dosya açılamadı")
                ctx.contentResolver.update(uri,ContentValues().apply {put(MediaStore.Downloads.IS_PENDING,0)},null,null)
                uri.toString() to null
            }catch(e:Exception){ctx.contentResolver.delete(uri,null,null);throw e}
        }catch(e:Exception){null to (e.message?:e.javaClass.simpleName)}
    }
}
