package com.sealion7.feature.diagnostics

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun OemDiscoveryPanel() {
    val ctx=LocalContext.current
    val scope=rememberCoroutineScope()
    var busy by remember {mutableStateOf(false)}
    var showOemPermissionNote by remember {mutableStateOf(false)}
    var area by remember {mutableStateOf(ScanArea.FIRMWARE)}
    var mode by remember {mutableStateOf(ScanMode.QUICK)}
    var context by remember {mutableStateOf(VehicleContext.UNKNOWN)}
    var current by remember {mutableStateOf<ScanReport?>(null)}
    var filter by remember {mutableStateOf("TÜMÜ")}
    if (showOemPermissionNote) AlertDialog(
        onDismissRequest={showOemPermissionNote=false},
        title={Text("BYD üretici yetkisi")},
        text={Text("BYDAUTO_*_GET ve bazı Android Automotive izinleri üretici imzası veya araç sistem yetkilendirmesi gerektirir. Android standart izin penceresi bu yetkiyi veremez. Taramayı yine başlatabilirsiniz; erişim engeli 'İzin gerekli' olarak kaydedilir.")},
        confirmButton={TextButton(onClick={showOemPermissionNote=false}) {Text("Anladım")}}
    )
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("İki bölümlü telemetri keşfi · V5.9",style=MaterialTheme.typography.titleMedium)
        Text("Birinci bölüm seçilmiş BYD firmware getter'larını, ikinci bölüm araç Android sisteminde görülebilen paket, servis ve SDK sınıflarını kontrol eder.",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick={showOemPermissionNote=true}) {Text("Üretici izinleri hakkında bilgi")}
        Text("Tarama bölümü",style=MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(selected=area==ScanArea.FIRMWARE,onClick={area=ScanArea.FIRMWARE;current=null},label={Text("1 · Firmware OEM")})
            FilterChip(selected=area==ScanArea.INSTALLED_SYSTEM,onClick={area=ScanArea.INSTALLED_SYSTEM;current=null},label={Text("2 · Yüklü sistem")})
        }
        Text("Tarama modu",style=MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(selected=mode==ScanMode.QUICK,onClick={mode=ScanMode.QUICK},label={Text("Hızlı")})
            FilterChip(selected=mode==ScanMode.FULL,onClick={mode=ScanMode.FULL},label={Text("Ayrıntılı")})
        }
        Text("Araç durumu (kullanıcı bildirimi; otomatik doğrulanmış değildir)",style=MaterialTheme.typography.labelMedium)
        val contexts=listOf(VehicleContext.UNKNOWN to "Bilinmiyor",VehicleContext.PARKED to "Park",VehicleContext.CHARGING to "Şarj",VehicleContext.DRIVING to "Sürüş")
        contexts.chunked(2).forEach {chunk-> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            chunk.forEach {(key,title)->FilterChip(selected=context==key,onClick={context=key},label={Text(title)})}
        }}
        val unsafe=mode==ScanMode.FULL && context!=VehicleContext.PARKED && context!=VehicleContext.CHARGING
        if(unsafe) Text("Ayrıntılı OEM taraması yalnız park/şarj olarak işaretlenmiş durumda açılır. Araç gerçekten güvenli şekilde durmuş olmalıdır.",color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
        val target=if(area==ScanArea.FIRMWARE) "${OemProbeCatalog.entries.size} getter adayı" else "sistem servis/paket/sınıf görünürlüğü"
        Text("Kapsam: $target. İzin veya destek yoksa sonuç ayrı işaretlenir; otomatik sürüş taraması yok.",style=MaterialTheme.typography.bodySmall)
        Button(enabled=!busy && !unsafe,onClick={
            busy=true
            scope.launch {
                try {current=withContext(Dispatchers.IO){DualScanEngine.scan(ctx.applicationContext,area,mode,context)}}
                finally {busy=false}
            }
        }) {Text(if(busy)"Taranıyor…" else "Taramayı başlat · JSON + CSV kaydet")}
        current?.let {report->
            Text("Kayıt: ${report.records.size}  ·  Gerçek getter çağrısı: ${report.attempted}")
            Text("Okunan: ${report.count(ProbeStatus.READ)} · İzin: ${report.count(ProbeStatus.PERMISSION)} · Desteklenmiyor: ${report.count(ProbeStatus.UNSUPPORTED)}")
            Text("Yanıt yok: ${report.count(ProbeStatus.UNAVAILABLE)} · Hata: ${report.count(ProbeStatus.ERROR)}")
            Text("Önceki tarama: ${report.diff.previousCount} kayıt · Yeni okunan: ${report.diff.newlyRead} · Kaybolan yanıt: ${report.diff.stoppedReading} · İzin durumu değişimi: ${report.diff.changedPermission}")
            Text("JSON: ${if(report.jsonUri!=null)"İndirilenler/Sealion7" else "Kaydedilemedi"} · CSV: ${if(report.csvUri!=null)"İndirilenler/Sealion7" else "Kaydedilemedi"}")
            report.failures.forEach { Text(it,color=MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                listOf("TÜMÜ","OKUNAN","İZİN","DİĞER").forEach {v->FilterChip(selected=filter==v,onClick={filter=v},label={Text(v)})}
            }
            val shown=report.records.filter {r->when(filter) {
                "OKUNAN"->r.status==ProbeStatus.READ
                "İZİN"->r.status==ProbeStatus.PERMISSION
                "DİĞER"->r.status!=ProbeStatus.READ && r.status!=ProbeStatus.PERMISSION
                else->true
            }}
            shown.take(35).forEach {r->
                HorizontalDivider()
                Text("${r.status} · ${r.key.substringAfterLast('.')}",style=MaterialTheme.typography.bodyMedium)
                Text("${r.group} · ${r.raw?:r.detail}",style=MaterialTheme.typography.bodySmall)
            }
            if(shown.size>35) Text("İlk 35 kayıt görüntüleniyor. ${shown.size} sonuç rapora kaydedildi.")
        } ?: Text("Tarama başlatılmadı. Önceki sonuçlar yalnız karşılaştırma için cihazda saklanır.")
    }
}
