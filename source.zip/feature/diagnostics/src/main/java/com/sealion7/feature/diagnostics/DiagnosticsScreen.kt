package com.sealion7.feature.diagnostics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sealion7.core.designsystem.DataCard
import com.sealion7.core.model.*

@Composable
fun DiagnosticsScreen(
    capabilities: List<VehicleCapability>,
    gpsEnabled: Boolean,
    phoneState: MetricState<Double>,
    snapshot: VehicleSnapshot,
    scanInProgress: Boolean,
    scanSummary: String,
    onScan: () -> Unit,
    phoneHeading: MetricState<Double>,
    deviceClock: String,
    gpsFix: PhoneGpsFixState,
    scanReport: VehicleScanReport?,
    firmwareCount: Int,
    distinctGetters: Int
) {
    val liveOrStale = MetricKey.entries.mapNotNull { key ->
        val state = snapshot.number(key)
        if (state is MetricState.Live || state is MetricState.Stale) key to state else null
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Okunanlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            DataCard("Salt-okunur tarama", Modifier.fillMaxWidth()) {
                Text("Bu bölüm yalnız gerçekten okunan veya daha önce okunup güncelliğini kaybetmiş alanları gösterir. Belirlenen ama canlı veri üretmeyen alanlar ayrı sekmededir.")
                Button(onClick = onScan, enabled = !scanInProgress) {
                    Text(if (scanInProgress) "Taranıyor…" else "Verileri tara")
                }
                Text(scanSummary, style = MaterialTheme.typography.bodySmall)
                Text("Anlık bağlantı: ${snapshot.connection}")
                Text("Canlı alan sayısı: ${snapshot.readings.values.count { it is MetricState.Live<*> }}")
                Text("Belirlenen alan sayısı: ${capabilities.count { it.canRead || it.providerId != null }}")
                HorizontalDivider()
                Text("Firmware'de tanımlı: $firmwareCount özellik / $distinctGetters benzersiz getter")
                Text("4.560 veya DEX içindeki metotların tamamı gerçek okuma sayısı değildir.")
                if (scanReport != null) {
                    Text("Son taramada kontrol edilen kaynak: ${scanReport.sourcesChecked}")
                    Text("Gerçek getter / getProperty çağrısı: ${scanReport.attemptedGetterCalls}", fontWeight=FontWeight.Bold)
                    Text("Null olmayan ham yanıt: ${scanReport.nonNullResponses}")
                    Text("Sorgulanan ayrı kaynak.metot yolu: ${scanReport.distinctInvokedPaths}")
                    Text("Geçerli farklı araç ölçümü: ${scanReport.liveVehicleMetrics}")
                    Text("Güncelliğini yitirmiş araç ölçümü: ${scanReport.staleVehicleMetrics}")
                    scanReport.sourceCallCounts.forEach { (source, count) ->
                        Text("$source: $count gerçek okuma çağrısı", style=MaterialTheme.typography.bodySmall)
                    }
                    Text("Ölçüm başarısı, yalnız kaynak ve birim doğrulamasından sonra geçerli sayılır.", style=MaterialTheme.typography.labelSmall)
                } else {
                    Text("Henüz kullanıcı tarafından gerçek okuma taraması başlatılmadı.")
                }
            }
        }
        item {
            DataCard("Yeni OEM keşif ve otomatik rapor", Modifier.fillMaxWidth()) {
                OemDiscoveryPanel()
            }
        }
        item {
            DataCard("TS CarAdapter · Bağlantı ve yeniden deneme", Modifier.fillMaxWidth()) {
                val s = snapshot.sourceDiagnostics["ts-caradapter-oem"]
                if (s == null) Text("TS oturumu henüz kontrol edilmedi") else {
                    Text("Oturum: ${s.phase} · ${s.description}", fontWeight=FontWeight.SemiBold)
                    Text("Bağlanma denemesi: ${s.connectionAttempts} · Bağlı değil anketleri: ${s.unboundPolls}")
                    if(s.nextRetryMs > 0) Text("Sonraki deneme en erken: ${s.nextRetryMs / 1000} saniye")
                    Text("Son kontrol: ${s.observedAt}",style=MaterialTheme.typography.labelSmall)
                }
                Text("Bir oturuma bağlanmak gerçek sensör verisi okunduğu anlamına gelmez.",style=MaterialTheme.typography.bodySmall)
            }
        }
        item {
            DataCard("ABRP karşılaştırması · TS ham kodları", Modifier.fillMaxWidth()) {
                listOf(MetricKey.TS_SHIFT_MODE_RAW,MetricKey.TS_CHARGER_STATE_RAW).forEach { key ->
                    when(val state=snapshot.number(key)) {
                        is MetricState.Live -> Text("${key.title}: ${state.metric.value.toInt()} (${state.metric.methodEvidence})")
                        is MetricState.Stale -> Text("${key.title}: güncel değil")
                        else -> Text("${key.title}: yanıt veya izin yok")
                    }
                }
                Text("Vites yalnız ABRP'de gözlenmiş P=1, N=3, D=4 olarak etiketlenir. R=2 kanıtlanmış değildir. Şarj kodundan AC/DC sonucu çıkartılmaz.",style=MaterialTheme.typography.bodySmall)
            }
        }
        item {
            DataCard("GPS koordinat ve rakım · yalnız telefon", Modifier.fillMaxWidth()) {
                when(gpsFix) {
                    is PhoneGpsFixState.Fresh -> {
                        Text("Enlem: ${gpsFix.fix.latitude} · Boylam: ${gpsFix.fix.longitude}")
                        Text("Rakım: ${gpsFix.fix.altitudeMeters?.let { "$it m" } ?: "yok"}")
                        Text("Doğruluk: ${gpsFix.fix.accuracyMeters} m · Zaman: ${gpsFix.fix.measuredAt}")
                    }
                    is PhoneGpsFixState.Stale -> Text("Güncel konum yok (${gpsFix.ageSeconds} sn)")
                    is PhoneGpsFixState.PermissionRequired -> Text("Konum izni gerekli")
                    is PhoneGpsFixState.Unavailable -> Text(gpsFix.reason)
                }
                Text("Konum yalnız izinle ve ekran açıkken okunur; uygulama ABRP'ye veya başka sunucuya göndermez.",style=MaterialTheme.typography.labelSmall)
            }
        }
        item {
            val raw = snapshot.oemRawObservations
            DataCard("BydCarSettings.apk · 34 ham veri alanı", Modifier.fillMaxWidth()) {
                Text("34 getter imzası APK kaynaklarında bulundu; bu sayı canlı okuma sayısı değildir.")
                Text("İzin sağlanmadı: ${raw.count { it.status == OemRawStatus.NEEDS_AUTHORIZATION }} · " +
                     "Ham cevap: ${raw.count { it.status == OemRawStatus.RAW_VALUE_UNVERIFIED }} · " +
                     "Eşleme eksik: ${raw.count { it.status == OemRawStatus.METHOD_NOT_VERIFIED }}")
                Text("Ham enum, birimi bilinmeyen float ve arıza kodları aktif araç uyarısına dönüştürülmez.",
                    style = MaterialTheme.typography.labelSmall)
            }
        }
        items(snapshot.oemRawObservations, key = { "oem-${it.id}" }) { observation ->
            DataCard("${observation.id} · ${observation.title}", Modifier.fillMaxWidth()) {
                Text(observation.rawValue?.let { "Ham cevap: $it (doğrulanmadı)" }
                    ?: CarSettingsRawSafety.statusLabel(observation.status))
                Text("${observation.className.substringAfterLast('.')}.${observation.method}()",
                    style = MaterialTheme.typography.bodySmall)
                Text("Gerekli izin: ${observation.permission.substringAfterLast('.')}",
                    style = MaterialTheme.typography.labelSmall)
                observation.observedAt?.let { Text("Örnek zamanı: $it", style = MaterialTheme.typography.labelSmall) }
                if (observation.explanation.isNotBlank()) Text(observation.explanation, style = MaterialTheme.typography.labelSmall)
            }
        }
        item {
            DataCard("TPMS · her lastiğin basınç uyarısı", Modifier.fillMaxWidth()) {
                Text("Bu kontrol OEM'in orijinal TPMS ikaz bayrağı değildir. AAOS'tan izinli okunan kPa ve aynı tekerleğe ait üretici alt basınç sınırı karşılaştırılır.")
                TirePressureSafety.assess(snapshot).forEach { result ->
                    HorizontalDivider()
                    val label = when (result.status) {
                        TirePressureStatus.LOW -> "DÜŞÜK BASINÇ"
                        TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT -> "Alt sınırın üzerinde"
                        TirePressureStatus.LIMIT_UNKNOWN -> "Üretici eşik değeri yok"
                        TirePressureStatus.READING_UNAVAILABLE -> "Veri yok / izin gerekli"
                        TirePressureStatus.READING_STALE -> "Güncel değil"
                        TirePressureStatus.INVALID_READING -> "Veri geçersiz"
                    }
                    Text("${result.wheel.title}: $label", fontWeight = FontWeight.SemiBold)
                    result.pressureKpa?.let { Text("Basınç: $it kPa") }
                    result.minimumKpa?.let { Text("Üretici alt sınırı: $it kPa") }
                    Text("Kaynak: ${result.source} · ${result.explanation}", style = MaterialTheme.typography.labelSmall)
                }
                val active = snapshot.alerts.filter { it.code.startsWith("TPMS_LOW_") }
                Text("Aktif doğrulanmış düşük basınç uyarısı: ${active.size}")
                Text("Ölçüm/limit okunamaması lastiğin güvenli olduğu anlamına gelmez. Fabrika TPMS uyarıları esas alınmalıdır.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (liveOrStale.isEmpty()) {
            item {
                DataCard("Okunan canlı veri yok", Modifier.fillMaxWidth()) {
                    Text("Henüz doğrulanmış canlı araç telemetrisi alınamadı. Tarama sonrası yalnız izinli ve erişilebilir alanlar burada gösterilir.")
                }
            }
        } else {
            items(liveOrStale, key = { it.first.name }) { (key, state) ->
                DataCard(key.title, Modifier.fillMaxWidth()) {
                    when (state) {
                        is MetricState.Live -> {
                            Text("${state.metric.value} ${state.metric.unit}")
                            Text("Kaynak: ${state.metric.providerId}")
                            Text("Kanıt/metot: ${state.metric.methodEvidence.ifBlank { "Platform özelliği" }}", style = MaterialTheme.typography.bodySmall)
                            Text("Alınma: ${state.metric.receivedAt}", style = MaterialTheme.typography.labelSmall)
                        }
                        is MetricState.Stale -> {
                            Text("Son değer: ${state.metric.value} ${state.metric.unit}")
                            Text("Güncel değil · ${state.ageSeconds} sn")
                        }
                        else -> Unit
                    }
                }
            }
        }
        item {
            DataCard("Yön · telefon GPS", Modifier.fillMaxWidth()) {
                when (phoneHeading) {
                    is MetricState.Live -> {
                        Text("${gpsBearingDirectionTr(phoneHeading.metric.value)} · ${phoneHeading.metric.value.toInt()}°")
                        Text("Kaynak: ${phoneHeading.metric.providerId}; hareket yönü (pusula değil)",
                            style = MaterialTheme.typography.labelSmall)
                    }
                    is MetricState.Stale -> Text("GPS yönü güncel değil")
                    is MetricState.PermissionRequired -> Text("Konum izni gerekli")
                    is MetricState.Unavailable -> Text(phoneHeading.reason)
                    is MetricState.Error -> Text("GPS yön hatası: ${phoneHeading.code}")
                    else -> Text("Telefon GPS yönü okunmuyor")
                }
            }
        }
        item {
            DataCard("Süre · cihaz saati", Modifier.fillMaxWidth()) {
                Text(deviceClock, style = MaterialTheme.typography.titleLarge)
                Text("Cihazın yerel saati; araç telemetrisi veya yolculuk süresi değil.",
                    style = MaterialTheme.typography.labelSmall)
            }
        }
        item {
            DataCard("Telefon GPS", Modifier.fillMaxWidth()) {
                Text(
                    if (!gpsEnabled) "Kullanıcı tarafından kapalı" else when (phoneState) {
                        is MetricState.Live -> "Telefon GPS ölçümü var (${phoneState.metric.value} ${phoneState.metric.unit}); araç ölçümü değil"
                        is MetricState.PermissionRequired -> "Konum izni gerekli"
                        is MetricState.Error -> "GPS hata kodu: ${phoneState.code}"
                        is MetricState.Unavailable -> phoneState.reason
                        else -> "Ölçüm bulunmuyor"
                    }
                )
            }
        }
    }
}
