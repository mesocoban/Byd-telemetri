package com.sealion7.feature.diagnostics

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import org.json.JSONArray
import org.json.JSONObject

internal enum class ScanArea { FIRMWARE, INSTALLED_SYSTEM }
internal enum class ScanMode { QUICK, FULL }
internal enum class VehicleContext { UNKNOWN, PARKED, CHARGING, DRIVING }
internal data class ScanRecord(val group:String,val key:String,val status:ProbeStatus,val raw:String?,val detail:String,val invoked:Boolean)
internal data class ScanDiff(val newlyRead:Int,val stoppedReading:Int,val changedPermission:Int,val previousCount:Int)
internal data class ScanReport(val records:List<ScanRecord>,val area:ScanArea,val mode:ScanMode,val context:VehicleContext,val diff:ScanDiff,
    val jsonUri:String?,val csvUri:String?,val failures:List<String>,val time:String=Instant.now().toString()) {
    fun count(s:ProbeStatus)=records.count {it.status==s}
    val attempted get()=records.count {it.invoked}
}

/** Keşif verileri uygulamaya özel saklanır; kullanıcı verisi / dosya içerikleri taranmaz. */
internal object DualScanEngine {
    private const val PREFS="sealion7_discovery_history_v58"
    private fun id(area:ScanArea)=area.name
    private fun previous(ctx:Context,area:ScanArea):Map<String,ProbeStatus> {
        val raw=ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(id(area),null) ?: return emptyMap()
        return runCatching { val obj=JSONObject(raw); obj.keys().asSequence().mapNotNull { k ->
            runCatching { k to ProbeStatus.valueOf(obj.getString(k)) }.getOrNull()
        }.toMap() }.getOrDefault(emptyMap())
    }
    private fun remember(ctx:Context,area:ScanArea,items:List<ScanRecord>) {
        val obj=JSONObject(); items.forEach {obj.put(it.key,it.status.name)}
        ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(id(area),obj.toString()).apply()
    }
    fun scan(ctx:Context,area:ScanArea,mode:ScanMode,context:VehicleContext):ScanReport {
        val before=previous(ctx,area)
        // If a prior complete scan doesn't exist, Quick starts with all safe candidates once.
        val results=when(area) {
            ScanArea.FIRMWARE -> {
                val shortlist=if(mode==ScanMode.QUICK && before.values.any {it==ProbeStatus.READ})
                    OemProbeCatalog.entries.filter { before[it.clazz+"#"+it.method]==ProbeStatus.READ }
                    else OemProbeCatalog.entries
                OemProbeRunner.scan(ctx,shortlist).map {r->ScanRecord(r.item.group,r.item.clazz+"#"+r.item.method,r.status,r.value,r.note,r.invoked)}
            }
            ScanArea.INSTALLED_SYSTEM -> systemScan(ctx,mode,before)
        }
        val diff=ScanDiff(results.count {it.status==ProbeStatus.READ && before[it.key]!=ProbeStatus.READ},
            results.count {it.status!=ProbeStatus.READ && before[it.key]==ProbeStatus.READ},
            results.count {before[it.key]!=null && before[it.key]!=it.status && (before[it.key]==ProbeStatus.PERMISSION || it.status==ProbeStatus.PERMISSION)},before.size)
        // QUICK updates only evaluated entries, retaining all other baseline statuses.
        val merged=if(mode==ScanMode.QUICK) before.toMutableMap().apply {results.forEach {put(it.key,it.status)}} else results.associate {it.key to it.status}.toMutableMap()
        val prefs=JSONObject(); merged.forEach {(k,v)->prefs.put(k,v.name)}
        ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(id(area),prefs.toString()).apply()
        val stamp=DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS").withZone(ZoneId.systemDefault()).format(Instant.now())
        val base="Sealion7_${area.name}_${mode.name}_$stamp"
        val json=JSONObject().apply {
            put("version","5.8"); put("generatedAt",Instant.now().toString()); put("area",area.name);put("mode",mode.name)
            put("vehicleContext",context.name);put("vehicleContextSource","USER_SELECTED_UNVERIFIED")
            put("warning","Ham yanıt canlı sensör ölçümü değildir; kod/birim henüz doğrulanmadı")
            put("attemptedGetterCalls",results.count {it.invoked});put("total",results.size)
            put("counts",JSONObject().also {o->ProbeStatus.entries.forEach {st->o.put(st.name,results.count {it.status==st})}})
            put("comparison",JSONObject().apply {put("previous",diff.previousCount);put("newlyRead",diff.newlyRead);put("stoppedReading",diff.stoppedReading);put("changedPermission",diff.changedPermission)})
            put("results",JSONArray().also {a->results.forEach {r->a.put(JSONObject().apply {
                put("group",r.group);put("methodOrService",r.key);put("status",r.status.name);put("raw",r.raw?:JSONObject.NULL)
                put("note",r.detail);put("invoked",r.invoked)
            })}})
        }
        fun quote(v:String)="\""+v.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\""
        val csv=buildString {
            append("group;method_or_service;status;raw;note;getter_invoked;scan_area;mode;vehicle_context\r\n")
            results.forEach {r->append(listOf(r.group,r.key,r.status.name,r.raw?:"",r.detail,r.invoked.toString(),area.name,mode.name,context.name).joinToString(";"){quote(it)}).append("\r\n")}
        }
        val a=save(ctx,"$base.json","application/json",json.toString(2).toByteArray(Charsets.UTF_8))
        val b=save(ctx,"$base.csv","text/csv",("\uFEFF"+csv).toByteArray(Charsets.UTF_8))
        return ScanReport(results,area,mode,context,diff,a.first,b.first,listOfNotNull(a.second,b.second))
    }
    private fun save(ctx:Context,name:String,mime:String,bytes:ByteArray):Pair<String?, String?> = try {
        val values=ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,mime)
            put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Sealion7");put(MediaStore.Downloads.IS_PENDING,1)
        }
        val uri=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: error("Downloads açılamadı")
        try {
            ctx.contentResolver.openOutputStream(uri)?.use {it.write(bytes)} ?: error("Çıktı yazılamadı")
            ctx.contentResolver.update(uri,ContentValues().apply {put(MediaStore.Downloads.IS_PENDING,0)},null,null)
            uri.toString() to null
        } catch(e:Exception) {ctx.contentResolver.delete(uri,null,null);throw e}
    } catch(e:Exception) {null to "$name: ${e.javaClass.simpleName}: ${e.message}"}

    /** Installed-system visibility is controlled by Android package visibility, not bypassed. */
    private fun systemScan(ctx:Context,mode:ScanMode,before:Map<String,ProbeStatus>):List<ScanRecord> {
        val candidates=listOf(
            "android.car" to "AAOS araç servis kitaplığı",
            "com.ts.caradapter" to "TS CarAdapter uygulama paketi adayı",
            "com.ts.car" to "TS araç servisi paketi adayı",
            "com.byd.auto" to "BYD sistem paketi adayı",
            "com.byd.carsystem" to "BYD araç sistem paketi adayı",
            "com.byd.carsettings" to "BYD araç ayarları paketi adayı",
            "com.byd.auto.service" to "BYD Auto Service paketi adayı"
        )
        val pkgRows=candidates.filter {mode==ScanMode.FULL || before.isEmpty() || before["package:"+it.first]==ProbeStatus.READ}.map {(pkg,note)->
            val exists=runCatching {ctx.packageManager.getPackageInfo(pkg,0)}.isSuccess
            ScanRecord("Yüklü araç paketleri","package:$pkg",if(exists)ProbeStatus.READ else ProbeStatus.UNAVAILABLE,
                if(exists) "visible" else null,"$note; görünmüyor sonucu yüklü değil anlamına gelmeyebilir",false)
        }
        val classes=listOf(
            "com.ts.lib.caradapter.CarAdapterManager",
            "com.ts.lib.car.hardware.instrument.CarVendorInstrumentManager",
            "android.hardware.bydauto.charging.BYDAutoChargingDevice",
            "android.hardware.bydauto.statistic.BYDAutoStatisticDevice",
            "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
            "android.hardware.bydauto.setting.BYDAutoSettingDevice",
            "android.car.Car",
            "android.car.hardware.property.CarPropertyManager"
        )
        val classRows=classes.filter {mode==ScanMode.FULL || before.isEmpty() || before["class:"+it]==ProbeStatus.READ}.map { name->
            val available=runCatching {Class.forName(name)}.isSuccess
            ScanRecord("Yüklü sistem SDK sınıfları","class:$name",if(available)ProbeStatus.READ else ProbeStatus.UNSUPPORTED,
                if(available) "class present" else null,"Yalnız sınıf erişimi; servis bağlılığı veya canlı veri kanıtı değildir",false)
        }
        val services=listOf("car","location","sensor")
        val serviceRows=services.filter {mode==ScanMode.FULL || before.isEmpty() || before["service:"+it]==ProbeStatus.READ}.map {name->
            val obj=runCatching {ctx.getSystemService(name)}.getOrNull()
            ScanRecord("Android sistem servisleri","service:$name",if(obj!=null)ProbeStatus.READ else ProbeStatus.UNAVAILABLE,
                obj?.javaClass?.name,"Sadece erişilebilir servis nesnesi, araçtan getter çağrısı yapılmadı",false)
        }
        return pkgRows+classRows+serviceRows
    }
}
