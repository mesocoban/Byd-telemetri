package com.sealion7.feature.catalog

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sealion7.core.designsystem.DataCard
import com.sealion7.core.model.MetricKey
import com.sealion7.core.model.MetricState
import com.sealion7.core.model.VehicleSnapshot

/** Only a unique validated metric mapping is eligible to show a live value. */
fun matchedFirmwareMetric(candidate: FirmwareCandidate, snapshot: VehicleSnapshot): MetricState<Double>? {
 val key = MetricKey.entries.firstOrNull { it.name == candidate.metricKey } ?: return null
 return snapshot.number(key)
}

@Composable
fun FirmwareCandidateSection(screen: String, entries: List<FirmwareCandidate>, snapshot: VehicleSnapshot) {
 val chosen = remember(screen, entries) { entries.filter { it.screen == screen } }
 var showAll by remember(screen) { mutableStateOf(false) }
 Row(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=4.dp), horizontalArrangement=Arrangement.Center) {
  TextButton(onClick={showAll=true}) {
   Text("${chosen.size} firmware adayı · $screen · Ayrıntılar")
  }
 }
 if(showAll) AlertDialog(onDismissRequest={showAll=false},
  title={Text("$screen · ${chosen.size} tanımlı alan")},
  text={LazyColumn(Modifier.heightIn(max=480.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
   items(chosen,key={it.id}) { item ->
    val state=matchedFirmwareMetric(item,snapshot)
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
     Text(item.title,fontWeight=FontWeight.SemiBold)
     Text(when(state) {
      is MetricState.Live -> "Okunan: ${state.metric.value} ${state.metric.unit} · ${state.metric.providerId}"
      is MetricState.Stale -> "Güncel değil"
      else -> "Tanımlı · canlı okuma doğrulanmadı"
     },style=MaterialTheme.typography.bodySmall)
     Text("Metot: ${item.getters.joinToString()}",style=MaterialTheme.typography.labelSmall)
     HorizontalDivider()
    }
   }
  }},confirmButton={TextButton(onClick={showAll=false}){Text("Kapat")}})
}

@Composable
fun FirmwareEvidenceScreen(entries: List<FirmwareCandidate>, snapshot: VehicleSnapshot) {
 var query by remember { mutableStateOf("") }
 var selected by remember { mutableStateOf("Tümü") }
 val groups=remember(entries){listOf("Tümü")+entries.map{it.screen}.distinct()}
 val shown=entries.filter { (selected=="Tümü"||it.screen==selected) &&
  (query.isBlank() || it.title.contains(query,true)||it.getters.any{m->m.contains(query,true)}) }
 Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("Firmware adayları · ${entries.size}",style=MaterialTheme.typography.headlineSmall)
  Text("Okunan ölçümler başka sekmededir. Bu liste 115 bulguyu ve 172 tekil getter adını açıklar; araçta hepsinin çalıştığını ifade etmez.",style=MaterialTheme.typography.bodySmall)
  OutlinedTextField(value=query,onValueChange={query=it},label={Text("Özellik veya getter ara")},singleLine=true,modifier=Modifier.fillMaxWidth())
  androidx.compose.foundation.lazy.LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
   items(groups) { group -> FilterChip(selected=selected==group,onClick={selected=group},label={Text(group)}) }
  }
  Text("Gösterilen: ${shown.size}",style=MaterialTheme.typography.labelSmall)
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
   items(shown,key={it.id}) { entry ->
    val state=matchedFirmwareMetric(entry,snapshot)
    DataCard("${entry.id} · ${entry.title}",Modifier.fillMaxWidth()) {
     Text("Grup: ${entry.screen}",style=MaterialTheme.typography.labelMedium)
     Text(when(state){
      is MetricState.Live -> "OKUNDU · ${state.metric.value} ${state.metric.unit} · ${state.metric.providerId}"
      is MetricState.Stale -> "GÜNCEL DEĞİL"
      is MetricState.PermissionRequired -> "İZİN GEREKLİ"
      else -> "TANIMLI · DOĞRULANMIŞ CANLI OKUMA YOK"
     },color=if(state is MetricState.Live)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
     Text("Aday metot(lar): ${entry.getters.joinToString()}",style=MaterialTheme.typography.bodySmall)
     Text("Kanıt 1: ${entry.archiveA.ifBlank { "Yok" }}",style=MaterialTheme.typography.labelSmall)
     Text("Kanıt 2: ${entry.archiveB.ifBlank { "Yok" }}",style=MaterialTheme.typography.labelSmall)
     Text("Kalan doğrulama: ${entry.verificationNeeded}",style=MaterialTheme.typography.bodySmall)
    }
   }
  }
 }
}
