package com.sealion7.feature.catalog

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import org.json.JSONObject
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sealion7.core.designsystem.DataCard

/** Original manual-derived catalog; presence in the manual is NOT evidence of live API access. */
data class FeatureEntry(val id:String,val title:String,val group:String,val page:Int?,
 val optional:Boolean,val classification:String,val evidence:String,val sourceNote:String,val apiVerified:Boolean) {
 val status:String get() = when {
  optional -> "Donanım doğrulanmalı"
  classification in listOf("reference+manual","static_trim_specific","physical","information+local_UI") -> "Kılavuz bilgisi"
  else -> if(apiVerified) "API eşleşmesi var" else "Entegrasyon gerekli"
 }
}
data class GlossaryItem(val code:String,val expansion:String)

/** Firmware DEX kanıtıdır; araçtan canlı veri okunduğu anlamına gelmez. */
data class FirmwareCandidate(
 val id: String, val title: String, val group: String, val screen: String,
 val getters: List<String>, val archiveA: String, val archiveB: String,
 val priorStatus: String, val verificationNeeded: String, val metricKey: String,
 val integrationStatus: String
)


class FeatureCatalogLoader @Inject constructor(@ApplicationContext private val context:Context) {
 fun firmwareCandidates(): List<FirmwareCandidate> {
  val arr = JSONObject(context.assets.open("firmware_candidates_115.json").bufferedReader().use { it.readText() }).getJSONArray("features")
  return List(arr.length()) { i ->
   val j=arr.getJSONObject(i)
   val a=j.getJSONArray("getters")
   FirmwareCandidate(j.getString("id"),j.getString("title"),j.getString("group"),j.getString("screen"),
    List(a.length()) { k -> a.getString(k) },j.getString("archiveA"),j.getString("archiveB"),
    j.getString("priorStatus"),j.getString("verificationNeeded"),j.getString("metricKey"),
    j.getString("status"))
  }
 }

 fun glossary():List<GlossaryItem> {
  val raw=JSONObject(context.assets.open("feature_catalog.json").bufferedReader().use{it.readText()})
  val obj=raw.getJSONObject("glossary_manual_page_215")
  return obj.keys().asSequence().map { key -> GlossaryItem(key,obj.getString(key)) }.toList().sortedBy{it.code}
 }
 fun load():List<FeatureEntry> {
  val json=JSONObject(context.assets.open("feature_catalog.json").bufferedReader().use { it.readText() })
  val arr=json.getJSONArray("features")
  return List(arr.length()) { i ->
   val x=arr.getJSONObject(i)
   FeatureEntry(x.getString("id"),x.getString("name_tr"),x.getString("group"),
    if(x.isNull("matched_manual_page")) x.optInt("manual_section_start_page",0).takeIf{it>0}
     else x.optInt("matched_manual_page"),
    x.optBoolean("optional_equipment"),x.optString("classification"),
    x.optString("evidence_match"),x.optString("source"),x.optBoolean("api_verified"))
  }
 }
}
@Composable fun CatalogScreen(entries:List<FeatureEntry>,glossary:List<GlossaryItem>,bookmarks:Set<String>,onToggleBookmark:(String)->Unit) {
 var query by remember { mutableStateOf("") }
 var selectedGroup by remember { mutableStateOf<String?>(null) }
 var selected by remember { mutableStateOf<FeatureEntry?>(null) }
 var onlySaved by remember { mutableStateOf(false) }
 var showGlossary by remember {mutableStateOf(false)}
 val groups=remember(entries){entries.map{it.group}.distinct()}
 Column(Modifier.fillMaxSize().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("Sistemler ve Tanımlar · ${entries.size}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
  OutlinedTextField(value=query,onValueChange={query=it},label={Text("Sistem, kısaltma veya işlev ara")},modifier=Modifier.fillMaxWidth(),singleLine=true)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
   FilterChip(showGlossary,onClick={showGlossary=!showGlossary},label={Text("42 kısaltma")})
   FilterChip(onlySaved,onClick={onlySaved=!onlySaved},label={Text("Kaydedilenler")})
   FilterChip(selectedGroup==null,onClick={selectedGroup=null},label={Text("Tümü")})
  }
  if(!showGlossary) LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
   items(groups){g-> FilterChip(selectedGroup==g,onClick={selectedGroup=g},label={Text(g)})}
  }
  val filtered=remember(entries,query,selectedGroup,onlySaved,bookmarks){entries.filter{e ->
    (selectedGroup==null||e.group==selectedGroup) && (!onlySaved||e.id in bookmarks) &&
    (query.isBlank() || e.title.contains(query,true) || e.group.contains(query,true))}}
  Text(if(showGlossary) "${glossary.size} kısaltma · kılavuz s. 215" else "${filtered.size} kayıt · API desteği ayrıca doğrulanır",style=MaterialTheme.typography.labelSmall)
  if(showGlossary) LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
   items(glossary.filter{query.isBlank()||it.code.contains(query,true)||it.expansion.contains(query,true)}){ item ->
    DataCard(item.code,Modifier.fillMaxWidth()) {Text(item.expansion)}
   }
  } else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
   items(filtered,key={it.id}){e->
    DataCard(e.title,Modifier.fillMaxWidth().clickable{selected=e}) {
     Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
      Text("${e.group} · s. ${e.page ?: "?"}",style=MaterialTheme.typography.bodySmall,modifier=Modifier.weight(1f))
      IconButton(onClick={onToggleBookmark(e.id)}) {Icon(if(e.id in bookmarks)Icons.Default.Bookmark else Icons.Default.BookmarkBorder,contentDescription="Kaydet")}
     }
     Text(e.status,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)
    }
   }
  }
 }
 if(selected!=null){
  val e=selected!!
  AlertDialog(onDismissRequest={selected=null},title={Text(e.title)},
   text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("Grup: ${e.group}");Text("Kılavuz bölümü / sayfa: ${e.page ?: "Belirlenemedi"}")
    Text("İşlev tipi: ${e.classification}");Text("Destek: ${e.status}")
    glossary.firstOrNull{ item -> e.title.contains(Regex("(?<![A-Za-z])"+Regex.escape(item.code)+"(?![A-Za-z])",RegexOption.IGNORE_CASE)) }?.let { Text("Sistem açıklaması (kılavuz sözlüğü): ${it.expansion}") }
    Text("Opsiyonel donanım: ${if(e.optional)"Evet" else "Belirtilmemiş"}")
    Text("Kaynak eşleşmesi: ${e.evidence}")
    Text("Kaynak açıklaması: ${e.sourceNote}")
    Text("Not: Kılavuzda listelenmesi aracınızda donanım veya üçüncü taraf erişimi kanıtlamaz.")
   }},confirmButton={TextButton(onClick={selected=null}){Text("Kapat")}})
 }
}
