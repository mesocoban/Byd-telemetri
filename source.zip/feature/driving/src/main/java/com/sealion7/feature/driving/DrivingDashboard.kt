package com.sealion7.feature.driving

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sealion7.core.designsystem.*
import com.sealion7.core.model.*
import java.util.Locale
import kotlin.math.abs

private fun labelOf(state: MetricState<Double>, decimals: Int = 0): String = when (state) {
    is MetricState.Live -> String.format(Locale.forLanguageTag("tr-TR"), "%.${decimals}f", state.metric.value)
    is MetricState.Stale -> "—"
    else -> "—"
}

@Composable
private fun heroColorForSpeed(state: MetricState<Double>): Color = when (state) {
    is MetricState.Live -> when {
        state.metric.value < 30 -> Palette.positive
        state.metric.value < 90 -> MaterialTheme.colorScheme.primary
        state.metric.value < 130 -> Palette.caution
        else -> MaterialTheme.colorScheme.error
    }
    is MetricState.Stale -> Palette.caution
    is MetricState.Error -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.outline
}

@Composable
private fun socColor(state: MetricState<Double>): Color = when (state) {
    is MetricState.Live -> when {
        state.metric.value < 15 -> MaterialTheme.colorScheme.error
        state.metric.value < 35 -> Palette.caution
        else -> Palette.positive
    }
    else -> MaterialTheme.colorScheme.outline
}

@Composable
fun SpeedHeroCard(state: MetricState<Double>, modifier: Modifier = Modifier) {
    val cardColor by animateColorAsState(heroColorForSpeed(state).copy(alpha = 0.16f), label = "speed-card")
    val ringColor by animateColorAsState(heroColorForSpeed(state), label = "speed-ring")
    val progress by animateFloatAsState(
        targetValue = if (state is MetricState.Live) (state.metric.value / 180.0).toFloat().coerceIn(0f, 1f) else 0f,
        animationSpec = tween(MotionSpec.fillMillis),
        label = "speed-progress"
    )
    DataCard("ARAÇ HIZI · OEM", modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(112.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    drawArc(
                        color = ringColor.copy(alpha = 0.15f),
                        startAngle = 140f,
                        sweepAngle = 260f,
                        useCenter = false,
                        style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = ringColor,
                        startAngle = 140f,
                        sweepAngle = 260f * progress,
                        useCenter = false,
                        style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                Text(labelOf(state), fontSize = 38.sp, fontWeight = FontWeight.Bold)
            }
            Column(
                Modifier
                    .weight(1f)
                    .background(cardColor, RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("km/sa", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (state is MetricState.Live) "Araç kaynağı: ${state.metric.source}" else "Doğrulanmış araç hızı alınamıyor",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun RangeHeroCard(state: MetricState<Double>, modifier: Modifier = Modifier) {
    val bg by animateColorAsState(
        when (state) {
            is MetricState.Live -> if (state.metric.value < 80) Palette.caution.copy(alpha = 0.16f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            else -> MaterialTheme.colorScheme.surfaceVariant
        }, label = "range-card"
    )
    DataCard("KALAN MENZİL", modifier) {
        Box(Modifier.fillMaxWidth().background(bg, RoundedCornerShape(18.dp)).padding(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(labelOf(state), fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text("km · ${if (state is MetricState.Live) "Araç verisi" else "Veri alınamıyor"}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun BatterySocCard(state: MetricState<Double>, modifier: Modifier = Modifier) {
    val ringColor by animateColorAsState(socColor(state), label = "soc-ring")
    val level = if (state is MetricState.Live) (state.metric.value / 100.0).toFloat().coerceIn(0f, 1f) else 0f
    val fill by animateFloatAsState(level, animationSpec = tween(MotionSpec.fillMillis), label = "battery")
    DataCard("BATARYA SOC", modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(76.dp)) {
                CircularProgressIndicator(progress = { fill }, strokeWidth = 8.dp, color = ringColor)
                Text(labelOf(state), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state is MetricState.Live) {
                    LinearProgressIndicator(
                        progress = { fill },
                        modifier = Modifier.fillMaxWidth(),
                        color = ringColor,
                        trackColor = ringColor.copy(alpha = 0.16f)
                    )
                    Text("% · ${state.metric.source}", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Veri alınamıyor", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun MetricTile(title: String, state: MetricState<Double>, unit: String, modifier: Modifier = Modifier) {
    val color by animateColorAsState(
        when (state) {
            is MetricState.Live -> MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            is MetricState.Error -> MaterialTheme.colorScheme.error.copy(alpha = 0.16f)
            else -> MaterialTheme.colorScheme.surfaceVariant
        },
        label = "$title-bg"
    )
    DataCard(title, modifier) {
        Box(Modifier.fillMaxWidth().background(color, RoundedCornerShape(16.dp)).padding(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(labelOf(state, if (unit in listOf("°C", "kW", "kWh", "kWh/100 km")) 1 else 0), fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                Text(when (state) {
                    is MetricState.Live -> "$unit · ${state.metric.providerId} · ${state.metric.receivedAt}"
                    is MetricState.Stale -> "Güncel değil · ${state.ageSeconds} sn"
                    is MetricState.Unavailable -> state.reason
                    is MetricState.PermissionRequired -> "Araç okuma izni gerekli"
                    is MetricState.Error -> "Hata: ${state.code}"
                    else -> "Canlı veri yok"
                }, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

/** Display-only localization: preserve the firmware/SDK SNOW value for decoding. */
private fun driveModeDisplayName(mode: String?): String = when ((mode ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "SNOW", "KAR" -> "KAR"
    else -> mode ?: "—"
}

@Composable
private fun modeCardColor(mode: String?): Color = when ((mode ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "ECO" -> Palette.positive
    "SPORT" -> Palette.caution
    "SNOW", "KAR" -> Color(0xFF74BDF7)
    "NORMAL" -> MaterialTheme.colorScheme.primary
    else -> MaterialTheme.colorScheme.outline
}

@Composable
private fun gearCardColor(gear: String?): Color = when ((gear ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "D" -> Palette.positive
    "R" -> Palette.caution
    "P" -> MaterialTheme.colorScheme.primary
    "N" -> Color(0xFF74BDF7)
    else -> MaterialTheme.colorScheme.outline
}

private fun regenModeLabel(state: MetricState<Double>): String = when (state) {
    is MetricState.Live -> "Ham kademe ${state.metric.value.toInt()}"
    is MetricState.Stale -> "—"
    is MetricState.PermissionRequired -> "Yetki gerekli"
    is MetricState.Unsupported -> "Desteklenmiyor"
    is MetricState.Unavailable -> "Veri yok"
    is MetricState.Error -> "Hata"
    MetricState.Disconnected -> "Bağlantı yok"
}

@Composable
private fun regenCardColor(state: MetricState<Double>): Color = when (regenModeLabel(state)) {
    "Yüksek" -> Palette.positive
    "Standart" -> MaterialTheme.colorScheme.primary
    else -> MaterialTheme.colorScheme.outline
}

private fun driveModeIcon(mode: String?): ImageVector = when ((mode ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "ECO" -> Icons.Default.Eco
    "SPORT" -> Icons.Default.SportsScore
    "SNOW", "KAR" -> Icons.Default.AcUnit
    else -> Icons.Default.DirectionsCar
}

private fun driveModeSubtitle(mode: String?): String = when ((mode ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "ECO" -> "Verimlilik odaklı"
    "SPORT" -> "Daha yüksek tepki"
    "SNOW", "KAR" -> "Kar ve kaygan zemin"
    "NORMAL" -> "Dengeli günlük kullanım"
    else -> "Canlı veri yok"
}

private fun gearSubtitle(gear: String?): String = when ((gear ?: "").uppercase(Locale.forLanguageTag("tr-TR"))) {
    "P" -> "Park"
    "R" -> "Geri"
    "N" -> "Boş"
    "D" -> "İleri sürüş"
    else -> "Canlı veri yok"
}

@Composable
private fun DriveStateCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val bg by animateColorAsState(accent.copy(alpha = 0.16f), label = "$title-bg")
    val border by animateColorAsState(accent.copy(alpha = 0.35f), label = "$title-border")
    DataCard(title, modifier) {
        Surface(
            modifier = Modifier.fillMaxWidth().border(1.dp, border, RoundedCornerShape(18.dp)),
            color = bg,
            tonalElevation = 0.dp,
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = accent.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.padding(10.dp).size(24.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun DriveStateCards(mode: String?, gear: String?, regenState: MetricState<Double>, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            DriveStateCard(
                title = "SÜRÜŞ MODU",
                value = driveModeDisplayName(mode),
                subtitle = if (mode == null) "Canlı veri yok" else driveModeSubtitle(mode),
                icon = driveModeIcon(mode),
                accent = modeCardColor(mode),
                modifier = Modifier.weight(1f)
            )
            DriveStateCard(
                title = "VİTES",
                value = gear ?: "—",
                subtitle = if (gear == null) "Canlı veri yok" else gearSubtitle(gear),
                icon = Icons.Default.SyncAlt,
                accent = gearCardColor(gear),
                modifier = Modifier.weight(1f)
            )
        }
        DriveStateCard(
            title = "REJENERATİF FRENLEME",
            value = regenModeLabel(regenState),
            subtitle = if (regenState is MetricState.Live) "Standart/Yüksek kod eşlemesi bekleniyor" else "İki mod: Standart / Yüksek · veri doğrulanmadı",
            icon = Icons.Default.Autorenew,
            accent = regenCardColor(regenState),
            modifier = Modifier.fillMaxWidth()
        )
    }
}


/** Read-only OEM probes; these are unscaled source values, not decoded car states. */
@Composable
fun CarSettingsRawSummary(snapshot: VehicleSnapshot, categories: Set<String>, modifier: Modifier = Modifier) {
    val items = snapshot.oemRawObservations.filter { (it.id.startsWith("CS-") && it.categoryOfCarSettings() in categories) ||
        (it.id.startsWith("B56-") && it.categoryOfBatteryCharge() in categories) }
    DataCard("Car Settings · ham OEM yanıtları", modifier) {
        Text("Getirilen ham kodlar yalnız tanı amaçlıdır. Birim ve mod çözümü doğrulanmadan canlı göstergeye dönüşmez.",
            style = MaterialTheme.typography.bodySmall)
        if (items.isEmpty()) {
            Text("Kaynak verisi bekleniyor veya OEM erişimi sağlanmadı.", style = MaterialTheme.typography.bodySmall)
        } else {
            items.take(9).forEach { reading ->
                HorizontalDivider()
                Text(reading.title, fontWeight = FontWeight.SemiBold)
                Text(
                    reading.rawValue?.let { "Ham cevap: $it · anlam doğrulanmadı" }
                        ?: CarSettingsRawSafety.statusLabel(reading.status),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (items.size > 9) Text("${items.size - 9} ek alan: Tanımlama > Okunanlar",
                style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun OemRawObservation.categoryOfBatteryCharge(): String =
    BatteryChargeGetterCatalog.entries.firstOrNull { it.id == id }?.category ?: "?"

private fun OemRawObservation.categoryOfCarSettings(): String =
    CarSettingsGetterCatalog.entries.firstOrNull { it.id == id }?.category ?: "?"

@Composable
fun AlertBanner(alerts: List<VehicleAlert>) {
    if (alerts.isNotEmpty()) {
        val highest = alerts.maxByOrNull { it.severity.ordinal } ?: return
        Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.WarningAmber, contentDescription = "Uyarı", tint = MaterialTheme.colorScheme.onErrorContainer)
                Column {
                    Text(highest.message, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                    val count = alerts.count { it.code.startsWith("TPMS_LOW_") }
                    if (count > 1) Text("Toplam $count lastikte düşük basınç saptandı", color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }
    } else {
        Text(
            "Araç uyarı verisi bağlantısı bulunmuyor; bu ekran OEM uyarı panelinin yerine geçmez.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PhoneSpeedTile(state: MetricState<Double>, samples: List<Double>) {
    DataCard("TELEFON GPS HIZI · ARAÇ HIZI DEĞİL", Modifier.fillMaxWidth()) {
        Text(labelOf(state, 1) + " km/sa", fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
        if (samples.size > 1) {
            Canvas(Modifier.fillMaxWidth().height(42.dp)) {
                val ceiling = samples.maxOrNull()?.coerceAtLeast(10.0) ?: 10.0
                val points = samples.mapIndexed { i, v ->
                    Offset(size.width * i / (samples.size - 1), size.height * (1f - (v / ceiling).toFloat().coerceIn(0f, 1f)))
                }
                for (i in 0 until points.size - 1) drawLine(Color(0xFF7BDAE8), points[i], points[i + 1], 2.dp.toPx(), cap = StrokeCap.Round)
            }
        }
        Text(if (state is MetricState.Live) "Telefonun konum sensöründen · güncel" else "GPS ölçümü yok veya güncel değil", style = MaterialTheme.typography.labelSmall)
    }
}

/** Heading is from permitted phone GPS movement; time is the device's local clock. */
@Composable
fun DirectionTimeRow(
    phoneHeading: MetricState<Double>,
    deviceClock: String,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier) {
        val compact = maxWidth < 360.dp
        if (compact) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DirectionCard(phoneHeading, Modifier.fillMaxWidth())
                TimeCard(deviceClock, Modifier.fillMaxWidth())
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DirectionCard(phoneHeading, Modifier.weight(1f))
                TimeCard(deviceClock, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun DirectionCard(state: MetricState<Double>, modifier: Modifier) {
    val signalColor by animateColorAsState(
        if (state is MetricState.Live) Palette.positive else MaterialTheme.colorScheme.outline,
        label = "direction-status"
    )
    DataCard("Yön", modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(48.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(signalColor.copy(alpha = 0.2f))
                    drawCircle(signalColor, radius = 4.dp.toPx())
                }
                if (state is MetricState.Live) {
                    Text("↑", modifier = Modifier.rotate(state.metric.value.toFloat()), color = signalColor, fontSize = 26.sp)
                } else {
                    Text("—", color = signalColor, fontSize = 22.sp)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(
                    if (state is MetricState.Live) {
                        "${gpsBearingDirectionTr(state.metric.value)} · ${state.metric.value.toInt()}°"
                    } else "—",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    when (state) {
                        is MetricState.Live -> "Telefon GPS hareket yönü"
                        is MetricState.Stale -> "GPS yönü güncel değil"
                        is MetricState.PermissionRequired -> "Konum izni gerekli"
                        is MetricState.Error -> "GPS yön hatası"
                        is MetricState.Unavailable -> state.reason
                        else -> "GPS hareket yönü yok"
                    },
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun TimeCard(deviceClock: String, modifier: Modifier) {
    DataCard("Süre", modifier) {
        Text(deviceClock, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
        Text("Cihazın yerel saati · yolculuk süresi değil", style = MaterialTheme.typography.labelSmall)
    }
}

/** Each wheel has two independently sourced metrics. No shared temperature fallback. */
@Composable
fun TireWheelSummary(snapshot: VehicleSnapshot, modifier: Modifier = Modifier) {
    val assessments = TirePressureSafety.assess(snapshot).associateBy { it.wheel }
    DataCard("Lastikler · basınç ve sıcaklık", modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WheelCard("Sol ön", snapshot.number(MetricKey.TIRE_FL), snapshot.number(MetricKey.TIRE_TEMP_FL), assessments.getValue(MetricKey.TIRE_FL))
                WheelCard("Sol arka", snapshot.number(MetricKey.TIRE_RL), snapshot.number(MetricKey.TIRE_TEMP_RL), assessments.getValue(MetricKey.TIRE_RL))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WheelCard("Sağ ön", snapshot.number(MetricKey.TIRE_FR), snapshot.number(MetricKey.TIRE_TEMP_FR), assessments.getValue(MetricKey.TIRE_FR))
                WheelCard("Sağ arka", snapshot.number(MetricKey.TIRE_RR), snapshot.number(MetricKey.TIRE_TEMP_RR), assessments.getValue(MetricKey.TIRE_RR))
            }
        }
        Text("Düşük basınç alarmı yalnız güncel ölçüm ve aynı lastiğin doğrulanmış üretici alt sınırıyla oluşturulur. Sıcaklıklar ayrı doğrulanır.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WheelCard(
    title: String,
    pressure: MetricState<Double>,
    temperature: MetricState<Double>,
    assessment: TirePressureAssessment
) {
    val qualityColor = when (assessment.status) {
        TirePressureStatus.LOW -> MaterialTheme.colorScheme.error
        TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT -> Palette.positive
        TirePressureStatus.READING_STALE -> Palette.caution
        TirePressureStatus.INVALID_READING -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.outline
    }
    val ring by animateColorAsState(qualityColor, label = "tire-$title")
    val status = when (assessment.status) {
        TirePressureStatus.LOW -> "⚠ Düşük basınç"
        TirePressureStatus.WITHIN_RECOMMENDED_LOWER_LIMIT -> "Alt sınırın üzerinde"
        TirePressureStatus.LIMIT_UNKNOWN -> "Alt sınır bilinmiyor"
        TirePressureStatus.READING_STALE -> "Eski veri"
        TirePressureStatus.INVALID_READING -> "Geçersiz okuma"
        TirePressureStatus.READING_UNAVAILABLE -> "Veri yok / izin gerekli"
    }
    val background by animateColorAsState(
        if (assessment.status == TirePressureStatus.LOW) qualityColor.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.58f), label = "tire-bg-$title"
    )
    Surface(shape = RoundedCornerShape(18.dp), color = background) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(9.dp).background(ring, RoundedCornerShape(50)))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            WheelMeasurement("Basınç", pressure, "kPa")
            HorizontalDivider()
            WheelMeasurement("Sıcaklık", temperature, "°C")
            Text(status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = ring)
            assessment.minimumKpa?.let { min ->
                Text("Üretici alt sınırı: ${min.toInt()} kPa", style = MaterialTheme.typography.labelSmall)
            }
            if (assessment.status == TirePressureStatus.LOW) {
                Text("Kaynak: ${assessment.source} · AAOS ölçümünden hesaplanan uyarı", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun WheelMeasurement(label: String, state: MetricState<Double>, unit: String) {
    val status = when (state) {
        is MetricState.Live -> "${labelOf(state, if (unit == "°C") 1 else 0)} $unit"
        is MetricState.Stale -> "— $unit · eski veri"
        is MetricState.PermissionRequired -> "— $unit · izin gerekli"
        is MetricState.Error -> "— $unit · okuma hatası"
        else -> "— $unit"
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(status, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun DrivingDashboardScreen(
    snapshot: VehicleSnapshot,
    phoneState: MetricState<Double>,
    phoneHistory: List<Double>,
    gpsEnabled: Boolean,
    phoneHeading: MetricState<Double>,
    deviceClock: String,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val wide = maxWidth >= 600.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Sürüş görünümü", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            AlertBanner(snapshot.alerts)
            DirectionTimeRow(phoneHeading, deviceClock, Modifier.fillMaxWidth())
            if (wide) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SpeedHeroCard(snapshot.number(MetricKey.VEHICLE_SPEED), Modifier.weight(2f))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        RangeHeroCard(snapshot.number(MetricKey.RANGE), Modifier.fillMaxWidth())
                        BatterySocCard(snapshot.number(MetricKey.SOC), Modifier.fillMaxWidth())
                    }
                }
            } else {
                SpeedHeroCard(snapshot.number(MetricKey.VEHICLE_SPEED), Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    RangeHeroCard(snapshot.number(MetricKey.RANGE), Modifier.weight(1f))
                    BatterySocCard(snapshot.number(MetricKey.SOC), Modifier.weight(1f))
                }
            }
            DriveStateCards(snapshot.driveMode, snapshot.gear, snapshot.number(MetricKey.REGEN_SETTING))
            CarSettingsRawSummary(snapshot, setOf("Sürüş"), Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile("ÇEKİŞ GÜCÜ (MOTOR)", snapshot.number(MetricKey.TRACTION_POWER), "kW", Modifier.weight(1f))
                MetricTile("DIŞ SICAKLIK", snapshot.number(MetricKey.OUTSIDE_TEMP), "°C", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile("BATARYA TÜKETİM GÜCÜ", snapshot.number(MetricKey.BATTERY_CONSUMPTION_POWER), "kW", Modifier.weight(1f))
                MetricTile("REJENERASYON GÜCÜ", snapshot.number(MetricKey.REGEN_POWER), "kW", Modifier.weight(1f))
            }
            EnergyConsumptionCards(snapshot, includeTrips = true)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile("BATARYA NET (+ŞARJ)", snapshot.number(MetricKey.BATTERY_NET_POWER), "kW", Modifier.weight(1f))
                MetricTile("BATARYA SICAKLIĞI", snapshot.number(MetricKey.BATTERY_AVG_TEMP), "°C", Modifier.weight(1f))
            }
            TireWheelSummary(snapshot, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile("TOPLAM KİLOMETRE", snapshot.number(MetricKey.ODOMETER), "km", Modifier.weight(1f))
                MetricTile("KİLOMETRE 1 · TRIP A", snapshot.number(MetricKey.TRIP_A), "km", Modifier.weight(1f))
            }
            MetricTile("KİLOMETRE 2 · TRIP B", snapshot.number(MetricKey.TRIP_B), "km", Modifier.fillMaxWidth())
            Text("Yalnız rejenerasyon ayar kademesi; geri kazanılan enerji ölçümü değildir.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (gpsEnabled) PhoneSpeedTile(phoneState, phoneHistory)
            Text(
                "Bilgilendirme uygulamasıdır. Fabrika gösterge paneli ve güvenlik sistemlerini esas alın.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}


/** Shared consumption cards: same repository states in Panel, Driving and Battery/Charging. */
@Composable
fun EnergyConsumptionCards(snapshot: VehicleSnapshot, includeTrips: Boolean = false) {
    Text("Enerji tüketimi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        MetricTile("ANLIK TÜKETİM", snapshot.number(MetricKey.INSTANT_CONSUMPTION), "kWh/100 km", Modifier.weight(1f))
        MetricTile("İZLEME ORTALAMASI", snapshot.number(MetricKey.TRACKED_AVG_CONSUMPTION), "kWh/100 km", Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        MetricTile("TÜKETİLEN ENERJİ · İZLEME", snapshot.number(MetricKey.TRACKED_ENERGY_CONSUMED), "kWh", Modifier.weight(1f))
        MetricTile("GERİ KAZANILAN · İZLEME", snapshot.number(MetricKey.RECOVERED_ENERGY), "kWh", Modifier.weight(1f))
    }
    Text("İzleme: uygulamanın açık olduğu ve eşzamanlı araç ölçümleri aldığı dönem. " +
         "Tüm yolculuğun/fabrika sayacının geçmiş tüketimi değildir.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (includeTrips) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile("TRIP A · İZLENEN ORT.", snapshot.number(MetricKey.TRIP_A_AVG_CONSUMPTION), "kWh/100 km", Modifier.weight(1f))
            MetricTile("TRIP B · İZLENEN ORT.", snapshot.number(MetricKey.TRIP_B_AVG_CONSUMPTION), "kWh/100 km", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile("TRIP A · TÜKETİLEN", snapshot.number(MetricKey.TRIP_A_ENERGY_CONSUMED), "kWh", Modifier.weight(1f))
            MetricTile("TRIP B · TÜKETİLEN", snapshot.number(MetricKey.TRIP_B_ENERGY_CONSUMED), "kWh", Modifier.weight(1f))
        }
        MetricTile("SON TAMAMLANAN YOLCULUK ORT.",
            snapshot.number(MetricKey.LAST_TRIP_AVG_CONSUMPTION), "kWh/100 km", Modifier.fillMaxWidth())
        Text("Trip A/B ve son yolculuk için doğrulanmamış firmware değerleri tüketim gibi kullanılmaz.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
