# OEM firmware / kaynak okuma eşleştirmesi

| Firmware / bağımsız proje | Veri yolu | Uygulama katmanı | Yetki |
|---|---|---|---|
| `BYD_Telemetri_Ortak.zip`: `ts-framework.jar`, `CarAdapterService.apk` | TS `CarAdapterManager`, sensör/genel/şarj/HVAC | `:data:ts-sdk` | Mevcut uygulama firmware TS allowlist'inde değil |
| `BYD_Telemetri_Ortak.zip`: `BydAutoService.apk` | `android.hardware.bydauto.*` getter'lar | `:data:bydauto-sdk` | OEM READ imza izni gerektiği varsayılmalı; doğrulanmadı |
| `BydMyCar.zip`: `BydMyCar.apk` / `BydMyCarTs.apk` | TS ve BYDAuto istemci referansları | Yöntem kanıtı ve izin envanteri | Farklı paket ve binary, üreticiye ait istemciler |
| `abrp-telemetry-sl7-main.zip` | TS SDK snapshot getter'ları | `:data:ts-sdk` | Belirli baş ünitede yetkiye bağlı |
| `Electro-Car-App.zip` içindeki Electro APK | BYDAuto getter/Listener + MQTT aktarımı | `:data:bydauto-sdk` (yalnız getter) | MQTT aktarımı uygulamaya kopyalanmadı |
| `byd-trip-stats-develop.zip` | DiLink 5 typed listener / polling | `:data:dilink5-sdk` (yalnız polling) | Listener uygulama kodu OEM SDK olmadan kopyalanmadı |
| `yoldas-arac-249.apk` | DiLink 5 ölçüm/doğrulama, `.so` hook | Tanım ve eşleştirme kanıtı | Hook kullanılmaz |
| `BYDMate-main.zip` | `autoservice` Binder FID, BMS DB | `:data:binder-reference` | Salt referans, transact yok |
| `android.car.jar` | AAOS kamusal `CarPropertyManager` | `:data:vehicle` | AAOS host + uygun Android izni |

**Kritik:** Firmware dosyalarındaki sınıf imzasının bulunması, ilgili çağrının bu uygulamada yetkili veya canlı çalıştığını kanıtlamaz. APK/JAR'lar çalışma zamanı APK'sına kopyalanmadı. Bazı API adları üçüncü taraf kaynaklardan öğrenilen gözlemlerdir ve BYD resmî sözleşmesi değildir.
