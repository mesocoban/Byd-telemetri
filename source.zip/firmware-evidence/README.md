# Kullanıcının firmware arşivlerinden alınan inceleme verileri

- `ts_permission_config.json` ve `ts-framework.xml` kullanıcıya ait ZIP içindeki yapılandırma dosyalarının **inceleme kopyalarıdır**, çalışan telefona veya araç sistemine yüklenmez.
- `Firmware_APK_metot_eslesmeleri.csv` ve `APK_onemli_sinif_tanimlari.csv` önceki DEX taramasında sınıf, metod, tanım ve kod gövdesi kanıtıdır; getter'ın araçta başarıyla çalıştığının kanıtı DEĞİLDİR.
- `source_method_matrix.csv` kaynağa dayanan yöntem/sinyal eşlemesi; resmî üretici SDK belgesi değildir.
- `source_sha256.json` kullanıcıdan gelen bütün ZIP/APK'ların SHA256 kanıtıdır. Bu kullanıcı ZIP'lerinin kendileri boyut ve sahipli yazılım nedeniyle Android proje çıktısına dahil edilmedi.
- `BYD_SEALION7_KILAVUZ_OZELLIK_KATALOGU.json`: 305 özellik; kılavuz sayfaları ve `api_verified:false` durumları korunur.
- Firmware içindeki herhangi bir APK/JAR/DEX/.so uygulamaya kopyalanmadı. Decompile edilen üçüncü taraf kodu kopyalanmadı; adapterlar özgün Kotlin ile yazıldı.
