# BYD SEALION 7 — Kılavuz Adları ve Sistem Envanteri

222 sayfalık kullanıcı kılavuzundan geliştirilen işlev adları ve sayfa referansları. Donanımın varlığı ve API erişimi ayrıca doğrulanmalıdır.

## Temel gösterge paneli (kılavuz bölüm başlangıcı: s. 34)

- Yön
- Süre
- Sürüş modu
- Hız Ölçer
- Vites durumu
- Rejeneratif frenleme
- Dış sıcaklık
- Toplam kilometre
- Güç ölçer
- Sürüş menzili
- Şarj durumu (SOC)
- Basit modda gösterge paneli görünümü
- Göstergeler/Uyarı Lambaları

## Gösterge işaretleri ve uyarıları (kılavuz bölüm başlangıcı: s. 35)

- Sola dönüş sinyali göstergesi
- Sağa dönüş sinyali göstergesi
- Far düğmesi göstergesi*
- Kısa far göstergesi
- Tamam göstergesi
- Konum ışığı göstergesi
- AVH göstergesi
- Deşarj göstergesi
- Uzun far göstergesi
- AFL göstergesi
- AEB göstergesi
- AHK (Akıllı Hız Kontrolü) göstergesi
- Şeritten ayrılma alarmı göstergesi
- AHSS göstergesi
- AEB arıza uyarı lambası
- AHK arıza uyarı lambası
- LDA arıza uyarı lambası
- AHSS arıza uyarı lambası
- Sürüş gücü limiti uyarı lambası
- ABS arıza uyarı lambası
- Yüksek voltajlı pil düşük SOC uyarı lambası
- BSD arıza uyarı lambası
- AVAS KAPALI göstergesi*
- Arka sis farı göstergesi
- Lastik basıncı arıza uyarı lambası
- Akıllı anahtar uyarı lambası
- ESC OFF uyarı lambası*
- Ana alarm göstergesi
- ESC arıza uyarı lambası
- Ön far arıza uyarı lambası
- AEB uyarı lambası
- Yüksek voltajlı pil şarj bağlantı göstergesi
- Düşük voltajlı güç sistemi arıza uyarı lambası
- Yüksek voltajlı pil arıza uyarı lambası
- Motor aşırı ısınma uyarı lambası
- Yüksek voltajlı pil aşırı ısınma uyarı lambası
- Güç aktarma organı arıza uyarı lambası
- Soğutma sıvısı aşırı ısınma uyarı lambası
- Emniyet kemeri hatırlatma göstergesi
- Hava yastığı arıza uyarı lambası
- EPB göstergesi
- Fren sistemi arıza uyarı lambası
- TSR göstergesi
- Direksiyon sistemi arıza uyarı lambası
- Konfor modu göstergesi
- Spor modu göstergesi
- Ekonomik mod göstergesi
- Kar modu göstergesi
- EV fonksiyonu sınırlı
- Lütfen ön far sistemini kontrol edin
- ADAS fonksiyonu sınırlı

## Araç anahtarları, erişim ve kapılar (kılavuz bölüm başlangıcı: s. 46)

- Elektronik akıllı anahtar
- NFC anahtar
- Mekanik anahtar
- Kapı kilidi
- Kapı kilidini açma
- Akıllı erişim ve başlatma sistemi
- Çocuk koruma kilidi
- Bagaj kapağı
- Elektrikli camlar
- Elektrikli yan aynalar
- Merkezi kilitleme
- Hırsızlık önleme alarm sistemi
- Kapı açık durumları
- Ön koltuklar
- Arka koltuklar
- Koltuk ısıtma durumu

## Fiziksel düğmeler ve kontroller (kılavuz bölüm başlangıcı: s. 65)

- Direksiyon düğmeleri
- Direksiyon ayarı
- Silecek düğmesi
- Işık düğmeleri
- Sürücü kapısı cam düğmeleri
- Yolcu tarafı cam kontrol düğmesi
- Kilometre sayacı düğmesi
- BSD düğmesi
- AVH düğmesi
- Sürüş modu ayar kolu
- Rejeneratif frenleme ayar kolu
- Ön yolcu hava yastığı düğmesi
- Tehlike uyarı lambası düğmesi
- Açılır tavan gölgeliği düğmeleri
- E-Çağrı düğmesi
- İç aydınlatma düğmesi

## Şarj, batarya ve enerji (kılavuz bölüm başlangıcı: s. 82)

- AC şarj
- DC şarj
- Mod 2 şarj kablosu
- Şarj istasyonu
- Şarj bağlantı noktası
- Şarj bağlantı noktası immobilizer sistemi
- Şarj durumu (SOC)
- Tam şarj için tahmini kalan süre
- Şarj bağlantısı göstergesi
- Akıllı şarj
- Planlı şarj
- Planlı kalkış*
- Başlangıç saati
- Bitiş saati
- Tekrar döngüsü
- AC sınırlı akımla şarj*
- Deşarj (V2L)
- Deşarj göstergesi
- Standart menzil görüntüleme
- Dinamik menzil görüntüleme
- Enerji tüketimi
- Yüksek voltajlı pil
- Düşük voltajlı akü
- Batarya Yönetim Sistemi (BMS)
- Şarj arızaları ve uyarıları

## Sürüş durumu ve park (kılavuz bölüm başlangıcı: s. 110)

- START/STOP
- Araç çalıştırma
- Vites mekanizması
- P vitesi
- R vitesi
- N vitesi
- D vitesi
- Elektronik El Freni (EPB)
- Otomatik Araç Tutma (AVH)
- Konfor modu
- Ekonomik mod
- Spor modu
- Kar modu
- Rejeneratif frenleme gücü
- Standart rejeneratif frenleme
- Odometer
- Kilometre 1
- Kilometre 2

## ADAS ve sürücü destek sistemleri (kılavuz bölüm başlangıcı: s. 118)

- Adaptif Hız Sabitleme Sistemi (AHSS)
- Akıllı Hız Kontrolü (AHK)
- Önden Çarpışma Uyarısı (FCW)
- Otomatik Acil Frenleme (AEB)
- Ön Çapraz Trafik Uyarısı (FCTA)
- Ön Çapraz Trafik Freni (FCTB)
- Trafik İşareti Tanıma (TSR)
- Akıllı Hız Limiti Kontrolü (ISLC)
- Adaptif Ön Işık (AFL)
- Şeritten Ayrılma Alarmı (LDA)
- Şeritten Ayrılma Uyarısı (LDW)
- Şeritten Ayrılmayı Önleme (LDP)
- Acil Durum Şerit Takip Asistanı (ELKA)
- Kör Nokta Asistanı (BSA)
- Kör Nokta Tespiti (BSD)
- Ön Ekran (HUD)*
- Doğrudan Lastik Basıncı İzleme (TPMS)
- Akustik Araç Uyarı Sistemi (AVAS)
- Çevre Görünümü Monitörü (AVM)
- Park Yardım Sistemi
- Sürücü İzleme Sistemleri (DMS)
- Sürücü yorgunluk uyarısı
- Sürücü dikkat dağılma uyarısı
- Çocuk Varlığı Algılama (CPD)*
- Akıllı Tork Adaptasyon Kontrolü (iTAC)*
- Araç yol kamerası*

## Sürüş güvenliği ve aktif güvenlik (kılavuz bölüm başlangıcı: s. 144)

- Araç Dinamik Kontrolü (VDC)
- Çekiş Kontrol Sistemi (TCS)
- Kilitlenme Önleyici Fren Sistemi (ABS)
- Elektronik Stabilite Kontrolörü (ESC)
- Hidrolik Fren Asistanı (HBA)
- Tepe İniş Desteği (HHC)
- El freni için kontrollü yavaşlama (CDP)
- Çoklu Çarpışma Freni (MCB)
- Rahat Park Etme (CST)
- Fren diski silme
- Arkadan Çarpışma Trafik Uyarısı (RCTA)
- Arka Çapraz Trafik Freni (RCTB)
- Arkadan Çarpışma Uyarısı (RCW)
- Kapı Açık Uyarısı (DOW)

## Bilgi eğlence, iletişim ve jestler (kılavuz bölüm başlangıcı: s. 154)

- Bilgi-eğlence dokunmatik ekranı
- Gezinti çubuğu
- Önceki sayfa
- Ana sayfa
- Ayar ekranı
- Uygulama listesi
- Bölünmüş ekran
- Yatay/dikey ekran geçişi
- Klima ekranı
- Tek dokunma
- Sürükleme
- Kaydırma
- Çift dokunma
- İki parmakla yayma/sıkma
- Üç parmakla sağ/sola kaydırma (fan)
- Üç parmakla yukarı/aşağı kaydırma (sıcaklık)
- Üstten aşağıya kaydırma (kısayol)
- Alttan yukarıya kaydırma (görevler)
- Sol/sağ kenardan kaydırma (geri)
- Kablosuz OTA güncelleme
- BYD Asistanı
- Bluetooth
- Hoparlörler
- Dosya Yönetimi
- Apple CarPlay
- Android Auto
- Fabrika ayarlarına sıfırlama
- Ekran koruyucu
- Ses 0-39

## Klima ve kabin hava kalitesi (kılavuz bölüm başlangıcı: s. 159)

- A/C açık/kapalı
- AUTO
- Sıcaklık
- Sürücü sıcaklık ayarı
- Yolcu sıcaklık ayarı
- Bağımsız/bağıl sıcaklık
- Fan hızı
- Hava dağıtımı
- Hava sirkülasyonu
- Temiz hava modu
- Ön cam buz çözücü
- Arka cam ve yan aynalar için buz çözücü
- Ekonomi/Konfor seçenekleri
- Koltuk ısıtma
- Havalandırmalar
- PM2.5 algılama*
- Hızlı temizleme*
- İyon/anyon jeneratörü*

## BYD mobil uygulaması (kılavuz bölüm başlangıcı: s. 165)

- BYD uygulaması (IoV)
- Hesap kaydı
- Araca kayıtlı e-posta
- Araçlar arası geçiş
- Araç adlandırma
- Plaka
- Kalan sürüş menzili
- SOC
- Hata bilgisi
- Sürüş durumu
- Şarj durumu
- Klima durumu
- Koltuk ısıtma durumu
- Lastik basıncı
- Uzaktan kilitle
- Uzaktan kilit aç
- Işıkları yanıp söndür
- Korna çal/ışıkla uyar
- Klima aç/kapat
- Kapı/cam/koltuk/lastik durum ekranları
- Hesap ve Güvenlik
- Mesaj ayarları
- Otomatik oturum açma
- Bölge seçimi

## Donanım, bakım ve acil durum (kılavuz bölüm başlangıcı: s. 166)

- Motor bölmesi depolama
- Torpido gözü
- Orta konsol gözü
- 12V yardımcı güç
- USB bağlantı noktaları
- SD kart yuvası
- Qi kablosuz telefon şarjı
- Bakım döngüsü
- Araç temizliği
- Kaput
- Soğutma sistemi
- Fren hidroliği
- Cam fıskiyesi
- Silecek lastikleri
- Lastik kontrolü
- Sigortalar
- Akıllı anahtar pilinin bitmesi
- Acil durum kapatma sistemi
- Araç yangın kurtarma
- Yüksek voltajlı pil sızıntısı
- Çekme prosedürü
- Lastik patlaması

## Teknik özellikler ve kimlik (kılavuz bölüm başlangıcı: s. 202)

- Uzunluk
- Genişlik
- Yükseklik
- Aks mesafesi
- Ön iz genişliği
- Arka iz genişliği
- Ön burun
- Arka burun
- Yaklaşma açısı
- Kalkış açısı
- Yüksüz ağırlık
- Aks yükleri
- Maksimum kütle
- Yolcu sayısı
- Motor model numarası
- Motor türü
- Çekiş tipi
- Nominal güç
- Maksimum güç
- Tork
- Maksimum tasarım hızı
- Maksimum tırmanma kabiliyeti
- 100 km başına güç tüketimi
- Pil kimyası
- Pil nominal kapasitesi (Ah)
- Lastik teknik özellikleri
- Önerilen lastik basıncı
- Fren diski kalınlıkları
- Fren hidroliği
- Soğutma sıvısı
- VIN
- Uygunluk beyanı
- RF cihazları

## Kısaltmalar

- **ELR:** Acil Durum Kilitleme Geri Çekme
- **ECU:** Elektronik Kontrol Ünitesi
- **ISOFIX:** Uluslararası Standartlar Organizasyonu Sabit
- **EDR:** Olay Veri Kaydedicisi
- **E-Çağrı:** Acil Durum Araması
- **EPB:** Elektronik El Freni
- **AVH:** Otomatik Araç Tutma
- **SOC:** Şarj Durumu
- **AHSS:** Adaptif Hız Sabitleme Sistemi
- **AHK:** Akıllı Hız Kontrolü
- **FCW:** İleri Çarpışma Uyarısı
- **AEB:** Otomatik Acil Frenleme
- **FCTA:** Ön Çapraz Trafik Uyarısı
- **FCTB:** Ön Çapraz Trafikte Frenleme
- **TSR:** Trafik İşareti Tanıma
- **ISLC:** Akıllı Hız Limiti Kontrolü
- **AFL:** Adaptif Ön Işık
- **LDA:** Şeritten Ayrılma Alarmı
- **LDP:** Şeritten Ayrılmayı Önleme
- **LDW:** Şeritten Ayrılma Uyarısı
- **ELKA:** Acil Durum Şerit Takip Asistanı
- **BSA:** Kör Nokta Asistanı
- **AVAS:** Akustik Araç Uyarı Sistemi
- **HUD:** Ön Ekran
- **BSD:** Kör Nokta Tespiti
- **RCTA:** Arkadan Çarpışma Trafik Uyarısı
- **RCTB:** Arka Çapraz Trafik Freni
- **RCW:** Arkadan Çarpışma Uyarısı
- **DOW:** Kapı Açık Uyarısı
- **VDC:** Araç Dinamik Kontrolü
- **TCS:** Çekiş Kontrol Sistemi
- **HHC:** Tepe İniş Desteği
- **HBA:** Hidrolik Fren Asistanı
- **CDP:** El Freni için Kontrollü Yavaşlama
- **CST:** Rahat Park Etme
- **ESC:** Elektronik Stabilite Kontrolörü
- **MCB:** Çoklu Çarpışma Freni
- **DMS:** Sürücü İzleme Sistemi
- **TPMS:** Lastik Basıncı İzleme Sistemi
- **VIN:** Araç Şasi Numarası
- **MAKS:** Maksimum
- **MIN:** Minimum

## Gerçek veri sözleşmesi — önerilen adlandırma, OEM API değildir

- `vehicle.speed`: Araç hızı [km/sa]
- `vehicle.range`: Kalan menzil [km]
- `battery.soc`: Batarya SOC [%]
- `battery.status`: Şarj/deşarj durumu [enum]
- `battery.estimated_remaining_charge_time`: Şarja kalan süre [dakika]
- `battery.power`: Anlık güç / güç ölçer [kW]
- `battery.regen_level`: Rejeneratif frenleme seviyesi [enum]
- `vehicle.gear`: Vites [P/R/N/D]
- `vehicle.drive_mode`: Sürüş modu [Konfor/Ekonomik/Spor/Kar]
- `vehicle.outside_temp`: Dış sıcaklık [°C]
- `vehicle.odometer`: Toplam kilometre [km]
- `vehicle.trip1`: Kilometre 1 [km]
- `vehicle.trip2`: Kilometre 2 [km]
- `tires.front_left`: Sol ön lastik basıncı [kPa/bar]
- `tires.front_right`: Sağ ön lastik basıncı [kPa/bar]
- `tires.rear_left`: Sol arka lastik basıncı [kPa/bar]
- `tires.rear_right`: Sağ arka lastik basıncı [kPa/bar]
- `climate.cabin_temperature`: Kabin sıcaklığı [°C]
- `climate.target_driver_temperature`: Sürücü sıcaklık hedefi [°C]
- `climate.target_passenger_temperature`: Yolcu sıcaklık hedefi [°C]
- `climate.fan_speed`: Klima fanı [kademe]
- `climate.mode`: Klima modu [enum]
- `vehicle.doors`: Kapıların durumu [enum/list]
- `vehicle.windows`: Camların durumu [enum/list]
- `vehicle.locked`: Merkezi kilit durumu [bool]
- `vehicle.seat_heater`: Koltuk ısıtma durumu [enum]
- `vehicle.alerts`: Arıza ve uyarılar [list]
- `adas.acc`: AHSS durumu ve hedef hız [enum + km/sa]
- `adas.aeb`: AEB durumu [enum]
- `adas.lane`: LDA/ELKA uyarıları [enum]
- `adas.tsr`: TSR işaretleri [km/sa]
- `adas.blindspot`: Kör nokta uyarıları [enum]
- `vehicle.air_quality_pm25`: PM2.5 [µg/m³ (cihaz birimi doğrulanmalı)]
- `vehicle.location`: Konum [enlem/boylam]
- `phone.gps_speed`: Telefon GPS hızı [km/sa]

## Teknik özellikler

Kaynak PDF sayfaları 207-211, basılı kılavuz s. 202-206. Tam değerleri JSON ve ham kılavuz metninden okuyun.

## Ham kaynak ve eksiksiz metin

`kilavuz_tam_metin.txt` ve `kilavuz_tam_metin.json` sayfa sayfa tüm ayıklanabilen metni içerir. Şekil, tablo ve görseller için orijinal PDF temel kaynaktır.
