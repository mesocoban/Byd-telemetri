# BYD Sealion 7 — GitHub kaynakları, Electro APK, Yoldaş 249 APK: veri okuma doğrulaması

**İnceleme tarihi:** 24 Ekim 2026. **Analiz yöntemi:** Kullanıcının sağladığı GitHub kaynak ZIP'lerinin doğrudan kod okunması; iki APK'nın binary AndroidManifest.xml, DEX string/type/class/method kimlikleri ve `code_off` alanları üzerinden statik analizi; seçili ELF `.so` kütüphanelerinde sembol ve string kontrolü; firmware arşivlerindeki APK/JAR DEX tanım karşılaştırması. **Çalışma zamanı testi yapılmadı.** Kod gövdesi bulunması, getter'ın çağrıldığı veya anlamlı veri döndürdüğü anlamına gelmez. Web'den okunan güncel proje belgeleri kullanıcı tarafından sağlanan ZIP sürümünden farklı olabilir.

## Kesin teknik sonuç

Firmware iki birbirini tamamlayan OEM okuma yoluna işaret ediyor:

1. `com.ts.lib.caradapter` TS adaptörleri: `ts-framework.jar` içinde tanımlanmış okuyucu arabirimleri ve `CarAdapterService.apk` içinde sağlayıcı tarafın kod gövdeleri. `CarSensorAdapterManager.getCurrentSpeed()`, `CarGeneralAdapterManager.getElecPercentageValue()`, `getElecDrivingRangeValue()`, `ChargingAdapterManager.getChargingPower()` imzaları bu tarafta mevcut. ABRP kodu bu arayüzleri kullanıyor.
2. `android.hardware.bydauto` BYDAuto aygıtları: firmware içindeki `BydAutoService.apk`, `BydDataCollect.apk` ve `BydMyCar.apk` içinde `BYDAutoSpeedDevice.getCurrentSpeed()`, `BYDAutoStatisticDevice.getElecPercentageValue()`, `BYDAutoInstrumentDevice.getOutCarTemperature()` sınıflarına ait kod gövdeleri mevcut. Electro APK içindeki aynı tip sınıf/metot imzaları da tanımlanmış. BYD Trip Stats DiLink 5 istemcisi bu ailede typed listener kullanıyor.

Her iki yol da üçüncü taraf uygulama için **resmî/izinli erişim kanıtı değildir**. Android 17 telefon üzerindeki `android.car` API'si bu OEM baş üniteye doğrudan erişim sağlamaz.

## Karşılaştırılan kaynaklar

| Dosya/proje | Gerçek yaklaşım | Güçlü taraf | Kritik sınır |
|---|---|---|---|
| `abrp-telemetry-sl7-main.zip` | `CarAdapterManager` ile TS SDK üzerinden periyodik snapshot; GPS `LocationManager`; ABRP'ye HTTP gönderimi | Sealion 7 özel, firmware TS metoduyla eşleşiyor; şarj gücü ve bağlantı kopması için önlem içeriyor | `CarAdapterService` restart, ters viteste veri kesilmesi, şarj harici yanlış güç, ADB tabanlı kalıcılık ve izinler |
| `byd-trip-stats-develop.zip` | DiLink 5 için `Dilink5Client.kt` ve typed BYDAuto listener + gerektiğinde getter/poll | Veri tazeliği, eventi/poll ayrımı, olası sentinel ve lastik birimi problemi için kontroller | Bazı getter'lar sabit/sentinel; bazı alanlar tahmin; DiLink 5 OEM izni/hidden API değişikliği ve araç sürümü bağımlılığı |
| `BYDMate-main.zip` | `autoservice` Binder, FID eşlemesi, BMS `energydata` veritabanı, shell erişimi | Geniş gözlem kapsamı ve gerçek sistem servisinde yerleşim | FID'nin yanlış eşlenme riski; araç üzerinde onaysız erişim, araç kontrol çağrıları; test edilen örnek araç Sealion 7 değil |
| `Electro-Car-App.apk` | APK içinde `android.hardware.BYDAutoManager`, BYDAuto cihaz getter ve listener metot gövdeleri, MQTT Paho istemcisi | OEM BYDAuto sınıflarıyla imza uyumu; MQTT köprüsü mümkün | APK obfuske; sınıfın bulunması fiilî veri kullanımı değil; çalışma zamanı/kimlik/izinler ve birim dönüşümleri doğrulanmadı |
| `yoldas-arac-249.apk` | `Dilink5Yukleyici`, `Dilink5CarAdapter`, `Dilink5Telemetri`, `Dilink5Sozlesme`, `OlcumSonucu` ve olay/poll bileşenleri | Kaynak-zaman-hata-durum modellemesi ve adaptör keşfi düşünülmüş | APK metinlerinde DiLink 5 desteğinin bazı bölümlerinin hazırlıkta olduğu yazıyor; tahmini anahtarların anlamı ve fiilî çalışma doğrulanmadı |

## Electro APK ayrıntısı

- APK `package`: `br.com.rory.electro`; SHA-256: `c0937bffd7f2a5a2b6d5bcb1cba8aa83e6849d24b761e664ce33109feafe9390`.
- Bir DEX, 5.636 sınıf tanımı ve 54.401 method_id referansı. Kaynakları kısmen obfuske ve `.so` bileşenleri içeriyor.
- `android.hardware.bydauto.speed.BYDAutoSpeedDevice`: `getCurrentSpeed()` gövdesi;
  `...statistic.BYDAutoStatisticDevice`: `getElecPercentageValue()`, `getTotalMileageValue()` gövdeleri;
  `...charging.BYDAutoChargingDevice`: `getChargerState()`, `registerListener()` gövdeleri;
  `...instrument.BYDAutoInstrumentDevice`: `getOutCarTemperature()` gövdesi.
- `android.hardware.BYDAutoManager` içinde `getInt`, `getDouble`, `getBuffer`, `setInt` gibi imzalar da mevcut; bu nedenle *yalnızca okuma* uygulaması değildir. Uygulamanın bu yöntemleri hangi koşullarda çağırdığı kontrol edilmeden güvenlik değerlendirmesi tamamlanamaz.
- MQTT için Eclipse Paho istemcisine ilişkin sınıflar ve `'/mqtt'` stringi bulunuyor. Telemetriyi yerel/ağ sistemlerine aktarabilme ihtimali yüksek; gerçek ağ trafiğinin hangi bilgilerden oluştuğu ancak izinli runtime ağ gözlemiyle doğrulanır.
- 23 manifest izin talebinde `WRITE_SECURE_SETTINGS`, `READ_LOGS`, `ACCESS_BACKGROUND_LOCATION`, `RECORD_AUDIO`, `CAMERA`, `SYSTEM_ALERT_WINDOW` ve kurulum izni bulunuyor. `MainService` exported=true ve manifestinde `permission` tanımlanmamış; servis içi kontroller incelenmeden dışarıdan çağrılabilirliğin etkisi kesinleştirilemez. Salt-okunur telemetri uygulaması için izin yüzeyi gereğinden geniş.
- Yerel `libelectropkg.so` içinde JNI ve BYDAuto stringleri, `libnative-lib.so` içinde görüntü işleme JNI sembolleri mevcut. Kendi `.so`'larını taşıması otomatik olarak araç SDK yetkisi verdiği anlamına gelmez.

## Yoldaş 249 APK ayrıntısı

- APK `package`: `app.yoldas.arac`; SHA-256: `2a9900293e8a62ebf9a52ebf7fa158b3aef8681655901deefb9c28d4eea31a20`.
- Bir DEX, 6.623 sınıf tanımı ve 35.690 method_id referansı.
- `Dilink5Yukleyici`: SDK yükleyici/oturum; `Dilink5CarAdapter`: bağlan, abone ol, oku, kapat; `Dilink5TelemetriYolu`: okuyucu/olay-tabanlı yol; `Dilink5Sozlesme$Alan`: birim, min/max, aralık, olay aralığı, getter alanları; `OlcumSonucu`: değer, durum, ham değer, hata, kaynak, okuma/olay zamanları. Bunlar gerçek DEX class_def ve kod gövdesi olarak tespit edildi.
- `DiLink5Kesfi` ve `AdayProbu` gibi keşif/probe modülleri mevcut. Keşif ile bulunan olası bir sınıf ya da FID'nin anlamı otomatik olarak doğrulanmış sayılmaz.
- APK stringlerinde `/system/framework/bydauto.jar`, `/system/framework/com.ts.lib.caradapter.jar` var; bunlar çalıştırılan veya cihazda gerçekten mevcut yollar değil, kod içinde referans olarak görülen stringlerdir.
- APK metinlerinde `DiLink 5 ... destek hazırlanıyor; bazı bölümler kapalı` ifadesi var. Destek yeteneklere göre ayrılmış olabilir. Her panel alanını doğrulanmış kabul etmeyin.
- `libyoldas_sl7_capture.so`, `libyoldas_sl7_hook.so` var. İlki `/data/local/tmp/yoldas-sl7-camera-v1-*` ve ikinci `.so` için izler içeriyor: **kamera yakalama/hook potansiyeli**, telemetri veri doğruluğu kanıtı değil. Kütüphaneleri çalıştırmadım ve teknik/uygulama güvenliği için önermiyorum.
- Android Accessibility Service ve DEBUG kurulum servisi manifestte erişim izniyle tanımlı; kamera/mikrofon/overlay dahil ek izinler var. İşlevsel güvenlik ve mahremiyet denetimi ayrıca yapılmalı.

## Veri doğruluğu için çarpıcı somut bulgular

1. **Hız:** TS `getCurrentSpeed()` firmware ve ABRP yolu arasında imza eşleşiyor. BYD Trip Stats'ın yüklenen kaynak dosyasında `BydVehicleDataSource.kt` ~8248–8258 satırları, bazı DiLink 5 örneklerinde `BYDAutoSpeedDevice` typed hız callback'inin uygulamaya ulaşmadığını ve TS sensör adaptörünün alternatif olduğunu açıkça söylüyor. Bundan dolayı hız olayına kör güvenmeyin. Başka araç sürümlerinde değişebilir.
2. **Lastik basıncı:** Trip Stats `Dilink5Client.kt` ~347–356 satırları, lastik değerlerinin panelin birimine göre değişebileceğini ve sıcaklığın getter yerine olaydan okunması gerekebileceğini açıklıyor. `BydVehicleDataSource.kt` ~8058–8156 satırları centi-bar/deci-bar/bar ve alternatif deci-PSI çözümlemesi uygular. Bu bir heuristiktir; lastik birimi doğrulanmadıkça ciddi bir uyarı veya göstergeye bağlanmamalıdır.
3. **Güç:** Trip Stats DiLink 5 istemcisinde HV gerilim×akım gerçek ölçüme dayalı hesap ile SOC kullanılabilir enerji değişimi üzerinden türetilmiş *tahmini* güç birbirinden ayrılmış (`Dilink5Client.kt` ~383–409). Kullanıcının hedef uygulamasında tahmin ham ölçüm diye gösterilmemeli; yalnız doğrulanmış güç ölçümü aktif edilmeli.
4. **Şarj gücü:** ABRP kendi README'sinde şarj yokken `getChargingPower()` sonucunun anlamsız olabildiğini bildiriyor. Şarj durumu doğrulanmadan şarj gücü gösterilmemeli.
5. **Güncellik:** Listener değerleri, servis kopması ve akü uyku hali sonrasında kalabilir. Her metrik `sourceTimestamp`, `receivedAt`, `quality`, `supportStatus`, `permissionStatus` ile saklanmalı ve timeout sonrası `Stale`/`Disconnected` gösterilmeli.

## Araç sürüş paneline alınması önerilen yaklaşım

- `VehicleDataProvider` arabirimi altında ayrı ve varsayılan **pasif** adaptörler: `AaosReadOnlyProvider` (izinli standart VHAL), `TsReadOnlyProvider` (yalnız belge/izin varsa), `BydAutoReadOnlyProvider` (yalnız belge/izin varsa). `Yoldas`/`Electro` APK'larını olduğu gibi çağırmaya veya yazma izinlerini kopyalamaya gerek yok.
- Kaynak başına *capability discovery*: servis, izin, property/getter, gerçek dönüş tipi, fiziksel birim, timestamp, örnek ölçüm kaydı. İzin/kaynak yoksa `Veri alınamıyor`, `Desteklenmiyor`, `Yetki gerekli`; araç hızını telefon GPS hızından ayırın.
- Hız: uygun TS ya da standart `PERF_VEHICLE_SPEED_DISPLAY` ile salt-okunur; SOC: orijinal getter veya belgeli VHAL batarya enerjisi; menzil ve şarj yalnız çalışma zamanı doğrulaması sonrası. Lastik basıncında profil ve ekran birimi özel test zorunludur.
- Kalite eşikleri: hız için kısa tazelik süresi; sıcaklık/SOC için uzun süre; eşikler araçtaki yayın frekansından kalibre edilmeli. Hatalı/sentinel/0 değer, makul görünse bile doğru diye kabul edilmemelidir.
- Araç kumandası, ECU yazma, hidden-API muafiyetini değiştirme, ADB shell'den servis çağırma veya sistem hook'u **aktif edilmemeli**.

## Gerçek dünyada doğrulamayı tamamlamak için gereken kanıt

**Araç park hâlinde ve izinli tanılamayla:** DiLink sürümü/Android API seviyesi; `pm list features` ve baş ünitede kamusal CarService property'si bulunup bulunmadığı; uygulamaya gerçekten izin verilip verilmediği; 15–30 saniyelik (yalnız sürüş yapılmadan) SOC, menzil, sıcaklık ve şarj durumunun OEM ekrandaki değerle karşılaştırıldığı *kişisel bilgi çıkarılmış* tanılama özeti. Hızın 0 dışındaki çalışma zamanı doğrulaması kontrollü test alanında, sürücüyü meşgul etmeyen bağımsız gözlemciyle yapılmalı. VIN, konum, token ve kişisel günlükler paylaşılmamalıdır.

## İncelemenin sınırları

- APK'lar yüklenmedi/çalıştırılmadı; trafik izlenmedi; çalışan Binder servisleri sorgulanmadı; cihaz sürümüne göre uyumluluk ölçülmedi.
- DEX'te metod tanımlanması o metotun uygulama çalışırken çağrıldığını kanıtlamaz; bytecode'daki tüm dalları decompile edip semantik akış teyidi yapılmadı.
- Yerel `.so`'ların yüzeysel ELF/string incelemesi kötü amaçlı davranış olup olmadığını kanıtlayamaz.
- APK imzasının geliştiriciyle eşleştirilmesi veya dosyanın değiştirilmemiş orijinal yayın olduğuna dair kriptografik doğrulama yapılmadı.

## Dış doğrulama bağlantıları

- ABRP Sealion 7: https://github.com/CRCinAU/abrp-telemetry-sl7
- BYD Trip Stats DiLink 5: https://github.com/angoikon/byd-trip-stats/blob/main/docs/DILINK5.md
- BYDMate (yüklenen arşiv adının eşleştiği GitHub projesi): https://github.com/AndyShaman/BYDMate
- Electro ürün sayfası: https://electro.app.br/tr/

**Özet:** Her iki APK da gerçek BYD SDK'sı için anlamlı sinyal ve sınıflar içeriyor. Elektro'nun BYDAuto metotları firmware ile doğrudan eşleşiyor; Yoldaş'ın DiLink 5 sınıfları uyarlanabilir, durum takibi açısından iyi tasarlanmış görünüyor. Fakat hiçbiri şu aşamada doğrudan *Sealion 7'de doğrulanmış, güvenli ve yetkili salt-okunur ölçüm sağlayıcısı* olarak kabul edilemez.
