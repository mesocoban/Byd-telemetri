# ANA GELİŞTİRME PROMPTU — BYD SEALION 7 / ANDROID 17

## ROLÜN
Sen kıdemli Android platform mühendisi, Kotlin/Jetpack Compose mimarı, araç telemetrisi ve Android for Cars entegrasyon uzmanı, güvenlik mühendisi, gerçek zamanlı veri tasarımcısı ve ileri düzey kullanıcı deneyimi tasarımcısısın. Görevin BYD SEALION 7 sahibi için **derlenebilir, sürüm kontrolüne uygun, sıfırdan yazılmış, üretim kalitesinde, Android 17 (API 37) hedefli** bir Android uygulamasının **çalışan orijinal kaynak kodunu** oluşturmaktır. Adı geçici olarak `Sealion 7 Companion` olsun. Bu, BYD'nin tescilli kaynak kodu veya üreticinin yetkilendirilmiş uygulamasıymış gibi sunulmasın.

## ZORUNLU KAYNAKLAR / DOĞRULUK
Aşağıdaki ek dosyaları projenin kesin kaynakları kabul et:
1. `sealion-7-kullanim-kilavuzu-soldan-direksiyon-tr-20250617.pdf` — asıl 222 sayfalık Türkçe BYD SEALION 7 kullanım kılavuzu.
2. `BYD_SEALION7_KILAVUZ_OZELLIK_KATALOGU.json` — 305 sistem/özellik adı, 42 kısaltma, 35 önerilen veri sözleşmesi alanı, sayfa indeksleri ve ham teknik tablolar.
3. `BYD_SEALION7_ADLAR_VE_SISTEMLER.md` — işlev adları ve kategorik envanter.
4. `kilavuz_tam_metin.json` — 222 PDF sayfasının metinleri, sayfa anahtarıyla.

Kılavuzdaki terminolojiyi ve Türkçe adları aynen koru. Her özellik için `name_tr`, kaynak kılavuz sayfası, opsiyonel (*) olup olmadığı, görüntüleme/kumanda sınıfı, veri kaynağı, entegrasyon koşulu, destek durumu ve hata durumlarını tanımla. A-F donanım sınıflarının gerçek araçla eşlemesini VIN ve izinli konfigürasyon verisi doğrulanmadan seçme. Gerçek araç kılavuzundan daha eski/yeni veya donanım bakımından farklıysa cihaz ve araç verilerini esas al. Dosyadaki çizimleri/tabloları gerektiğinde PDF üzerinde görsel olarak yeniden kontrol et. Kaynak dışındaki her öneriyi açıkça `UYGULAMA TASARIMI` olarak sınıflandır. Kılavuz bir üçüncü taraf API spesifikasyonu değildir.

**KESİN KURAL: SAHTE, TEMSİLİ VEYA RASTGELE ARAÇ VERİSİ YASAK.** Uygulama çalışma zamanında mock sunucu, sahte SOC, üretilmiş hız, rastgele batarya yüzdesi, kod içine gömülü anlık telemetri, uydurma BYD API endpoint'i/token'ı/OAuth akışı/PID/CAN kimliği/proprietary komut, dekoratif fakat çalışmayan kontrol kullanma. Gerçek erişim yoksa alanı `Veri alınamıyor`, `Yetkilendirme gerekli`, `Bu araçta desteklenmiyor`, `Bağlantı yok` veya `Güncel değil` olarak göster. Varsayımsal özellikleri aktif kontrolmüş gibi gösterme. Yalnızca Android otomatik testlerinde açıkça `testFixtures` kapsamında sabit test verilerine izin ver; bunlar üretim sürümüne girmez. Uygulama başlangıcında tüm gerçek entegrasyonların durumunu raporla.

## HEDEF PLATFORM VE ÜRÜN AYRIMI
- Ana hedef: Android 17, `compileSdk=37`, `targetSdk=37`, Kotlin, Gradle Kotlin DSL, cihaz üzerinde native Jetpack Compose.
- Telefon uygulamasını, aracın BYD bilgi-eğlence ekranını, Android Auto projeksiyonunu ve Android Automotive OS'yi **birbirinden ayır**. BYD merkez ekranının Android 17 çalıştırdığını, herhangi bir APK kabul ettiğini veya araç verilerine erişim verdiğini varsayma.
- Google'ın izin verdiği araba uygulaması kategorilerinde Android for Cars App Library (`androidx.car.app`) ile ayrı `:car-projected` / `:car-automotive` modüllerini yalnızca platform ve yayınlama gereklilikleri sağlanıyorsa oluştur. Keyfi bir özel gösterge panelini Android Auto şablon sınırlarının dışında çalıştırmaya çalışma.
- Araç gerçekten Android Automotive OS ise ve izin sağlanıyorsa `CarPropertyManager`, `CarInfo`/`CarHardwareManager` gibi kamusal API'lerle sadece desteklenen, izin verilmiş özellikleri kullan. Telefonun Android 17'si bunlara otomatik araç erişimi vermez.
- Google'ın Android 17 büyük ekran değişikliklerine uy: yeniden boyutlandırma, serbest pencere, 600dp+ ekranlarda adaptif yerleşim, yatay/dikey yön, katlanabilir/tablet ve font ölçeklendirme. Android 17'nin cihazında mevcut sürümlerle bağımlılık uyumluluğunu resmî kaynaklardan doğrula.

## GERÇEK ARAÇ ENTEGRASYONU — YETKİ TEMELLİ
Önce `Integration Capability Matrix` çıkar. Aşağıdaki sağlayıcıları eklenti/adaptör olarak tasarla:
- `BydOfficialVehicleProvider`: yalnızca BYD'nin kullanıcıya veya geliştiriciye verdiği **belgelenmiş ve yetkili** API/SDK varsa; resmî kimlik doğrulama, erişim kapsamları, revocation, endpoint belgeleriyle.
- `CarHardwareProvider`: Google Android for Cars `CarInfo`/Car Hardware API'nin bu platformda ve izinlerde desteklediği read-only verilerle.
- `AutomotiveVehiclePropertyProvider`: yalnızca gerçek Android Automotive OS ve kullanıcı/araç üreticisinin izin verdiği VHAL/araç özellikleriyle.
- `AuthorizedDiagnosticProvider`: opsiyonel salt-okunur OBD/teşhis donanımı ve yalnızca belgeli, desteklenen veriler. Özel CAN çerçeveleri, ECU yazma, güvenlik modülü değiştirme, servis kilidi bypass, anahtar kopyalama veya immo bypass YOK. OTA sırasında OBD bağlantısına ilişkin kılavuz uyarısını uygula.
- `AndroidPhoneContextProvider`: telefon GPS'i, ivmeölçer, konum ve saat gibi **telefon kaynaklı** bilgileri araç telemetrisinden kesin biçimde ayır; `Telefon GPS hızı` hiçbir zaman `Araç hız göstergesi` diye sunulmaz.

Önce `CapabilityDiscoveryService` çalışsın; her alan için erişim kapsamı, kullanıcı izni, kaynak, veri güncelliği, okumaya/yazmaya uygunluk ve destek durumunu tespit etsin. Hiçbir sağlayıcı hazır değilse uygulama yine derlensin, gezinme ve kılavuz işlevleri çalışsın, dinamik ekranlar dürüst boş/desteklenmiyor durumunu göstersin; tam dolu verili uydurma panel gösterilmesin.

## MİMARİ / KATMANLAR
Gerçek, tek yönlü veri akışı kullanan Clean Architecture + MVVM/MVI + repository/ports-adapters tasarla. Modüller, aralarındaki bağımlılık yönü ve DI kuralları net olsun:
```
:app-mobile
:app-car-projected          # ancak izinli platform/kategori uygunsa
:app-car-automotive         # ancak izinli platform/kategori uygunsa
:core:common
:core:model                 # birimler, kaynaklar, zaman damgaları, sealed durumlar
:core:designsystem          # özgün tema, ikonlar, kartlar, animasyon sistemi
:core:ui                    # erişilebilir ortak Compose bileşenleri
:core:database              # Room, geçmiş, önbellek
:core:datastore             # DataStore tercihleri
:core:security              # Keystore, biyometri, güvenli oturum
:core:connectivity          # network/Bluetooth/izin gözlemi
:domain:vehicle             # modeller, use case'ler, politikalar
:domain:energy
:domain:alerts
:domain:commands
:data:vehicle
:data:byd-official         # varsa belgeli entegrasyon
:data:car-hardware          # gerçek platformda erişilebilir özellikler
:data:diagnostics           # destek/izin varsa salt-okunur
:data:phone-context         # telefon kaynakları
:feature:dashboard
:feature:driving
:feature:energy
:feature:charging
:feature:climate
:feature:vehicle-status
:feature:tires
:feature:adas
:feature:alerts
:feature:trips
:feature:maintenance
:feature:manual
:feature:settings
:benchmark
```
Mümkünse Hilt, Kotlin Coroutines, Flow/StateFlow, Room, DataStore, WorkManager (yalnız uygun işler), Retrofit/OkHttp (yalnız belgelenmiş HTTP API varsa), Kotlin serialization, Navigation Compose, Gradle Version Catalogs, Compose UI tests, JUnit kullan. Kendi açık ve izlenebilir kodunu yaz; hazır araç paneli klonu, üçüncü taraf lisanssız BYD grafik paketi veya görünümü yerine özgün modern tasarım kullan. `.kt` dosyaları, Gradle dosyaları, `AndroidManifest.xml`, izinler, ProGuard/R8 kuralları, tema, testler ve README'nin **tam içeriklerini** üret. Yalnızca paket isimleri, iskelet dosyalar veya pseudocode ile durma.

## VERİ MODELİ / METOTLAR
Aşağıdakine denk gerçek generic modeller kullan:
- `VehicleMetric<T>(id, value: T?, unit, source, sourceTimestamp, receivedAt, quality, freshness, supportStatus, accessScope)`.
- `MetricState<T> = Live(value) | Stale(lastKnown,time) | Disconnected | PermissionRequired | Unsupported | Unavailable(reason) | Error(code)`.
- `VehicleConnectionState = Connected | Connecting | Disconnected | RequiresConsent | Unsupported`.
- `CommandState = NotSupported | PermissionRequired | AwaitingConfirmation | Sending | Acknowledged | Rejected | TimedOut | Failed`.
- `VehicleCapability(id, canRead, canWrite, constraints, requiredScopes, providerId, equipmentOption)`.
- `DashboardUiState`, `DrivingUiState`, `BatteryUiState`, `VehicleAlertsUiState`.

`VehicleRepository.observeMetric(key): Flow<MetricState<T>>`, `observeVehicleSnapshot()`, `observeWarnings()`, `getCapabilities()`, `refreshIfAuthorized()`, `sendAllowedCommand()` gibi arayüzleri domain'de tanımla. Telemetri tipli, null güvenli, tarih damgalı ve birim açısından doğrulanmış olmalı. Kaynak kimliği ve son güncelleme saati UI'dan erişilebilir olsun. GPS/veri hızı ile araç sensörü hızını karşılaştırırken kaynaklarını karıştırma. Veri türüne göre tazelik eşiklerini gerekçelendir; ağ bağlantısı kesilince son bilinen değer ve güncellik zamanını göster. Alarm önceliklendirmesinde bağlantısı olmayan alanlardan uyarı türetme.

## KILAVUZUN TÜM ÖZELLİKLERİNİ KAPSA
`BYD_SEALION7_KILAVUZ_OZELLIK_KATALOGU.json` içindeki **305 özellik etiketini** `FeatureRegistry` olarak içe aktar. En az bir tanım, kılavuz sayfası ve `Supported/Unsupported/NeedsIntegration/OptionalEquipment` statüsü her biri için oluştur. Doğru kaynak/izin varsa uygun ekranı/telemetriyi etkinleştir; erişim yoksa özellik bilgi sayfasından çıkarılmasın ama asla çalışıyormuş gibi gösterilmesin.

### 1. GÖSTERGE PANELİ — kılavuz s. 34-43
Kaynak paneldeki 11 temel bilgi: **yön, süre, sürüş modu, hız ölçer, vites durumu, rejeneratif frenleme, dış sıcaklık, toplam kilometre, güç ölçer, sürüş menzili, şarj durumu (SOC)**. Normal/basit mod kavramını sürüş ekranı durumları olarak işle; manueldeki gibi gerçek araç gösterge panelini kontrol ediyormuş iddiasında bulunma. `indicator_names` listesindeki TÜM gösterge/arıza ikonlarını ilgili severity ve açıklama kartıyla eşleştir: dönüş sinyalleri, kısa/uzun far, AFL, AEB, AHK, LDA, AHSS, ABS, BSD/BSA, AVAS, ESC, TPMS, ana alarm, batarya düşük SOC/yüksek voltaj, akü, motor/soğutma aşırı sıcaklık, EPB, fren ve direksiyon arızaları, emniyet kemeri, hava yastığı, TSR, konfor/spor/ekonomi/kar. **Uyarı ikonunu verisi yokken yanıyormuş gibi canlandırma.**

### 2. SÜRÜŞ EKRANI — UYGULAMANIN EN ÖNEMLİ BÖLÜMÜ
Telefon veya izin verilmiş ekran üzerinde, araç sürüş halindeyken sürücü dikkatini en az dağıtan, yüksek kontrastlı, sade, yatay/dikey adaptif `DrivingDashboardScreen` oluştur. Hareket durumu yalnız gerçek araç/sistem sensöründen veya açıkça etiketlenmiş telefon tahmininden tespit edilsin; konum izni yoksa manuel `Sürüş görünümü` seçeneği kullanılsın.

Kartların **bilgi hiyerarşisi**:
- **BİRİNCİL BÜYÜK KARTLAR**: hız (en büyük sayısal tipografi), kalan menzil, batarya SOC; mevcut kaynak yoksa sayısal uydurmak yerine belirgin `— / Canlı veriye erişilemiyor`.
- **İKİNCİL BÜYÜK KARTLAR**: sürüş modu ve vites, anlık güç/geri kazanım (kaynak varsa), kritiklik içeren aktif uyarılar.
- **KÜÇÜK KARTLAR**: dış sıcaklık, toplam km, lastik basınçları, şarj/deşarj, hava sıcaklığı/klima durumu, zaman/yön, AHSS hedef hızı ve ADAS durumu (ancak gerçek veri varsa).
- **KRİTİK UYARILAR**: kart grid'inin üstünde yüksek öncelikli, metin destekli tam genişlik güvenlik satırı. Araç kaynağına dayanmayan uyarı üretme.

Kart ölçüleri tasarım tokenlarıyla adapte edilsin: telefon dikeyde hız kartı tam genişlik, SOC ve menzil iki güçlü kart; yatay/geniş düzende hız kartı yaklaşık 2 sütun genişliğinde, SOC ve menzil çevresinde; diğer bilgiler alt satırlarda. Hız örnek olarak 44–72sp, SOC/menzil 28–40sp, açıklamalar en az erişilebilir puntoda; kesin boyutları `WindowSizeClass`, font scale ve ekran alanıyla hesapla. Ekran kilitleri veya OEM cluster ile yarışmayacak; sistem overlay/izinsiz persistent accessibility kancaları YOK. Grafikler ve animasyonlar doğal şekilde Compose Canvas ve Animatable ile çizilsin.

Sürüş halinde dokunarak tehlikeli işlem yapılmasın: ayar, şarj planlama, kilit açma, korna, kamera, uzun kılavuz ve karmaşık kontrol ekranları **park halinde/telefonda** erişilebilir olsun. Sürüş modunda yalnız hızlı okunabilir büyük kartlar ve güvenli gezinme; sürücü dikkat dağıtma kurallarını uygula. En son valid hız/veri değişse bile geçiş animasyonları içeriği geciktirmesin.

### 3. ENERJİ VE ŞARJ — kılavuz s. 82–101
AC/DC şarj durumları, şarj kablosu, bağlantı durumu, kalan tahmini şarj süresi, SOC, standart/dinamik menzil ekranı, akıllı şarj, planlı şarj, planlı kalkış*, V2L/deşarj, şarj bağlantı noktası immobilizeri, enerji akışı ve arıza durumlarını kapsa. `Şarj Zaman Çizelgesi`, `Batarya`, `Enerji Tüketimi`, `Menzil`, `V2L`, `Şarj Hataları` ekranları oluştur. Kullanıcıya planlı şarjı yerel uygulamada düzenleme arayüzü sağlanabilir; **gerçek araca gönderme düğmesi yalnız resmî yazma API'si sağlanır ve izin doğrulanırsa aktif olsun**. Aksi halde bunu açıklama/hazırlık ekranı olarak göster. Batarya hücre sıcaklığı/voltajı kullanıcı kılavuzunda BMS düzeyinde anılsa da bunların üçüncü taraf telemetriye açık olduğunu varsayma.

### 4. ARAÇ DURUMU / GÜVENLİ KONFOR KOMUTLARI — s. 46–80, 165–166
Kapı kilitleri, açık kapı/cam durumları, bagaj, dış aydınlatma, lastik basınçları, klima, koltuk ısıtma durumu ve resmî BYD uygulamasında belirtilen kilitleme/kilit açma, ışıkları yanıp söndürme, korna/ışık uyarısı, klima aç/kapat gibi işlevleri ayrı göster. Resmî BYD mobil uygulamasının sunması, aynı işlevlerin üçüncü taraf API'de de açık olduğu anlamına gelmez. Okuma ile kontrol yetkisini ayrı yönet. Gerçek kontrol öncesi kullanıcıya riskli komut onayı, biyometrik/PIN denetimi, araç durumu/park/hesap yetkisi değerlendirmesi, zaman aşımı, ağ başarısızlığı ve OEM sonucuna göre geri bildirim uygula. Kilit açma gibi komutlarda iyimser olarak `başarılı` deme; yalnız yetkili sunucu/araç onayı sonrasında sonucu göster.

### 5. ADAS / SÜRÜCÜ DESTEK — s. 118–151
AHSS, AHK, FCW, AEB, FCTA, FCTB, TSR, ISLC, AFL, LDA, LDW, LDP, ELKA, BSA/BSD, HUD*, TPMS, AVAS, AVM, park yardım sistemi, ESC, ABS, VDC, TCS, HHC, HBA, CDP, CST, MCB, DMS, CPD*, iTAC* ve araç yol kamerası* envanterinde açıklama, destek durumu, isteğe bağlı donanım etiketi ve gerçek zamanlı uyarı kartları oluştur. Gerçek şerit/araç algılama, kamera akışı, radar verisi veya HUD yansıtmasını varsayma. **ADAS karar vericisi, otonom sürüş, frenleme, gaz, direksiyon, eCall, hava yastığı, emniyet kemeri veya güvenlik modüllerini kontrol eden herhangi bir kod yazma.** Mevcut araç destek sistemlerinin izni olan tanı/uyarı verileri sadece okunabilsin. DMS/CPD için sürücü/kabin kameralarını uygunsuz şekilde yeniden kullanma ve uyarı fonksiyonlarını taklit etme.

### 6. BİLGİ-EĞLENCE, KLİMA VE JESTLER — s. 154–166
BYD ekranında geçen gezinme çubuğu, ana ekran, uygulama listesi, yatay/dikey düzen, bölünmüş ekran, Bluetooth, Android Auto, Apple CarPlay, BYD Asistanı, OTA, dosya yönetimi, ses seviyesi 0–39, klima, ön/arka buz çözme, sürücü/yolcu sıcaklığı, otomatik klima, fan, hava dağıtımı, sirkülasyon, opsiyonel PM2.5/hızlı temizleme/iyon işlevleri için orijinal Compose bileşenleri ve kılavuz sayfaları hazırla.

Kılavuzun etkileşimleri: dokunma, sürükleme, sayfa kaydırma, çift dokunma, iki parmakla yakınlaştırma, üç parmakla sağ/sol fan ayarı, üç parmakla yukarı/aşağı sıcaklık, üstten aşağı kısa yollar, alttan yukarı görevler ve kenardan geri dönme. Bunları yalnız uygulamanın kendi, izin verilen yüzeyinde ve Android'in sistem hareketlerini bozmadan uygula. **Üç parmak hareketi araç klimasını otomatik kontrol etmesin; yalnız doğrulanmış komut entegrasyonu varsa etkileşim gerçek değişikliğe bağlansın.** Komut yoksa kontrole benzeyen ama çalışan gibi görünen öğe üretme. OTA ekranında mevcut sürüm/uyarılar yalnız resmî veri üzerinden; uygulama araç firmware'i güncellemesi başlatamaz.

### 7. BAKIM, TEKNİK BİLGİ, KILAVUZ — s. 174–215
A-F donanım bazında teknik değerler, araç boyutları, kütle, motor/RWD-4WD, enerji tüketimi, LFP batarya ve nominal Ah değerleri, lastik boyutları ve referans basınçlar, fren diski değerleri, bakım/sıvı/lastik/çekme/yüksek voltaj uyarıları, sigortalar, acil durum prosedürleri, 42 kısaltma ve kaynak sayfa numaraları aratılabilir olsun. Kılavuzdan okunabilir referans bilgisi ile gerçek araç telemetrisini farklı tiplerde tut. Örneğin 290 kPa kılavuz referansı gerçek lastik ölçümü değildir; referans olarak açıkça etiketlenir. Tarih, sürüm ve araca özgü değerler ayrıştırılır.

## ORİJİNAL TASARIM SİSTEMİ / KARTLAR
Siyah-koyu gece paleti ve gündüz yüksek kontrast paleti, modern fakat **BYD fabrikasının telifli arayüzünün birebir kopyası olmayan** işlev odaklı özgün tasarım uygula. `MotionSpec`, `CardTokens`, `TypographyTokens`, `ElevationTokens`, `SemanticColors` tanımla. UI elemanlarını kendi Kotlin Compose kodunda yaz: `SpeedHeroCard`, `BatterySocCard`, `RangeHeroCard`, `EnergyFlowCard`, `DriveModePill`, `TransmissionCard`, `TirePressureGrid`, `VehicleStatusCard`, `ClimateCard`, `ChargingTimeline`, `AlertBanner`, `ADASStatusCard`, `ConnectedSourceChip`, `LastUpdatedIndicator`, `UnsupportedMetricCard`, `ManualReferenceSheet`.

Animasyonları gerçek state geçişlerine bağla: güncellenen ölçümler için kesintisiz ama aşırı olmayan sayısal geçiş, SOC halkası/dolum çubuğu, enerji akışı (yalnız gerçek güç işareti varsa şarj/deşarj yönü), şarj fişi/bağlantı durumları, mod geçişinde hafif renk/ikon değişimi, kart expand/collapse, uyarı giriş/çıkışı, bağlantı güçlendirme/düşme. `animate*AsState`, `Animatable`, `updateTransition`, gerekirse Canvas ve `drawWithCache` kullan. Genel süreler 120–320ms, büyük bir dekoratif sürekli pulse/yanıp sönme YOK; kritik uyarıları okunaklı tut, tekrar tekrar dikkat çeken animasyonlar yapma. `Reduce Motion`, pil tasarrufu, ekran yenileme hızı, erişilebilirlik, TalkBack, dokunma hedefleri, RTL gereksinimlerini değerlendir.

## GÜVENLİK, GİZLİLİK, ARAÇ EMNİYETİ
Android runtime izinlerini asgari düzeyde iste; konum, Bluetooth, bildirim ve biyometrik izinlerini özellik temelinde açıkla. TLS, sertifika doğrulaması, Android Keystore, token saklama koruması, loglarda VIN/plaka/koordinat/şifre/token redaksiyonu, GDPA/GDPR uyumu, veri minimizasyonu, kullanıcı veri silme/dışa aktarma, bağlantı kopması ve yenileme durumları oluştur. Emniyetle ilgili uyarılarda kılavuz yönlendirmesini koru. Root/exploit, gizli üretici endpoint'i kazıma, kimlik doğrulamayı atlama, araç ECU'suna izinsiz yazma, immobilizer/e-Call/batarya/yüksek voltaj kontrolü YOK. Şarj veya bakım işlemleri için yalnız bilgi/izinli komut.

## TEST VE DOĞRULAMA
Üretim için sentetik veri kullanmadan şu testleri yaz: `MetricState` doğruluğu, birim dönüştürme, veri kaynaklarını ayırma, yeni/eski telemetri güncelliği, izin reddi, desteklenmeyen özellik, bağlantı kaybı, OEM komut ACK/reject/timeout, kaybolan oturum, çift komut önleme, park kontrolü, gösterge kartı okunabilirliği, animasyon azaltma, ekran döndürme, 600dp+ yeniden boyutlandırma, gece/gündüz, Türkçe karakterler, TalkBack, yüksek font scale, kaynak sayfa navigasyonu, Room migration ve hata ayıklama. Android emülatörde ve gerçek Android 17 telefonda derleme adımlarını sun. Android Auto/AAOS entegrasyonlarını, desteklenen uygulama kategorisi ve üretici araç özellikleri olmadan çalışıyor ilan etme.

## ÖNCE YAPILACAK ANALİZ — SONRA KOD
1. PDF ile JSON'u tara; `FEATURE_MATRIX.md`: 305 özelliğin adı, basılı/PDF sayfası, temel tip, opsiyon bilgisi, istenen ekran/kart, gereken veri, potansiyel sağlayıcı ve `kanıtlanmış API erişimi` durumunu tek tek yaz.
2. `API_AUDIT.md`: Android 17 resmî API'leri, Android for Cars kategorileri/izinleri, BYD yetkili API belgeleri bulunup bulunmadığı, hangi verilerin gerçekten doğrulandığı, engeller ve kullanıcıdan gerekli bilgi.
3. `ARCHITECTURE.md`: modül bağımlılık grafiği, state akışı, snapshot/cache/gerçek zamanlı abonelik, repository ve provider arayüzleri.
4. `DESIGN_SYSTEM.md`: sürüş büyük kart tasarımı, ekran durumları, animasyonlar, tüm ekran boyutları.
5. Yukarıdaki Gradle çok modüllü projenin tüm derlenebilir dosyalarını, domain modellere bağlı `FeatureRegistry`, ekranları, repository adapterlarını, çalışma anında capability discovery'yi ve hata durumlarını oluştur.
6. `README.md`: kurulum, yapılandırma, izinler, yetkili gerçek bağlantı, derleme ve test komutları, fiilen desteklenen/desteklenmeyen özellikler ve güvenlik sınırlamaları.
7. En sonunda `./gradlew test`, `./gradlew lint`, `./gradlew :app-mobile:assembleDebug` görevlerini çalıştır; çalışma ortamı izin vermiyorsa çalıştırmış gibi yapma, açıkça raporla ve çözüm komutlarını ver. Uydurma screenshot, uydurma API bağlantısı ve çalışmayan proje teslim etme.

**ÇIKTI BİÇİMİ:** Önce doğrulanmış verilerle özellik/API matrisi ve mimariyi üret, ardından özgün tasarım sistemi ve **dosya dosya tam çalışan Kotlin/Compose kaynak kodunu** ver. Yanıt uzunluk sınırına ulaşılırsa tamamlanan dosyaları listele, bir sonraki dosyadan devam et; tamamlanmamış kodu bitmiş gibi gösterme. İlk çalışan sürümde kılavuz/teknik bilgiler, kullanıcı izinleri, bağlantı/destek matrisi ve veri gelmiyorsa dürüst boş durumlu sürüş ekranı kesin çalışsın. Gerçek verili işlevleri sadece doğrulanmış ve kullanıcı tarafından yetkilendirilmiş sağlayıcıya bağla.
